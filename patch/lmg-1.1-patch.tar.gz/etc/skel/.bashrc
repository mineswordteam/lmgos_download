# LMG OS shell
case $- in *i*) ;; *) return;; esac
HISTCONTROL=ignoreboth; HISTSIZE=2000; shopt -s histappend checkwinsize
alias ls='ls --color=auto'; alias ll='ls -lah'; alias grep='grep --color=auto'
alias update='lmg-control-panel update'
PS1='\[\e[38;5;39m\]╭─\[\e[38;5;45m\]\u\[\e[38;5;245m\]@\[\e[38;5;39m\]lmgos \[\e[38;5;250m\]\w\n\[\e[38;5;39m\]╰─\[\e[38;5;45m\]❯ \[\e[0m\]'
[ -z "$LMG_WELCOMED" ] && [ -t 1 ] && command -v lmg-info >/dev/null && { export LMG_WELCOMED=1; lmg-info; }
