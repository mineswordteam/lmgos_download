# LMG OS 1.0 (Logic Mind Grid) — Minesword Team

Light Linux desktop based on Debian 13 + XFCE, black and neon-blue theme.

## Highlights
- Neon theme, hexagon branding, boot splash, login/lock screen, "Welcome" and "Shutting down" screens
- Single bottom taskbar, slide-in sidebar (pin/dock), neon tooltips
- LMG OS Control Panel (Update, RAM, Hardware, Test, Disk, Settings, Gaming) and an interactive Tutorial
- Wide hardware support: AMD/Intel/NVIDIA GPUs, Wi-Fi (Intel, Broadcom, MediaTek, Realtek, Atheros, Qualcomm), Bluetooth, Android/iPhone (MTP/usbmuxd)
- zram + earlyoom for low-RAM machines; Windows apps via Wine/Bottles
- Calamares installer (supports disk encryption)

## Using it
1. Write the ISO to a USB stick with Rufus in **DD mode**, balenaEtcher, or `dd`.
2. Boot it. Live user: `live` / password `live`. If the screen stays black pick **LMG OS Live (safe graphics)**.
3. Start **Install LMG OS** from the desktop.

## Known limitations
- Control Panel and Tutorial are English and Persian only.
- Lock screen = LightDM greeter (Ctrl+Alt+L).
- First public build: please report bugs.
