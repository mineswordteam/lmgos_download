import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation {
    id: presentation

    Timer {
        interval: 7000
        running: true
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    function slide(title, body) { return {t: title, b: body}; }

    Slide {
        Rectangle { anchors.fill: parent; color: "#060a14" }
        Image { id: logo1; source: "lmg-logo.png"; width: 140; height: 140; anchors.horizontalCenter: parent.horizontalCenter; y: 60 }
        Text { anchors.top: logo1.bottom; anchors.topMargin: 24; anchors.horizontalCenter: parent.horizontalCenter
               text: "Welcome to LMG OS"; color: "#00d0ff"; font.pixelSize: 30; font.bold: true }
        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 330; width: parent.width - 120; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
               text: "Logic Mind Grid. Light, secure and yours."; color: "#dbe9ff"; font.pixelSize: 18 }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#060a14" }
        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 120; text: "Light"; color: "#00d0ff"; font.pixelSize: 30; font.bold: true }
        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 190; width: parent.width - 140; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
               text: "A tuned XFCE desktop that stays well under 1 GB of RAM at idle. Turn on Light mode to switch effects off."; color: "#dbe9ff"; font.pixelSize: 18 }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#060a14" }
        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 120; text: "Secure"; color: "#00d0ff"; font.pixelSize: 30; font.bold: true }
        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 190; width: parent.width - 140; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
               text: "Firewall on by default, AppArmor enabled, and full disk encryption available during install."; color: "#dbe9ff"; font.pixelSize: 18 }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#060a14" }
        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 120; text: "Runs your apps"; color: "#00d0ff"; font.pixelSize: 30; font.bold: true }
        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 190; width: parent.width - 140; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
               text: "Linux apps natively and Windows apps through Wine and Bottles. Built by Minesword Team."; color: "#dbe9ff"; font.pixelSize: 18 }
    }

    function onActivate() { }
    function onLeave() { }
}
