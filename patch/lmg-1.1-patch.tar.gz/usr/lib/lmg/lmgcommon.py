"""Shared helpers for LMG OS apps (GTK3, light on RAM)."""
import json, re, os, subprocess, threading
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib

LIB = "/usr/lib/lmg"
SHARE = "/usr/share/lmg"
HELPER = LIB + "/bin/lmg-helper"
CONF_DIR = os.path.expanduser("~/.config/lmg")
CONF = os.path.join(CONF_DIR, "settings.json")
VERSION = "1.1"
TEAM = "Minesword Team"

DEFAULTS = {
    "language": "auto",
    "light_mode": False,
    "sound_enabled": True,
    "sidebar_pinned": False,
    "sidebar_mode": "dock",        # dock | overlay
    "quick_apps": [
        ["Browser", "lmg-firefox", "web-browser"],
        ["Files", "thunar", "system-file-manager"],
        ["Terminal", "xfce4-terminal", "utilities-terminal"],
        ["Control Panel", "lmg-control-panel", "lmgos"],
        ["Editor", "mousepad", "text-editor"],
    ],
    "gaming_whitelist": ["xfce", "lmg", "thunar", "panel", "picom", "pipewire", "wireplumber", "nm-applet", "polkit", "lightdm", "Xorg"],
}

def load_settings():
    data = dict(DEFAULTS)
    try:
        with open(CONF) as f:
            data.update(json.load(f))
    except Exception:
        pass
    return data

def save_settings(data):
    try:
        os.makedirs(CONF_DIR, exist_ok=True)
        tmp = CONF + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, CONF)
    except Exception as e:
        print("lmg: cannot save settings:", e)

# ---------------- i18n ----------------
_STR, _EN = {}, {}

def _load(lang):
    try:
        with open(f"{SHARE}/i18n/{lang}.json", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def current_language(settings=None):
    s = settings or load_settings()
    lang = s.get("language", "auto")
    if lang == "auto":
        lang = (os.environ.get("LANG", "en")[:2] or "en")
    return lang

def init_i18n(settings=None):
    global _STR, _EN
    _EN = _load("en")
    lang = current_language(settings)
    _STR = _load(lang) if lang != "en" else _EN
    if lang in ("fa", "ar", "he", "ur"):
        Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)

_RLM = "\u200f"; _AR = re.compile("[\u0600-\u06ff\u0750-\u077f\ufb50-\ufdff\ufe70-\ufeff]"); _TAGS = re.compile(r"<[^>]*>|%\d*\$?[a-zA-Z]|\{[^}]*\}")
_RTLFIX = {}

def _rtl(s):
    """A Persian text that starts with an English word would be laid out left-to-right (Persian parts in the wrong order): start it with an invisible RTL mark."""
    r = _RTLFIX.get(s)
    if r is None:
        r = s
        if _AR.search(s) and not s.startswith(_RLM):
            for ch in _TAGS.sub("", s):
                if _AR.match(ch): break
                if ch.isascii() and ch.isalpha(): r = _RLM + s; break
        _RTLFIX[s] = r
    return r

def t(key):
    v = _STR.get(key) or _EN.get(key) or key
    return _rtl(v) if _STR is not _EN else v

# ---------------- misc ----------------
def load_css(path=None, screen=None):
    prov = Gtk.CssProvider()
    try:
        prov.load_from_path(path or "/usr/share/themes/LMG-Neon/gtk-3.0/gtk.css")
    except Exception as e:
        print("lmg: css error:", e)
    Gtk.StyleContext.add_provider_for_screen(screen or Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_USER)
    return prov

def is_live():
    try:
        return "boot=live" in open("/proc/cmdline").read()
    except Exception:
        return False

def run(cmd, timeout=15, shell=False):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, shell=shell)
        return (r.stdout or "").strip()
    except Exception:
        return ""

def human(n):
    n = float(n)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024

def admin_cmd(*args):
    return ["pkexec", HELPER] + list(args)

def spawn(cmd):
    try:
        subprocess.Popen(cmd, shell=isinstance(cmd, str), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except Exception as e:
        print("lmg: spawn failed", cmd, e)

def in_thread(fn, done=None):
    def work():
        try:
            res = fn()
        except Exception as e:
            res = e
        if done:
            GLib.idle_add(done, res)
    threading.Thread(target=work, daemon=True).start()

def stream_cmd(cmd, on_line, on_done):
    """Run cmd in a thread, feed lines to on_line(str) on the GTK thread."""
    def work():
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                GLib.idle_add(on_line, line.rstrip("\n"))
            p.wait()
            GLib.idle_add(on_done, p.returncode)
        except Exception as e:
            GLib.idle_add(on_line, f"error: {e}")
            GLib.idle_add(on_done, 1)
    threading.Thread(target=work, daemon=True).start()

def heading(text, sub=None):
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
    l = Gtk.Label(label=text, xalign=0); l.get_style_context().add_class("lmg-title"); box.pack_start(l, False, False, 0)
    if sub:
        s = Gtk.Label(label=sub, xalign=0, wrap=True); s.get_style_context().add_class("lmg-sub"); box.pack_start(s, False, False, 0)
    return box

def card(child=None):
    f = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
    f.get_style_context().add_class("lmg-card")
    if child is not None:
        f.pack_start(child, True, True, 0)
    return f

def play_sound(name):
    spawn(["/usr/lib/lmg/bin/lmg-sound", name])

def confirm(parent, text, detail=None):
    play_sound("permission")
    d = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=Gtk.MessageType.QUESTION,
                          buttons=Gtk.ButtonsType.YES_NO, text=text)
    if detail:
        d.format_secondary_text(detail)
    r = d.run(); d.destroy()
    return r == Gtk.ResponseType.YES

def page_base():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
    box.set_border_width(20)
    return box

class PageBase(Gtk.ScrolledWindow):
    """Every module is a scrollable page with a vertical box in self.box."""
    title_key = "x"
    def __init__(self, win=None):
        super().__init__()
        self.win = win
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.box = page_base()
        self.add(self.box)
    def on_show(self): pass
    def on_hide(self): pass


KB_LAYOUTS = {"fa": "us,ir", "en": "us"}


def apply_system_language(code, on_done=None):
    """Whole-system language, in one step: the sign-in language file, the keyboard layouts (Persian adds the Persian layout; Alt+Shift switches),
    and - through the helper - the system default and login screen. on_done(rc) is called when the helper has finished (sign out only after that)."""
    d = os.path.expanduser("~/.config/lmg"); os.makedirs(d, exist_ok=True)
    body = {"fa": "export LANG=fa_IR.UTF-8\nexport LANGUAGE=fa:en\nexport LC_ALL=\n",
            "en": "export LANG=en_US.UTF-8\nexport LANGUAGE=en_US:en\nexport LC_ALL=\n"}.get(code, "")
    with open(d + "/locale.conf", "w") as f: f.write(body)
    lay = KB_LAYOUTS.get(code)
    if lay:
        try:
            with open(d + "/keyboard.sh", "w") as f: f.write("#!/bin/sh\nsetxkbmap -layout %s -option grp:alt_shift_toggle\n" % lay)
            os.chmod(d + "/keyboard.sh", 0o755); spawn(["sh", d + "/keyboard.sh"])
        except Exception: pass
    if code in ("fa", "en"):
        try: stream_cmd(admin_cmd("locale-set", code), lambda s: None, lambda rc: on_done and on_done(rc))
        except Exception:
            if on_done: on_done(1)
    elif on_done: on_done(0)


# ---------------- protected system parts (cannot be ended or switched off by mistake) ----------------
PROTECTED_PROC = ["xfdesktop", "xfwm4", "xfce4-panel", "xfce4-session", "xfsettingsd", "xfconfd", "xfce4-notifyd", "whiskermenu",
                  "picom", "lightdm", "xorg", "xwayland", "systemd", "dbus", "pipewire", "wireplumber", "pulseaudio", "lxpolkit",
                  "polkit", "nm-applet", "networkmanager", "udisksd", "upowerd", "thunar --daemon", "tumblerd", "at-spi",
                  "gvfs", "/usr/lib/lmg/", "lmg-", "sidebar.py", "welcome_splash"]
PROTECTED_AUTOSTART = ("lmg-", "lxpolkit", "xfce", "polkit", "nm-applet", "pipewire", "wireplumber", "pulseaudio", "pulse", "at-spi",
                       "xdg-user-dirs", "gnome-keyring", "blueman", "print-applet")

def is_protected_proc(name, cmdline="", pid=None):
    if pid == 1:
        return True
    hay = ((name or "") + " " + (cmdline or "")).lower()
    return any(w in hay for w in PROTECTED_PROC)

def is_protected_autostart(fn):
    return fn.lower().startswith(PROTECTED_AUTOSTART)
