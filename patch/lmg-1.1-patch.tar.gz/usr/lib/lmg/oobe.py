#!/usr/bin/python3
"""LMG OS first-run welcome (after a fresh install or a flash upgrade). Full screen, above everything, keyboard captured:
no Alt+F4, no virtual terminals, no shortcuts. If the computer is switched off it simply comes back at the next sign-in,
until the last step is finished. Exit 0 = finished, 3 = the page never loaded (the launcher retries, then gives up)."""
import os, signal, subprocess, sys
sys.path.insert(0, "/usr/lib/lmg")
os.environ.setdefault("WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS", "1")
import gi
gi.require_version("Gtk", "3.0"); gi.require_version("Gdk", "3.0"); gi.require_version("WebKit2", "4.1")
from gi.repository import Gtk, Gdk, GLib, WebKit2
import oobe_server

DEV = os.environ.get("LMG_OOBE_DEV") == "1"
code = [3]


def sx(args):
    try: subprocess.run(args, timeout=10)
    except Exception: pass


def xkb_options():
    try:
        for l in subprocess.run(["setxkbmap", "-query"], capture_output=True, text=True).stdout.splitlines():
            if l.startswith("options:"): return l.split(":", 1)[1].strip()
    except Exception: pass
    return ""


def main():
    old_opts = xkb_options()
    if not DEV:                                                   # no Ctrl+Alt+F1..F6, no server-side shortcuts
        sx(["setxkbmap", "-option", "srvrkeys:none"] if not old_opts else ["setxkbmap", "-option", old_opts + ",srvrkeys:none"])
    def restore():
        sx(["setxkbmap", "-option", ""])
        if old_opts: sx(["setxkbmap", "-option", old_opts])
        k = os.path.join(oobe_server.CONF, "keyboard.sh")
        if os.path.exists(k): sx(["sh", k])
    def done():
        code[0] = 0; GLib.idle_add(Gtk.main_quit)
    srv = oobe_server.Server(on_done=done)

    scr = Gdk.Screen.get_default()
    win = Gtk.Window(); win.set_decorated(False)
    win.set_type_hint(Gdk.WindowTypeHint.SPLASHSCREEN)
    win.set_skip_taskbar_hint(True); win.set_skip_pager_hint(True); win.set_keep_above(True)
    win.set_default_size(scr.get_width(), scr.get_height()); win.move(0, 0)
    win.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.02, 0.03, 0.07, 1))
    win.connect("delete-event", lambda *a: True)                  # Alt+F4 / close request: ignored
    win.connect("key-press-event", lambda w, e: e.keyval == Gdk.KEY_Escape and DEV and (Gtk.main_quit() or True))
    ctx = WebKit2.WebContext.new_ephemeral()
    view = WebKit2.WebView.new_with_context(ctx)
    st = view.get_settings(); st.set_enable_developer_extras(False); st.set_media_playback_requires_user_gesture(False)
    st.set_hardware_acceleration_policy(WebKit2.HardwareAccelerationPolicy.ON_DEMAND)
    view.set_background_color(Gdk.RGBA(0.02, 0.03, 0.07, 1))
    view.connect("context-menu", lambda *a: True)
    view.connect("web-process-terminated", lambda v, r: (view.reload(), True)[1])
    view.connect("decide-policy", lambda v, d, t: (d.ignore(), True)[1] if t == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION else False)
    win.add(view); win.show_all(); win.fullscreen()

    def grab():
        try:
            gw = win.get_window()
            if gw is not None:
                seat = Gdk.Display.get_default().get_default_seat()
                seat.grab(gw, Gdk.SeatCapabilities.KEYBOARD, True, None, None, None)
        except Exception: pass
        return True
    def front():
        win.present(); win.fullscreen(); win.set_keep_above(True); grab(); return True
    GLib.timeout_add(250, lambda: (grab(), False)[1]); GLib.timeout_add(1000, front)     # panels or the sidebar mapped later must not get on top; a lost grab is taken back
    view.load_uri(srv.url)
    def watchdog():
        if not srv.ready: code[0] = 3; Gtk.main_quit()
        return False
    GLib.timeout_add_seconds(30, watchdog)
    GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGTERM, lambda: (Gtk.main_quit(), False)[1]) if DEV else None
    Gtk.main()
    try: Gdk.Display.get_default().get_default_seat().ungrab()
    except Exception: pass
    try:
        win.hide(); win.destroy()                       # the full-screen window must disappear now, not when the process ends
        while Gtk.events_pending(): Gtk.main_iteration()
    except Exception: pass
    restore()
    try: srv.stop()
    except Exception: pass
    return code[0]


if __name__ == "__main__":
    rc = main()
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(rc)                                        # nothing may keep the process (and a black screen) alive
