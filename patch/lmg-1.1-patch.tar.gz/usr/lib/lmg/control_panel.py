#!/usr/bin/python3
"""LMG OS Control Panel: 15% module list on the left, 85% content on the right."""
import importlib, os, sys
sys.path.insert(0, "/usr/lib/lmg"); sys.path.insert(0, "/usr/lib/lmg/modules")
from lmgcommon import *
from gi.repository import GdkPixbuf

MODULES = ["welcome", "update", "upgrade", "ram", "taskmgr", "hardware", "test", "disk", "gaming"]
ICONS = {"welcome": "user-home-symbolic", "update": "software-update-available-symbolic", "upgrade": "go-up-symbolic", "ram": "computer-symbolic", "taskmgr": "utilities-system-monitor-symbolic",
         "hardware": "drive-harddisk-symbolic", "test": "emblem-ok-symbolic", "disk": "drive-multidisk-symbolic",
         "gaming": "input-gaming-symbolic"}

class Win(Gtk.Window):
    def __init__(self, start="welcome"):
        super().__init__(title=t("app_title"))
        self.set_default_size(1040, 660); self.set_icon_name("lmg-control-panel")
        self.pages, self.btns, self.cur = {}, {}, None
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL); self.add(paned); self.paned = paned
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); side.get_style_context().add_class("lmg-side")
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_size(SHARE + "/branding/logo-main.png", 72, 72)
            img = Gtk.Image.new_from_pixbuf(pb); img.set_margin_top(14); img.set_margin_bottom(6); side.pack_start(img, False, False, 0)
        except Exception: pass
        name = Gtk.Label(label="LMG OS"); name.get_style_context().add_class("lmg-title"); side.pack_start(name, False, False, 0)
        side.pack_start(Gtk.Box(), False, False, 6)
        for m in MODULES:
            b = Gtk.Button(); b.get_style_context().add_class("lmg-nav")
            h = Gtk.Box(spacing=8); h.pack_start(Gtk.Image.new_from_icon_name(ICONS[m], Gtk.IconSize.BUTTON), False, False, 0)
            l = Gtk.Label(label=t(m), xalign=0); l.set_ellipsize(3); h.pack_start(l, True, True, 0); b.add(h)
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.connect("clicked", lambda _b, mm=m: self.show_page(mm)); side.pack_start(b, False, False, 0); self.btns[m] = b
        side.pack_start(Gtk.Box(), True, True, 0)
        tm = Gtk.Label(label=f"{t('team')}\n{t('version')} {VERSION}"); tm.get_style_context().add_class("lmg-team"); tm.set_justify(Gtk.Justification.CENTER)
        tm.set_margin_bottom(12); side.pack_start(tm, False, False, 0)
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=180)
        paned.pack1(side, False, False); paned.pack2(self.stack, True, False)
        self.connect("size-allocate", self.on_size)
        self.show_all(); self.show_page(start)
        self._fade()

    def _fade(self):
        if load_settings().get("light_mode"): return
        self.set_opacity(0.0); self._t0 = GLib.get_monotonic_time()
        def step():
            p = min(1.0, (GLib.get_monotonic_time() - self._t0) / 260000.0); self.set_opacity(p)
            return p < 1.0
        GLib.timeout_add(16, step)

    def on_size(self, w, alloc):
        pos = max(168, int(alloc.width * 0.15))
        if abs(self.paned.get_position() - pos) > 2: self.paned.set_position(pos)

    def show_page(self, m):
        if m not in MODULES: m = "welcome"
        if self.cur and self.cur in self.pages: self.pages[self.cur].on_hide()
        if m not in self.pages:
            try:
                page = importlib.import_module(m).Page(self)
            except Exception as e:
                page = PageBase(self); page.box.pack_start(Gtk.Label(label=f"{m}: {e}"), False, False, 0)
            page.show_all(); self.pages[m] = page; self.stack.add_named(page, m)
        self.stack.set_visible_child_name(m); self.pages[m].on_show(); self.cur = m
        for k, b in self.btns.items():
            ctx = b.get_style_context(); (ctx.add_class if k == m else ctx.remove_class)("active")

def main():
    s = load_settings(); init_i18n(s); load_css()
    start = sys.argv[1] if len(sys.argv) > 1 else "welcome"
    if start == "settings": os.execv("/usr/local/bin/lmg-settings", ["lmg-settings"])
    w = Win(start); w.connect("destroy", Gtk.main_quit); Gtk.main()

if __name__ == "__main__":
    main()
