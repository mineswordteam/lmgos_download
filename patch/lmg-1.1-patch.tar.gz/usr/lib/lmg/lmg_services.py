#!/usr/bin/python3
"""Minesword Services: the system tools of LMG OS in one app (live persistence, USB maker, cleaning, drivers, repair,
services, firewall, backup). Everything privileged goes through lmg-helper (pkexec)."""
import json, os, re, subprocess, sys
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *


class ToolPage(PageBase):
    """A page with a heading, optional extra widgets, action buttons and a log."""
    def __init__(self, win, title_key, sub_key):
        super().__init__(win)
        self.busy = False
        self.box.pack_start(heading(t(title_key), t(sub_key)), False, False, 0)
        self.extra = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.box.pack_start(card(self.extra), False, False, 0)
        self.bar = Gtk.Box(spacing=8); self.box.pack_start(self.bar, False, False, 0)
        self.log = Gtk.TextView(editable=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        ls = Gtk.ScrolledWindow(); ls.set_size_request(-1, 170); ls.add(self.log); self.box.pack_start(ls, True, True, 0)
        self.btns = []

    def button(self, key, cb, danger=False):
        b = Gtk.Button(label=t(key)); b.connect("clicked", cb)
        if danger: b.get_style_context().add_class("destructive-action")
        self.bar.pack_start(b, False, False, 0); self.btns.append(b); return b

    def action(self, key, args, confirm_key=None, danger=False):
        def go(*_):
            if confirm_key and not confirm(self.get_toplevel(), t(confirm_key)): return
            self.run_admin(args)
        return self.button(key, go, danger)

    def say(self, line):
        b = self.log.get_buffer(); b.insert(b.get_end_iter(), line + "\n"); self.log.scroll_mark_onscreen(b.get_insert())

    def set_busy(self, on):
        self.busy = on
        for b in self.btns: b.set_sensitive(not on)

    def run_admin(self, args, after=None):
        if self.busy: return
        self.set_busy(True); self.say("$ " + " ".join(args))
        def done(rc):
            self.set_busy(False)
            self.say(t("svc_done") if rc == 0 else t("svc_failed") + " (%s)" % rc)
            if after: after(rc)
            self.on_show()
        stream_cmd(admin_cmd(*args), self.say, done)

    def run_user(self, cmd, after=None):
        if self.busy: return
        self.set_busy(True); self.say("$ " + " ".join(cmd))
        def done(rc):
            self.set_busy(False); self.say(t("svc_done") if rc == 0 else t("svc_failed") + " (%s)" % rc)
            if after: after(rc)
        stream_cmd(cmd, self.say, done)

    def label(self, text=""):
        l = Gtk.Label(label=text, xalign=0, wrap=True); self.extra.pack_start(l, False, False, 0); return l


# ---------- live persistence ----------
class PersistPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_persist", "svc_persist_sub")
        self.state = self.label()
        r = Gtk.Box(spacing=10); r.pack_start(Gtk.Label(label=t("svc_persist_size"), xalign=0), False, False, 0)
        self.size = Gtk.ComboBoxText()
        for k, v in (("all", t("svc_all_free")), ("1024", "1 GB"), ("4096", "4 GB"), ("8192", "8 GB")): self.size.append(k, v)
        self.size.set_active_id("all"); r.pack_start(self.size, False, False, 0); self.extra.pack_start(r, False, False, 0)
        self.b_create = self.button("svc_persist_create", self.create)
        self.b_remove = self.button("svc_persist_remove", self.remove, danger=True)
        self.on_show()

    def on_show(self):
        if not is_live():
            self.state.set_text(t("svc_persist_notlive")); self.b_create.set_sensitive(False); self.b_remove.set_sensitive(False); return
        have = bool(run(["blkid", "-L", "persistence"]))
        active = os.path.ismount("/run/live/persistence") or "persistence" in open("/proc/cmdline").read().split() and os.path.isdir("/run/live/persistence")
        self.state.set_text(t("svc_persist_active") if have and active else t("svc_persist_next") if have else t("svc_persist_none"))
        if not self.busy:
            self.b_create.set_sensitive(not have); self.b_remove.set_sensitive(have)

    def create(self, *_):
        if confirm(self.get_toplevel(), t("svc_persist_confirm")): self.run_admin(["persist-create", self.size.get_active_id()])

    def remove(self, *_):
        if confirm(self.get_toplevel(), t("svc_persist_rm_confirm")): self.run_admin(["persist-remove"])


# ---------- live USB maker ----------
class UsbPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_usb", "svc_usb_sub")
        self.iso = ""
        self.iso_l = self.label(t("svc_usb_noiso"))
        pick = Gtk.Button(label=t("svc_usb_pick")); pick.connect("clicked", self.pick_iso); self.extra.pack_start(pick, False, False, 0)
        r = Gtk.Box(spacing=10); r.pack_start(Gtk.Label(label=t("svc_usb_drive"), xalign=0), False, False, 0)
        self.drv = Gtk.ComboBoxText(); r.pack_start(self.drv, True, True, 0)
        rf = Gtk.Button(label=t("svc_refresh")); rf.connect("clicked", lambda *_: self.on_show()); r.pack_start(rf, False, False, 0)
        self.extra.pack_start(r, False, False, 0)
        self.button("svc_usb_write", self.write, danger=True)
        self.on_show()

    def on_show(self):
        self.drv.remove_all()
        try:
            for d in json.loads(run(["lsblk", "-J", "-d", "-o", "PATH,SIZE,MODEL,TRAN,RM,TYPE"]) or "{}").get("blockdevices", []):
                if d.get("type") == "disk" and (d.get("tran") == "usb" or d.get("rm") in (True, "1", 1)):
                    self.drv.append(d["path"], "%s  %s  %s" % (d["path"], d.get("size") or "", (d.get("model") or "").strip()))
        except Exception: pass
        if self.drv.get_model() and len(self.drv.get_model()): self.drv.set_active(0)

    def pick_iso(self, *_):
        d = Gtk.FileChooserNative(title=t("svc_usb_pick"), action=Gtk.FileChooserAction.OPEN, transient_for=self.get_toplevel())
        f = Gtk.FileFilter(); f.set_name("ISO"); f.add_pattern("*.iso"); d.add_filter(f)
        if d.run() == Gtk.ResponseType.ACCEPT:
            self.iso = d.get_filename(); self.iso_l.set_text(self.iso)

    def write(self, *_):
        dev = self.drv.get_active_id()
        if not self.iso or not dev: self.say(t("svc_usb_need")); return
        if confirm(self.get_toplevel(), t("svc_usb_confirm").format(dev), t("svc_usb_confirm2")):
            self.run_admin(["usb-write", self.iso, dev])


# ---------- cleaning ----------
class CleanPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_clean", "svc_clean_sub")
        for key, args in (("svc_clean_apt", ["clean-apt"]), ("svc_clean_auto", ["autoremove"]), ("svc_clean_journal", ["clean-journal"]), ("svc_clean_cache", ["drop-caches"])):
            self.action(key, args)
        self.button("svc_clean_user", self.user_clean)

    def user_clean(self, *_):
        home = os.path.expanduser("~")
        self.run_user(["sh", "-c", "rm -rf '%s/.cache/thumbnails'/* 2>/dev/null; gio trash --empty 2>/dev/null; echo ok" % home])


# ---------- drivers ----------
class DriversPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_drivers", "svc_drivers_sub")
        gpu = [l.split(": ", 1)[-1] for l in run(["lspci", "-nn"]).splitlines() if re.search(r"VGA|3D controller|Display", l)]
        self.label(t("svc_gpu") + ": " + ("; ".join(gpu) or "?"))
        for key, arg in (("svc_drv_nvidia", "nvidia"), ("svc_drv_amd", "amd"), ("svc_drv_intel", "intel"), ("svc_drv_wifi", "wifi"), ("svc_drv_printer", "printer")):
            self.action(key, ["driver-install", arg], "svc_install_confirm")
        self.action("svc_repos", ["repos-enable"], "svc_repos_confirm")


# ---------- boot repair ----------
class BootPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_boot", "svc_boot_sub")
        self.action("svc_boot_repair", ["boot-repair"], "svc_boot_confirm", danger=True)


# ---------- services ----------
class ServicesPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_services", "svc_services_sub")
        self.store = Gtk.ListStore(str, str, str)
        self.entry = Gtk.SearchEntry(placeholder_text=t("svc_search")); self.entry.connect("search-changed", lambda *_: self.on_show())
        self.extra.pack_start(self.entry, False, False, 0)
        self.tv = Gtk.TreeView(model=self.store)
        for i, title in enumerate((t("svc_col_name"), t("svc_col_boot"), t("svc_col_now"))):
            c = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=i); c.set_resizable(True); c.set_expand(i == 0); self.tv.append_column(c)
        sw = Gtk.ScrolledWindow(); sw.set_size_request(-1, 230); sw.add(self.tv); self.extra.pack_start(sw, True, True, 0)
        for key, act in (("svc_enable", "enable"), ("svc_disable", "disable"), ("svc_start", "start"), ("svc_stop", "stop")):
            self.button(key, lambda _b, a=act: self.act(a))
        self.on_show()

    def on_show(self):
        q = self.entry.get_text().strip().lower() if hasattr(self, "entry") else ""
        active = set(l.split()[0] for l in run(["systemctl", "list-units", "--type=service", "--state=active", "--no-legend", "--plain"]).splitlines() if l.split())
        rows = []
        for l in run(["systemctl", "list-unit-files", "--type=service", "--no-legend", "--plain"]).splitlines():
            f = l.split()
            if len(f) >= 2 and f[1] in ("enabled", "disabled") and (not q or q in f[0].lower()):
                rows.append((f[0], f[1], t("svc_running") if f[0] in active else "-"))
        self.store.clear()
        for r in sorted(rows)[:400]: self.store.append(list(r))

    def act(self, what):
        m, p = self.tv.get_selection().get_selected()
        if not p: self.say(t("svc_pick_one")); return
        unit = m[p][0]
        def after(rc):
            if rc == 5: self.say(t("svc_protected"))
        self.run_admin(["service-set", what, unit], after)


# ---------- firewall ----------
class FirewallPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_firewall", "svc_firewall_sub")
        self.state = self.label()
        self.action("svc_fw_on", ["firewall", "on"]); self.action("svc_fw_off", ["firewall", "off"], "svc_fw_off_confirm")
        self.on_show()

    def on_show(self):
        on = run(["systemctl", "is-active", "ufw"]).strip() == "active"
        self.state.set_text(t("svc_fw_is_on") if on else t("svc_fw_is_off"))


# ---------- backup ----------
class BackupPage(ToolPage):
    def __init__(self, win):
        super().__init__(win, "svc_backup", "svc_backup_sub")
        self.dest = ""
        self.dest_l = self.label(t("svc_backup_nodest"))
        pick = Gtk.Button(label=t("svc_backup_pick")); pick.connect("clicked", self.pick); self.extra.pack_start(pick, False, False, 0)
        self.button("svc_backup_now", self.backup); self.button("svc_backup_restore", self.restore)

    def pick(self, *_):
        d = Gtk.FileChooserNative(title=t("svc_backup_pick"), action=Gtk.FileChooserAction.SELECT_FOLDER, transient_for=self.get_toplevel())
        if d.run() == Gtk.ResponseType.ACCEPT:
            self.dest = d.get_filename(); self.dest_l.set_text(self.dest)

    def target(self): return os.path.join(self.dest, "LMG-Backup-" + os.environ.get("USER", "user"))

    def backup(self, *_):
        if not self.dest: self.say(t("svc_backup_nodest")); return
        os.makedirs(self.target(), exist_ok=True)
        self.run_user(["rsync", "-a", "--exclude=.cache", "--exclude=.local/share/Trash", "--exclude=LMG-Backup-*", os.path.expanduser("~") + "/", self.target() + "/"])

    def restore(self, *_):
        if not self.dest or not os.path.isdir(self.target()): self.say(t("svc_backup_none")); return
        if confirm(self.get_toplevel(), t("svc_backup_restore_confirm")):
            self.run_user(["rsync", "-a", self.target() + "/", os.path.expanduser("~") + "/"])


# ---------- LMG tools ----------
class LinksPage(PageBase):
    def __init__(self, win):
        super().__init__(win)
        self.box.pack_start(heading(t("svc_tools"), t("svc_tools_sub")), False, False, 0)
        grid = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=3, column_spacing=10, row_spacing=10)
        for key, icon, cmd in (("svc_l_packages", "lmg-packages", ["lmg-packages"]), ("svc_l_settings", "lmg-settings", ["lmg-settings"]),
                               ("svc_l_panel", "lmg-control-panel", ["lmg-control-panel"]), ("svc_l_task", "utilities-system-monitor", ["lmg-control-panel", "taskmgr"]),
                               ("svc_l_disk", "drive-harddisk", ["lmg-control-panel", "disk"]), ("svc_l_upgrade", "lmg-upgrade", ["lmg-control-panel", "upgrade"]),
                               ("svc_l_gaming", "applications-games", ["lmg-control-panel", "gaming"]), ("svc_l_terminal", "utilities-terminal", ["xfce4-terminal"])):
            b = Gtk.Button(); b.set_relief(Gtk.ReliefStyle.NONE)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            v.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.DIALOG), False, False, 0); v.pack_start(Gtk.Label(label=t(key)), False, False, 0)
            b.add(v); b.connect("clicked", lambda _b, c=cmd: spawn(c)); grid.add(b)
        self.box.pack_start(card(grid), False, False, 0)


TOOLS = [("svc_tools", "applications-system-symbolic", LinksPage), ("svc_persist", "media-removable-symbolic", PersistPage),
         ("svc_usb", "drive-removable-media-symbolic", UsbPage), ("svc_clean", "edit-clear-all-symbolic", CleanPage),
         ("svc_drivers", "video-display-symbolic", DriversPage), ("svc_boot", "system-reboot-symbolic", BootPage),
         ("svc_services", "preferences-system-symbolic", ServicesPage), ("svc_firewall", "security-high-symbolic", FirewallPage),
         ("svc_backup", "document-save-symbolic", BackupPage)]


class Win(Gtk.Window):
    def __init__(self, start=0):
        super().__init__(title=t("svc_app")); self.set_default_size(960, 660); self.set_icon_name("minesword-services")
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL); self.add(paned)
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); side.get_style_context().add_class("lmg-side")
        title = Gtk.Label(label=t("svc_app")); title.get_style_context().add_class("lmg-title"); title.set_margin_top(16); title.set_margin_bottom(10)
        side.pack_start(title, False, False, 0)
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=150); self.btns = {}; self.pages = {}
        for key, icon, cls in TOOLS:
            b = Gtk.Button(); b.get_style_context().add_class("lmg-nav"); b.set_relief(Gtk.ReliefStyle.NONE)
            h = Gtk.Box(spacing=8); h.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON), False, False, 0)
            h.pack_start(Gtk.Label(label=t(key), xalign=0), True, True, 0); b.add(h)
            b.connect("clicked", lambda _b, k=key: self.show(k)); side.pack_start(b, False, False, 0); self.btns[key] = b
            page = cls(self); page.show_all(); self.stack.add_named(page, key); self.pages[key] = page
        paned.pack1(side, False, False); paned.pack2(self.stack, True, False); paned.set_position(230)
        self.show_all(); self.show(TOOLS[start][0] if isinstance(start, int) else start)

    def show(self, k):
        self.stack.set_visible_child_name(k)
        try: self.pages[k].on_show()
        except Exception: pass
        for n, b in self.btns.items():
            (b.get_style_context().add_class if n == k else b.get_style_context().remove_class)("active")


def main():
    s = load_settings(); init_i18n(s); load_css()
    start = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] in dict((k, 1) for k, _, _ in TOOLS) else TOOLS[0][0]
    w = Win(start); w.connect("destroy", Gtk.main_quit); Gtk.main()


if __name__ == "__main__":
    main()
