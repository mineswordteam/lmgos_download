#!/usr/bin/python3
"""LMG Connector server: lets the Android app see and control this desktop over the local network / phone hotspot.

Protocol (version 1), over wss://<ip>:47111/ws (TLS, self-signed certificate):
  server -> {"t":"hello","nonce":hex,"name":host,"v":1}
  client -> {"t":"auth","mac":hex}     mac = HMAC-SHA256(key=pairing code, msg=nonce + sha256(server certificate DER) as lower-case hex)
  server -> {"t":"ok","w":W,"h":H,"name":host}  or  {"t":"fail","why":"code"|"locked"}
  server -> binary messages: a JPEG per screen frame (starts with FF D8), or sound: 'A' + raw PCM (signed 16 bit little endian, stereo, 44100 Hz)
  client -> {"t":"audio","on":true|false}     (sound is off until the phone asks for it)
  client -> {"t":"move","dx":,"dy":} {"t":"abs","x":0..1,"y":0..1} {"t":"click","b":1|2|3} {"t":"down","b":} {"t":"up","b":}
            {"t":"scroll","n":int} {"t":"key","k":"Return","m":["ctrl","alt","shift","super"]} {"t":"text","s":"..."} {"t":"quality","w":px,"fps":n,"q":2..31}
The pairing code is shown on the desktop; binding the HMAC to the certificate fingerprint stops a man in the middle who does not know the code.
UDP 47110: answer to b"LMGCONNECTOR?" so the phone can find the computer.  HTTP 47112: serves the Android app (.apk) if it is installed."""
import asyncio, base64, hashlib, hmac, json, os, re, secrets, signal, socket, ssl, struct, subprocess, sys, time

PORT, UDP_PORT, HTTP_PORT = 47111, 47110, 47112
APK = os.environ.get("LMG_CONNECTOR_APK", "/usr/share/lmg/connector/lmg-connector.apk")
FAKE = os.environ.get("LMG_CONNECTOR_FAKE") == "1"          # tests: no screen, no input, events go to a log file
STATE_DIR = os.environ.get("LMG_CONNECTOR_DIR", os.path.expanduser("~/.config/lmg/connector"))
STATUS = os.environ.get("LMG_CONNECTOR_STATUS") or os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), "lmg-connector-%d.json" % os.getuid())
GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
KEYSYM = re.compile(r"^[A-Za-z0-9_]{1,40}$")
MODS = {"ctrl": "ctrl", "alt": "alt", "shift": "shift", "super": "super"}


def log(*a): print("[connector]", *a, flush=True)


# ------------------------------------------------------------------ certificate and pairing
def ensure_cert():
    os.makedirs(STATE_DIR, exist_ok=True); os.chmod(STATE_DIR, 0o700)
    crt, key = os.path.join(STATE_DIR, "cert.pem"), os.path.join(STATE_DIR, "key.pem")
    if not (os.path.exists(crt) and os.path.exists(key)):
        subprocess.run(["openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1", "-nodes", "-keyout", key,
                        "-out", crt, "-days", "3650", "-subj", "/CN=lmg-connector"], check=True, capture_output=True)
        os.chmod(key, 0o600)
    der = ssl.PEM_cert_to_DER_cert(open(crt).read())
    return crt, key, hashlib.sha256(der).hexdigest()


def new_code(): return "%06d" % secrets.randbelow(10**6)


def mac_for(code, nonce, fp): return hmac.new(code.encode(), (nonce + fp).encode(), hashlib.sha256).hexdigest()


def local_ips():
    ips = set()
    try:
        for line in subprocess.run(["ip", "-4", "-o", "addr", "show", "scope", "global"], capture_output=True, text=True).stdout.splitlines():
            ips.add(line.split()[3].split("/")[0])
    except Exception: pass
    return sorted(ips)


# ------------------------------------------------------------------ minimal WebSocket (RFC 6455, no extensions, no fragmentation)
async def ws_handshake(r, w):
    head = await asyncio.wait_for(r.readuntil(b"\r\n\r\n"), 10)
    lines = head.decode("latin1").split("\r\n"); req = lines[0].split()
    h = {l.split(":", 1)[0].strip().lower(): l.split(":", 1)[1].strip() for l in lines[1:] if ":" in l}
    if len(req) < 2 or req[1].split("?")[0] != "/ws" or "websocket" not in h.get("upgrade", "").lower() or "sec-websocket-key" not in h:
        w.write(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"); await w.drain(); return False
    acc = base64.b64encode(hashlib.sha1((h["sec-websocket-key"] + GUID).encode()).digest()).decode()
    w.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: %s\r\n\r\n" % acc).encode())
    await w.drain(); return True


async def ws_read(r):
    """Returns (opcode, payload). Handles masking and the three length forms."""
    b1, b2 = await r.readexactly(2)
    op, masked, n = b1 & 0x0F, b2 & 0x80, b2 & 0x7F
    if n == 126: n = struct.unpack(">H", await r.readexactly(2))[0]
    elif n == 127: n = struct.unpack(">Q", await r.readexactly(8))[0]
    if n > 1 << 20: raise ValueError("frame too large")
    mask = await r.readexactly(4) if masked else b""
    data = await r.readexactly(n) if n else b""
    if masked: data = bytes(c ^ mask[i & 3] for i, c in enumerate(data))
    return op, data


def ws_frame(op, data):
    n = len(data)
    head = bytes([0x80 | op]) + (bytes([n]) if n < 126 else b"\x7e" + struct.pack(">H", n) if n < 65536 else b"\x7f" + struct.pack(">Q", n))
    return head + data


# ------------------------------------------------------------------ screen capture (ffmpeg x11grab -> MJPEG) and input (xdotool)
def screen_size():
    if FAKE: return 1280, 720
    try:
        m = re.search(r"dimensions:\s+(\d+)x(\d+)", subprocess.run(["xdpyinfo"], capture_output=True, text=True).stdout)
        return int(m.group(1)), int(m.group(2))
    except Exception: return 1280, 720


class Capture:
    def __init__(self, width=960, fps=12, q=6):
        self.width, self.fps, self.q, self.proc = width, fps, q, None

    async def frames(self):
        if FAKE:
            n = 0
            while True:
                n += 1; yield b"\xff\xd8FAKE%d\xff\xd9" % n; await asyncio.sleep(0.05)
        sw, sh = screen_size(); w = min(self.width, sw)
        cmd = ["ffmpeg", "-loglevel", "error", "-f", "x11grab", "-draw_mouse", "1", "-framerate", str(self.fps), "-video_size", "%dx%d" % (sw, sh),
               "-i", os.environ.get("DISPLAY", ":0"), "-vf", "scale=%d:-2" % w, "-q:v", str(self.q), "-f", "mjpeg", "-"]
        self.proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
        buf = b""
        while True:
            chunk = await self.proc.stdout.read(65536)
            if not chunk: break
            buf += chunk
            while True:
                a = buf.find(b"\xff\xd8")
                if a < 0: buf = b""; break
                b = buf.find(b"\xff\xd9", a + 2)
                if b < 0: buf = buf[a:]; break
                yield buf[a:b + 2]; buf = buf[b + 2:]

    def stop(self):
        try:
            if self.proc and self.proc.returncode is None: self.proc.kill()
        except Exception: pass


class AudioCapture:
    """What the computer plays (the monitor of the default output) as raw PCM: ffmpeg through PulseAudio / PipeWire-Pulse."""
    RATE, CH, CHUNK = 44100, 2, 4096

    def __init__(self): self.proc = None; self.err = ""

    async def _watch(self):
        while True:
            line = await self.proc.stderr.readline()
            if not line: break
            self.err = line.decode(errors="replace").strip()[:200]

    async def chunks(self):
        if FAKE:
            while True:
                yield b"\x00" * self.CHUNK; await asyncio.sleep(0.02)
        try:
            sink = subprocess.run(["pactl", "get-default-sink"], capture_output=True, text=True, timeout=5).stdout.strip()
        except Exception: sink = ""
        src = sink + ".monitor" if sink else "@DEFAULT_MONITOR@"
        cmd = ["ffmpeg", "-loglevel", "error", "-fflags", "nobuffer", "-f", "pulse", "-i", src, "-ac", str(self.CH), "-ar", str(self.RATE), "-f", "s16le", "-"]
        self.src = src
        self.proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        asyncio.create_task(self._watch())
        while True:
            try: b = await self.proc.stdout.readexactly(self.CHUNK)
            except asyncio.IncompleteReadError: break
            yield b

    def stop(self):
        try:
            if self.proc and self.proc.returncode is None: self.proc.kill()
        except Exception: pass


class Input:
    """Mouse and keyboard through xdotool. Everything the phone sends is validated: no shell, fixed command shapes."""
    def __init__(self):
        self.dx = self.dy = 0; self.log = os.environ.get("LMG_CONNECTOR_LOG")
        self.sw, self.sh = screen_size()

    async def _x(self, *args):
        if FAKE:
            if self.log: open(self.log, "a").write(" ".join(str(a) for a in args) + "\n")
            return
        try:
            p = await asyncio.create_subprocess_exec("xdotool", *[str(a) for a in args], stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            await asyncio.wait_for(p.wait(), 5)
        except Exception as e: log("xdotool:", e)

    async def flush_move(self):
        dx, dy, self.dx, self.dy = self.dx, self.dy, 0, 0
        if dx or dy: await self._x("mousemove_relative", "--", dx, dy)

    async def handle(self, m):
        t = m.get("t")
        if t == "move":
            self.dx += int(max(-2000, min(2000, float(m.get("dx", 0))))); self.dy += int(max(-2000, min(2000, float(m.get("dy", 0)))))
        elif t == "abs":
            x = int(max(0.0, min(1.0, float(m.get("x", 0)))) * (self.sw - 1)); y = int(max(0.0, min(1.0, float(m.get("y", 0)))) * (self.sh - 1))
            await self._x("mousemove", x, y)
        elif t in ("click", "down", "up"):
            b = int(m.get("b", 1)); b = b if b in (1, 2, 3) else 1
            await self._x({"click": "click", "down": "mousedown", "up": "mouseup"}[t], b)
        elif t == "scroll":
            n = int(max(-30, min(30, int(m.get("n", 0)))))
            if n: await self._x("click", "--repeat", abs(n), 4 if n < 0 else 5)       # button 4 = up, 5 = down; negative n = scroll up
        elif t == "key":
            k = str(m.get("k", ""))
            if not KEYSYM.match(k): return
            mods = [MODS[x] for x in m.get("m", []) if x in MODS]
            await self._x("key", "+".join(mods + [k]))
        elif t == "text":
            s = str(m.get("s", ""))[:400]
            if s: await self._x("type", "--delay", 4, "--", s)


# ------------------------------------------------------------------ server
class Server:
    def __init__(self):
        self.crt, self.key, self.fp = ensure_cert()
        self.code = new_code(); self.fails = {}; self.client = None; self.session = None; self.name = socket.gethostname()
        self.started = int(time.time()); self.audio_msg = "off"

    def status(self):
        d = {"pid": os.getpid(), "code": self.code, "ips": local_ips(), "port": PORT, "name": self.name, "client": self.client,
             "http": HTTP_PORT if os.path.exists(APK) else 0, "fp": self.fp[:16], "started": self.started, "audio": self.audio_msg}
        tmp = STATUS + ".tmp"
        with open(tmp, "w") as f: json.dump(d, f)
        os.replace(tmp, STATUS)

    def locked(self, ip): return self.fails.get(ip, (0, 0))[0] >= 5 and time.time() < self.fails[ip][1]

    def fail(self, ip):
        n = self.fails.get(ip, (0, 0))[0] + 1
        self.fails[ip] = (n, time.time() + 60)

    async def handle(self, r, w):
        peer = w.get_extra_info("peername") or ("?", 0); ip = peer[0]
        try:
            if not await ws_handshake(r, w): return
            nonce = secrets.token_hex(16)
            await self.send_text(w, {"t": "hello", "nonce": nonce, "name": self.name, "v": 1})
            if self.locked(ip):
                await self.send_text(w, {"t": "fail", "why": "locked"}); return
            op, data = await asyncio.wait_for(ws_read(r), 15)
            msg = json.loads(data.decode()) if op == 1 else {}
            if msg.get("t") != "auth" or not hmac.compare_digest(str(msg.get("mac", "")), mac_for(self.code, nonce, self.fp)):
                self.fail(ip); log("wrong code from", ip); await self.send_text(w, {"t": "fail", "why": "code"}); return
            self.fails.pop(ip, None)
            if self.session: self.session.cancel()                      # a new phone replaces the old session
            self.session = asyncio.current_task(); self.client = ip; self.status()
            sw, sh = screen_size()
            await self.send_text(w, {"t": "ok", "w": sw, "h": sh, "name": self.name})
            log("connected:", ip)
            await self.run_session(r, w)
        except (asyncio.IncompleteReadError, ConnectionError, asyncio.TimeoutError, asyncio.CancelledError, ssl.SSLError, ValueError, json.JSONDecodeError) as e:
            pass
        except Exception as e: log("session error:", repr(e))
        finally:
            if self.client == ip and self.session is asyncio.current_task(): self.client = None; self.session = None; self.status(); log("disconnected:", ip)
            try: w.close()
            except Exception: pass

    async def send_text(self, w, obj):
        w.write(ws_frame(1, json.dumps(obj).encode())); await w.drain()

    async def run_session(self, r, w):
        cap, inp = Capture(), Input(); latest = [None]; ev = asyncio.Event(); wlock = asyncio.Lock()
        async def grab():
            while True:
                async for f in cap.frames(): latest[0] = f; ev.set()
                await asyncio.sleep(0.5)                                  # capture ended (e.g. quality change): start again
        async def pump():
            while True:
                await ev.wait(); ev.clear(); f = latest[0]
                if f is not None:
                    async with wlock: w.write(ws_frame(2, f)); await w.drain()
        async def mover():
            while True:
                await asyncio.sleep(0.03); await inp.flush_move()
        aud = AudioCapture(); audio_task = [None]
        async def sound():
            while True:
                self.audio_msg = "starting"; self.status()
                async for chunk in aud.chunks():
                    if self.audio_msg != "ok": self.audio_msg = "ok"; self.status()
                    if w.transport.get_write_buffer_size() > 200000: continue       # the phone is behind: drop sound instead of delaying it
                    async with wlock: w.write(ws_frame(2, b"A" + chunk)); await w.drain()
                self.audio_msg = "no sound: " + (aud.err or "capture ended") + " (source %s)" % getattr(aud, "src", "?"); self.status(); log(self.audio_msg)
                await asyncio.sleep(3)                                              # no sound source yet: try again
        tasks = [asyncio.create_task(x()) for x in (grab, pump, mover)]
        try:
            while True:
                op, data = await ws_read(r)
                if op == 8: break
                if op == 9:
                    async with wlock: w.write(ws_frame(10, data)); await w.drain()
                elif op == 1:
                    m = json.loads(data.decode())
                    if m.get("t") == "audio":
                        if m.get("on") and audio_task[0] is None: audio_task[0] = asyncio.create_task(sound())
                        elif not m.get("on") and audio_task[0] is not None: audio_task[0].cancel(); audio_task[0] = None; aud.stop()
                    elif m.get("t") == "quality":
                        cap.width = int(max(320, min(1920, int(m.get("w", cap.width))))); cap.fps = int(max(2, min(30, int(m.get("fps", cap.fps))))); cap.q = int(max(2, min(31, int(m.get("q", cap.q)))))
                        cap.stop()
                    else: await inp.handle(m)
        finally:
            for t in tasks: t.cancel()
            if audio_task[0] is not None: audio_task[0].cancel()
            cap.stop(); aud.stop()

    async def http(self, r, w):
        try:
            head = await asyncio.wait_for(r.readuntil(b"\r\n\r\n"), 5); path = head.split(b" ")[1].decode("latin1") if b" " in head else "/"
            if path in ("/", "/lmg-connector.apk") and os.path.exists(APK):
                if path == "/":
                    body = b"<meta name=viewport content='width=device-width'><h2>LMG Connector</h2><p><a href='/lmg-connector.apk'>Download the Android app</a></p>"
                    w.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: %d\r\nConnection: close\r\n\r\n" % len(body) + body)
                else:
                    size = os.path.getsize(APK)
                    w.write(b"HTTP/1.1 200 OK\r\nContent-Type: application/vnd.android.package-archive\r\nContent-Disposition: attachment; filename=lmg-connector.apk\r\nContent-Length: %d\r\nConnection: close\r\n\r\n" % size)
                    with open(APK, "rb") as f:
                        while True:
                            c = f.read(65536)
                            if not c: break
                            w.write(c); await w.drain()
            else: w.write(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            await w.drain()
        except Exception: pass
        finally:
            try: w.close()
            except Exception: pass


class Discovery(asyncio.DatagramProtocol):
    def __init__(self, srv): self.srv = srv
    def connection_made(self, tr): self.tr = tr
    def datagram_received(self, data, addr):
        if data.strip() == b"LMGCONNECTOR?":
            self.tr.sendto(json.dumps({"name": self.srv.name, "port": PORT, "v": 1}).encode(), addr)


async def main():
    global PORT, UDP_PORT, HTTP_PORT
    for i, a in enumerate(sys.argv):
        if a == "--port": PORT = int(sys.argv[i + 1])
        if a == "--udp": UDP_PORT = int(sys.argv[i + 1])
        if a == "--http": HTTP_PORT = int(sys.argv[i + 1])
    srv = Server()
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.minimum_version = ssl.TLSVersion.TLSv1_2; ctx.load_cert_chain(srv.crt, srv.key)
    s1 = await asyncio.start_server(srv.handle, "0.0.0.0", PORT, ssl=ctx)
    s2 = await asyncio.start_server(srv.http, "0.0.0.0", HTTP_PORT)
    loop = asyncio.get_running_loop()
    try: await loop.create_datagram_endpoint(lambda: Discovery(srv), local_addr=("0.0.0.0", UDP_PORT), allow_broadcast=True)
    except OSError as e: log("discovery off:", e)
    srv.status(); log("ready, code", srv.code)
    stop = asyncio.Event()
    for sg in (signal.SIGTERM, signal.SIGINT): loop.add_signal_handler(sg, stop.set)
    async def refresher():
        while True:
            await asyncio.sleep(5); srv.status()
    async def newcode():                                                   # the GUI asks for a new code by touching this file
        f = STATUS + ".newcode"
        while True:
            await asyncio.sleep(1)
            if os.path.exists(f):
                try: os.remove(f)
                except OSError: pass
                srv.code = new_code(); srv.fails.clear(); srv.status()
    t = [asyncio.create_task(refresher()), asyncio.create_task(newcode())]
    await stop.wait()
    for x in t: x.cancel()
    s1.close(); s2.close()
    try: os.remove(STATUS)
    except OSError: pass


if __name__ == "__main__":
    asyncio.run(main())
