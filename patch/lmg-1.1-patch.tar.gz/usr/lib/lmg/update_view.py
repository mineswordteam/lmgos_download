#!/usr/bin/python3
"""Full-screen viewer for the LMG update screen: WebKitGTK showing the local page (same HTML scenes, no Firefox).
Exit code 0 only when it was closed on purpose; anything else makes lmg-update-kiosk fall back to Firefox."""
import os, signal, sys
os.environ.setdefault("WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS", "1")   # no user namespaces in the update environment
os.environ.setdefault("WEBKIT_DISABLE_COMPOSITING_MODE", "1")            # software path: works with any graphics at boot
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("WebKit2", "4.1")
from gi.repository import Gtk, Gdk, GLib, WebKit2

URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765/"


def main():
    scr = Gdk.Screen.get_default()
    w, h = scr.get_width(), scr.get_height()
    win = Gtk.Window()
    win.set_decorated(False)
    win.set_type_hint(Gdk.WindowTypeHint.SPLASHSCREEN)      # inside a running desktop (live installer): above the taskbar and sidebar, not in the task list
    win.set_skip_taskbar_hint(True); win.set_skip_pager_hint(True); win.set_keep_above(True)
    win.set_default_size(w, h)
    win.resize(w, h)
    win.move(0, 0)
    win.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0, 0, 0, 1))
    ctx = WebKit2.WebContext.new_ephemeral()
    ctx.set_cache_model(WebKit2.CacheModel.DOCUMENT_VIEWER)
    view = WebKit2.WebView.new_with_context(ctx)
    st = view.get_settings()
    st.set_enable_javascript(True)
    st.set_hardware_acceleration_policy(WebKit2.HardwareAccelerationPolicy.NEVER)
    st.set_enable_developer_extras(False)
    st.set_enable_write_console_messages_to_stdout(False)
    st.set_media_playback_requires_user_gesture(False)
    view.set_background_color(Gdk.RGBA(0, 0, 0, 1))
    view.connect("context-menu", lambda *a: True)
    view.connect("web-process-terminated", lambda v, r: sys.exit(3))
    view.connect("load-failed", lambda v, ev, uri, err: (GLib.timeout_add_seconds(2, lambda: (v.load_uri(URL), False)[1]), True)[1])
    win.connect("delete-event", lambda *a: True)            # Alt+F4 / close requests are ignored: the screen ends only when the installer ends it
    win.connect("key-press-event", lambda w, e: True)
    win.add(view)
    win.show_all()
    win.fullscreen()
    def grab():                                              # keyboard captured: no window-manager shortcuts (Alt+F4, Alt+Tab, Super...)
        try:
            gw = win.get_window()
            if gw is not None:
                win.get_display().get_default_seat().grab(gw, Gdk.SeatCapabilities.KEYBOARD, True, None, None, None)
        except Exception:
            pass
        return True
    GLib.timeout_add(300, lambda: (grab(), False)[1])
    GLib.timeout_add(1500, lambda: (win.present(), win.fullscreen(), win.set_keep_above(True), grab(), False)[4])
    GLib.timeout_add(3000, grab)   # a panel mapped later must not end up on top
    try:
        win.get_window().set_cursor(Gdk.Cursor.new_for_display(win.get_display(), Gdk.CursorType.BLANK_CURSOR))
    except Exception:
        pass
    view.load_uri(URL)
    signal.signal(signal.SIGTERM, lambda *_: Gtk.main_quit())
    GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGTERM, lambda: (Gtk.main_quit(), False)[1])
    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main())
