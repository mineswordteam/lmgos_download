"""Wallpaper gallery shared by LMG Settings and the first-run welcome."""
import os, subprocess
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf
from lmgcommon import t

DIR = os.environ.get("LMG_WALLS", "/usr/share/backgrounds/lmg")
NAMES = ["lmg-mountain", "lmg-neon-grid", "lmg-aurora", "lmg-nebula", "lmg-waves",
         "lmg-circuit", "lmg-sunset", "lmg-hexagons", "lmg-logo-glow"]

def list_walls():
    out = []
    for n in NAMES:
        p = os.path.join(DIR, n + ".jpg")
        if os.path.exists(p):
            th = os.path.join(DIR, "thumbs", n + ".jpg")
            out.append((n, p, th if os.path.exists(th) else p))
    return out

def set_wallpaper(path):
    """Set the picture on every monitor/workspace known to xfdesktop."""
    try:
        props = subprocess.run(["xfconf-query", "-c", "xfce4-desktop", "-l"], capture_output=True, text=True, timeout=10).stdout.splitlines()
    except Exception:
        props = []
    for p in props:
        if p.endswith("/last-image"):
            subprocess.run(["xfconf-query", "-c", "xfce4-desktop", "-p", p, "-s", path], timeout=10)

def choose_wall(parent):
    """Gallery dialog; returns the chosen path (already applied) or None."""
    d = Gtk.Dialog(title=t("wallpaper"), transient_for=parent, modal=True)
    d.set_default_size(720, 520)
    d.add_button(t("wall_other"), 1); d.add_button(t("close"), Gtk.ResponseType.CLOSE)
    fb = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.SINGLE, max_children_per_line=3, min_children_per_line=2, homogeneous=True, column_spacing=10, row_spacing=10, margin=12)
    paths = []
    for n, p, th in list_walls():
        try: pb = GdkPixbuf.Pixbuf.new_from_file_at_size(th, 220, 124)
        except Exception: continue
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        box.pack_start(Gtk.Label(label=t("wall_" + n) if t("wall_" + n) != "wall_" + n else n.replace("lmg-", "").replace("-", " ").title()), False, False, 0)
        fb.add(box); paths.append(p)
    sw = Gtk.ScrolledWindow(); sw.add(fb); d.get_content_area().pack_start(sw, True, True, 0)
    chosen = [None]
    def act(_fb, child):
        chosen[0] = paths[child.get_index()]; set_wallpaper(chosen[0])
    fb.connect("child-activated", act)
    d.show_all()
    while True:
        r = d.run()
        if r == 1:
            f = Gtk.FileChooserNative(title=t("wallpaper"), action=Gtk.FileChooserAction.OPEN, transient_for=d)
            ff = Gtk.FileFilter(); ff.set_name("Images"); ff.add_mime_type("image/png"); ff.add_mime_type("image/jpeg"); f.add_filter(ff)
            f.set_current_folder("/usr/share/backgrounds")
            if f.run() == Gtk.ResponseType.ACCEPT:
                chosen[0] = f.get_filename(); set_wallpaper(chosen[0])
            continue
        break
    d.destroy()
    return chosen[0]
