#!/usr/bin/python3
"""LMG OS login splash: neon 'Welcome' + loading bar shown right after the password,
closes as soon as the panel and desktop are up (3-6 seconds)."""
import gi, os, sys, json, math, subprocess
gi.require_version("Gtk", "3.0"); gi.require_version("PangoCairo", "1.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Pango, PangoCairo
import cairo

WALL = "/usr/share/backgrounds/lmg/lmg-mountain.jpg"
LOGO = "/usr/share/lmg/branding/logo-main.png"
MIN_T, MAX_T = 3.0, 25.0
MSG = len(sys.argv) > 2 and sys.argv[1] == "--msg"
BYE = (len(sys.argv) > 2 and sys.argv[1] == "--bye") or MSG
BYE_TEXT = sys.argv[2] if BYE else ""
user = "" if BYE else (sys.argv[1] if len(sys.argv) > 1 else os.environ.get("USER", ""))
FA_BYE = {"Update completed": "به‌روزرسانی انجام شد", "Previous version restored": "نسخه‌ی قبلی بازگردانی شد", "Shutting down": "در حال خاموش شدن…", "Restarting": "در حال راه‌اندازی مجدد…", "Signing out": "در حال خروج…"}
fa = os.environ.get("LANG", "").startswith("fa")
try:
    for p in (os.path.join(os.environ.get("LMG_USER_HOME") or os.path.expanduser("~"), ".config/lmg/settings.json"), "/etc/skel/.config/lmg/settings.json"):
        if os.path.exists(p):
            lang = json.load(open(p)).get("language", "auto")
            if lang == "fa": fa = True
            if lang == "en": fa = False
            break
except Exception: pass
FANCY = False
try: FANCY = bool(json.load(open(os.path.join(os.environ.get("LMG_USER_HOME") or os.path.expanduser("~"), ".config/lmg/settings.json"))).get("fancy_animations"))
except Exception: pass
OUT = 0.8 if FANCY else 0.5          # seconds of the cross-fade into the desktop
WORD = (FA_BYE.get(BYE_TEXT, BYE_TEXT) if fa else (BYE_TEXT if MSG else BYE_TEXT + "…")) if BYE else ("خوش آمدید" if fa else "Welcome")

class Splash(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.POPUP)
        geo = Gdk.Display.get_default().get_monitor(0).get_geometry()
        self.W, self.H = geo.width, geo.height
        self.set_default_size(self.W, self.H); self.move(geo.x, geo.y); self.set_app_paintable(True)
        self.set_keep_above(True)
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(WALL); s = max(self.W / pb.get_width(), self.H / pb.get_height())
            pb = pb.scale_simple(int(pb.get_width() * s) + 1, int(pb.get_height() * s) + 1, GdkPixbuf.InterpType.BILINEAR)
            self.bg = Gdk.cairo_surface_create_from_pixbuf(pb, 1, None); self.bgdx = (pb.get_width() - self.W) // 2; self.bgdy = (pb.get_height() - self.H) // 2
        except Exception: self.bg = None
        try: self.logo = GdkPixbuf.Pixbuf.new_from_file_at_size(LOGO, 120, 120)
        except Exception: self.logo = None
        self.t0 = GLib.get_monotonic_time(); self.ready_t = None; self.calm = 0; self.last = self.cpu()
        self.connect("draw", self.on_draw); self.show_all()
        GLib.timeout_add(50, self.tick)
        if MSG: GLib.timeout_add(3500, Gtk.main_quit)
        GLib.timeout_add(400, self.check); GLib.timeout_add(int((60 if BYE else MAX_T) * 1000) + 2000, Gtk.main_quit)

    def cpu(self):
        try:
            v = [int(x) for x in open("/proc/stat").readline().split()[1:]]
            return sum(v), v[3] + v[4]
        except Exception: return (1, 1)

    def now(self): return (GLib.get_monotonic_time() - self.t0) / 1e6

    def check(self):
        if BYE: return True
        tot, idle = self.cpu(); dt, di = tot - self.last[0], idle - self.last[1]; self.last = (tot, idle)
        busy = 1 - (di / dt) if dt > 0 else 1
        self.calm = self.calm + 1 if busy < 0.35 else 0
        if self.ready_t is None and self.now() >= MIN_T:
            up = all(subprocess.run(["pgrep", "-x", n], stdout=subprocess.DEVNULL).returncode == 0 for n in ("xfce4-panel", "xfdesktop"))
            if (up and self.calm >= 4) or self.now() >= MAX_T: self.ready_t = self.now()
        return True

    def tick(self):
        if self.ready_t is not None:
            x = (self.now() - self.ready_t) / OUT
            if x >= 1: Gtk.main_quit(); return False
            try: self.set_opacity(1 - (x * x * (3 - 2 * x)))          # smooth-step: the desktop appears through the splash
            except Exception: pass
        self.queue_draw(); return True

    def text(self, cr, s, size, y, bold=True, glow=True, color=(0.85, 0.95, 1)):
        lay = PangoCairo.create_layout(cr); lay.set_font_description(Pango.FontDescription(("Noto Sans Bold " if bold else "Noto Sans ") + str(size)))
        lay.set_text(s, -1); w, h = lay.get_pixel_size(); x = (self.W - w) / 2
        if glow:
            for r, a in ((9, .05), (6, .09), (3, .16)):
                cr.save(); cr.move_to(x, y); PangoCairo.layout_path(cr, lay); cr.set_line_width(r); cr.set_line_join(cairo.LINE_JOIN_ROUND)
                cr.set_source_rgba(0, .55, 1, a * 2); cr.stroke(); cr.restore()
        cr.move_to(x, y); cr.set_source_rgb(*color); PangoCairo.show_layout(cr, lay); return h

    def on_draw(self, w, cr):
        t = self.now(); a = min(1, t / 0.35)
        if self.ready_t is not None: a *= max(0, 1 - (t - self.ready_t) / (OUT * 0.6))
        cr.set_source_rgb(0.02, 0.04, 0.09); cr.paint()
        if self.bg: cr.set_source_surface(self.bg, -self.bgdx, -self.bgdy); cr.paint()
        cr.set_source_rgba(0, 0, 0, 0.62); cr.paint()
        cx, cy = self.W / 2, self.H / 2
        cr.push_group()
        if FANCY and self.ready_t is not None:                 # the greeting grows gently while it fades away
            k = min(1, (t - self.ready_t) / OUT); z = 1 + 0.12 * k * k
            cr.translate(cx, cy); cr.scale(z, z); cr.translate(-cx, -cy)
        self.text(cr, WORD, 54, cy + 40)
        if user: self.text(cr, user, 20, cy + 120, bold=False, glow=False, color=(0.45, 0.7, 1))
        bw, bh = 340, 6; bx, by = cx - bw / 2, cy + 175
        cr.set_source_rgba(0.1, 0.2, 0.4, 0.8); cr.rectangle(bx, by, bw, bh); cr.fill()
        done = 1.0 if self.ready_t is not None else min(0.9, 0.9 * (1 - math.exp(-t / 3.5)))
        if BYE: done = 1.0 if MSG else (t * 0.35) % 1.0
        cr.set_source_rgb(0.0, 0.7, 1.0); cr.rectangle(bx, by, bw * done, bh); cr.fill()
        cr.set_source_rgba(0, 0.75, 1, 0.25); cr.rectangle(bx - 2, by - 2, bw * done + 4, bh + 4); cr.fill()
        cr.pop_group_to_source(); cr.paint_with_alpha(a)
        return False

Splash(); Gtk.main()
