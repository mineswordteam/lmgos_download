#!/usr/bin/python3
"""Shown on the desktop after a restart that installed an update or restored the previous version and FAILED:
what happened, and the log in this separate window."""
import json, os, sys
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *
from modules.update import show_log, read_log, RESULT


def main():
    init_i18n(load_settings()); load_css()
    try:
        res = json.load(open(RESULT))
    except Exception:
        res = {}
    kind = res.get("kind", "update")
    ttl = t({"update": "upd_failed_title", "upgrade": "upg_failed_title"}.get(kind, "rb_failed_title"))
    w = Gtk.Window(title=ttl)
    w.set_default_size(560, 260); w.set_position(Gtk.WindowPosition.CENTER); w.set_icon_name("lmgos")
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12); box.set_border_width(20); w.add(box)
    box.pack_start(heading(ttl), False, False, 0)
    box.pack_start(Gtk.Label(label=res.get("message") or "", xalign=0, wrap=True, selectable=True), False, False, 0)
    if res.get("restored"):
        ok = Gtk.Label(label=t("upd_restored_note"), xalign=0, wrap=True); ok.get_style_context().add_class("lmg-sub")
        box.pack_start(ok, False, False, 0)
    row = Gtk.Box(spacing=8); row.set_halign(Gtk.Align.END)
    b1 = Gtk.Button(label=t("upd_show_log")); b1.connect("clicked", lambda *_: show_log(w, t("upd_log_title"), (read_log() or res.get("log_tail", ""))))
    b2 = Gtk.Button(label=t("close")); b2.get_style_context().add_class("suggested-action"); b2.connect("clicked", lambda *_: Gtk.main_quit())
    row.pack_start(b1, False, False, 0); row.pack_start(b2, False, False, 0)
    box.pack_end(row, False, False, 0)
    w.connect("destroy", Gtk.main_quit); w.show_all(); Gtk.main()


if __name__ == "__main__":
    main()
