#!/usr/bin/python3
"""LMG OS installer front door (live session, runs as root).
Looks for an older LMG OS already installed on this computer. If there is one it offers to UPGRADE it (only the system is
replaced; files, accounts and programs stay), otherwise - or when the user chooses so - it starts the normal installer (Calamares)."""
import http.server, json, os, signal, subprocess, sys, threading, time
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *
import lmgupgrade as G

PROBE = "/run/lmg/probe"
TARGET = "/run/lmg/target"
FS_OK = ("ext4", "ext3", "ext2", "btrfs", "xfs", "f2fs")


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def list_partitions():
    r = sh(["lsblk", "-J", "-p", "-o", "NAME,FSTYPE,TYPE,SIZE,LABEL,MOUNTPOINT"])
    out = []
    def walk(nodes):
        for n in nodes or []:
            out.append(n); walk(n.get("children"))
    try: walk(json.loads(r.stdout).get("blockdevices"))
    except Exception: pass
    return out


def unlock_luks(passphrase):
    """Open every LUKS partition that accepts this passphrase (the user usually has the same one everywhere)."""
    opened = []
    for p in list_partitions():
        if p.get("fstype") == "crypto_LUKS":
            name = "lmgprobe_" + os.path.basename(p["name"])
            r = subprocess.run(["cryptsetup", "open", p["name"], name, "--key-file", "-"], input=passphrase, text=True, capture_output=True)
            if r.returncode == 0: opened.append(name)
    sh(["vgchange", "-ay"])
    return opened


def find_installs():
    """[{dev, version, host, size}] for every partition holding an LMG OS."""
    sh(["vgchange", "-ay"])
    found = []
    for p in list_partitions():
        dev, fs = p.get("name"), p.get("fstype")
        if fs not in FS_OK or p.get("type") == "loop" or p.get("mountpoint") == "/":
            continue
        already = p.get("mountpoint")
        mp = already or (PROBE + "/" + os.path.basename(dev))
        if not already:
            os.makedirs(mp, exist_ok=True)
            if sh(["mount", "-o", "ro", dev, mp]).returncode != 0:
                continue
        try:
            if G.is_lmg_root(mp):
                try: host = open(mp + "/etc/hostname").read().strip()
                except Exception: host = ""
                found.append({"dev": dev, "version": G.current_version(mp) or "1.0", "host": host, "size": p.get("size", "")})
        finally:
            if not already:
                sh(["umount", "-l", mp])
    return found


def mount_target(dev):
    """Mount the installed system read-write plus the partitions its fstab needs for booting (/boot, /boot/efi...)."""
    os.makedirs(TARGET, exist_ok=True)
    sh(["umount", dev])          # the file manager may have opened it (read-only) in the live session
    r = sh(["mount", dev, TARGET])
    if r.returncode != 0: raise RuntimeError("Could not open the installed system: " + r.stderr.strip())
    mounted = [TARGET]
    try:
        lines = open(TARGET + "/etc/fstab").read().splitlines()
    except Exception:
        lines = []
    for l in lines:
        f = l.split()
        if len(f) < 3 or l.lstrip().startswith("#") or f[1] in ("/", "none", "swap") or f[2] in ("swap", "tmpfs", "nfs", "cifs"):
            continue
        if not f[1].startswith(("/boot", "/usr", "/var", "/opt", "/etc")) or "/home" in f[1]:
            continue
        spec = sh(["findfs", f[0]]).stdout.strip() if "=" in f[0] else f[0]
        if not spec: continue
        mp = TARGET + f[1]; os.makedirs(mp, exist_ok=True)
        if sh(["mount", spec, mp]).returncode == 0: mounted.append(mp)
    for b in ("dev", "proc", "sys", "run"):
        os.makedirs(TARGET + "/" + b, exist_ok=True)
        if sh(["mount", "--rbind", "/" + b, TARGET + "/" + b]).returncode == 0: mounted.append(TARGET + "/" + b)
    return mounted


def umount_target(mounted):
    sh(["sync"])
    for m in reversed(mounted):
        sh(["umount", "-R", "-l", m])


class Screen:
    """The full-screen upgrade animation (same page as the boot-time upgrade): local page server + WebKit viewer."""
    PORT = 8766

    def __init__(self):
        self.state = {"scene": "upgrade", "pct": 0, "lang": "fa" if current_language() == "fa" else "en"}
        self.proc = self.httpd = None

    def start(self):
        ui = self
        class H(http.server.SimpleHTTPRequestHandler):
            def __init__(self, *a, **k): super().__init__(*a, directory="/usr/share/lmg/update-ui", **k)
            def do_GET(self):
                if self.path.startswith("/status.json"):
                    b = json.dumps(ui.state).encode()
                    self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(b); return
                super().do_GET()
            def log_message(self, *a): pass
        try:
            self.httpd = http.server.ThreadingHTTPServer(("127.0.0.1", self.PORT), H)
            threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
            self.proc = subprocess.Popen([sys.executable, "/usr/lib/lmg/update_view.py", "http://127.0.0.1:%d/upgrade.html" % self.PORT],
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        except Exception as e:
            G.log("upgrade screen: %r" % e)

    def scene(self, name): self.state["scene"] = name
    def pct(self, p): self.state["pct"] = max(0, min(100, p))

    def stop(self):
        try:
            if self.proc and self.proc.poll() is None: os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
        except Exception: pass
        try:
            if self.httpd: self.httpd.shutdown()
        except Exception: pass


def run_upgrade(dev, progress):
    """The upgrade of the installed system on `dev` from this live image, with the full-screen animation. Returns (ok, message)."""
    src, srcm = G.live_source()
    if not src: return False, "The new system image was not found on this live medium."
    new_ver = G.current_version(src)
    mounted = []
    scr = Screen()
    def prog(p, text):
        scr.pct(p); progress(p, text)
    try:
        progress(1, "Opening the installed system")
        mounted = mount_target(dev)
        old_ver = G.current_version(TARGET)
        need = 3 * 2**30            # the new system replaces files one by one: room for the biggest changes plus the new kernel files
        if G.free_bytes(TARGET) < need:
            return False, "Not enough free space on the installed system: about %d MB are needed, %d MB are free." % (need // 2**20, G.free_bytes(TARGET) // 2**20)
        scr.start()
        G.upgrade_tree(src, TARGET, lambda p, t: prog(2 + p * 0.75, t), backup_dir=TARGET + "/var/lib/lmg/upgrade-backup")
        prog(78, "Boot files")
        if not G.boot_files(TARGET, lambda p, t: prog(78 + p * 0.19, t)):
            scr.scene("error"); time.sleep(5)
            return False, "No kernel was found after the upgrade."
        prog(100, "")
        t0 = time.monotonic(); scr.scene("optimize")
        G.optimize(TARGET)                       # caches, TRIM on SSD / defragmentation on a hard disk
        G.write_marker(TARGET, old_ver, new_ver)
        queue_welcome(TARGET)
        G.write_json(TARGET + "/var/lib/lmg/update-result.json", {"kind": "upgrade", "ok": True, "message": "", "from": old_ver, "to": new_ver, "ts": int(time.time())})
        time.sleep(max(0, 12 - (time.monotonic() - t0)))
        scr.scene("restart"); time.sleep(5)
        return True, ""
    except Exception as e:
        G.log("installer upgrade failed: %r" % e)
        scr.scene("error"); time.sleep(4)
        return False, str(e)
    finally:
        scr.stop()
        umount_target(mounted)
        G.umount_all(srcm)


def queue_welcome(target):
    """After a flash upgrade every existing user gets the first-run welcome once (a fresh install gets it from /etc/skel)."""
    try: homes = [os.path.join(target, "home", d) for d in os.listdir(os.path.join(target, "home"))]
    except OSError: return
    for h in homes:
        try:
            st = os.stat(h)
            d = os.path.join(h, ".config", "lmg"); os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "oobe-pending"), "w") as f: f.write('{"kind": "upgrade", "version": "1.1"}\n')
            try: os.remove(os.path.join(d, "first-run-done"))
            except OSError: pass
            for p in (os.path.join(h, ".config"), d, os.path.join(d, "oobe-pending")): os.chown(p, st.st_uid, st.st_gid)
        except Exception as e:
            G.log("welcome marker failed for %s: %r" % (h, e))


class Win(Gtk.Window):
    def __init__(self):
        super().__init__(title=t("ins_title")); self.set_default_size(620, 420); self.set_position(Gtk.WindowPosition.CENTER); self.set_icon_name("lmg-install")
        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12); self.box.set_border_width(22); self.add(self.box)
        self.box.pack_start(heading(t("ins_title"), t("ins_sub")), False, False, 0)
        self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10); self.box.pack_start(self.body, True, True, 0)
        self.busy_label(t("ins_scanning")); self.show_all()
        in_thread(find_installs, self.found)

    def clear(self):
        for c in self.body.get_children(): c.destroy()

    def busy_label(self, text):
        self.clear(); l = Gtk.Label(label=text, xalign=0, wrap=True); self.body.pack_start(l, False, False, 0); self.body.show_all()

    def fresh(self, *_):
        """Start the normal installer (Calamares). This window waits and comes back with the reason if Calamares fails to start."""
        self.hide()
        log = "/tmp/lmg-calamares.log"
        def work():
            with open(log, "w") as f:
                p = subprocess.Popen(["calamares"], stdout=f, stderr=subprocess.STDOUT, env=os.environ)
                return p.wait()
        def done(rc):
            if rc == 0:
                Gtk.main_quit(); return
            tail = ""
            try: tail = "".join(open(log).readlines()[-8:])
            except OSError: pass
            if isinstance(rc, Exception): tail = str(rc) + "\n" + tail
            self.show(); self.clear()
            self.body.pack_start(Gtk.Label(label=t("ins_fresh_failed") + "\n\n" + tail, xalign=0, wrap=True, selectable=True), False, False, 0)
            b = Gtk.Button(label=t("ins_fresh")); b.set_halign(Gtk.Align.END); b.connect("clicked", self.fresh); self.body.pack_end(b, False, False, 0); self.body.show_all()
        in_thread(work, done)

    def found(self, res):
        if isinstance(res, Exception): res = []
        self.installs = res; self.clear()
        new = G.current_version("/")
        self.luks = [p for p in list_partitions() if p.get("fstype") == "crypto_LUKS"]
        if not res and not self.luks:
            return self.fresh()
        if not res:
            self.body.pack_start(Gtk.Label(label=t("ins_luks"), xalign=0, wrap=True), False, False, 0)
            row = Gtk.Box(spacing=8); row.set_halign(Gtk.Align.END)
            b1 = Gtk.Button(label=t("ins_fresh")); b1.connect("clicked", self.fresh)
            b2 = Gtk.Button(label=t("ins_unlock")); b2.get_style_context().add_class("suggested-action"); b2.connect("clicked", self.unlock)
            row.pack_start(b1, False, False, 0); row.pack_start(b2, False, False, 0); self.body.pack_end(row, False, False, 0); self.body.show_all()
            return
        l = Gtk.Label(label=t("ins_found"), xalign=0, wrap=True); self.body.pack_start(l, False, False, 0)
        self.sel = None; group = None
        for it in res:
            txt = "LMG OS %s  -  %s  (%s)%s" % (it["version"], it["dev"], it["size"], ("  -  " + it["host"]) if it["host"] else "")
            rb = Gtk.RadioButton.new_with_label_from_widget(group, txt); group = group or rb
            rb.connect("toggled", lambda b, i=it: b.get_active() and setattr(self, "sel", i)); self.body.pack_start(rb, False, False, 0)
        self.sel = res[0]
        newer = [i for i in res if G.is_newer(new, i["version"])]
        info = Gtk.Label(label=(t("ins_up_info").format(new) if newer else t("ins_same")), xalign=0, wrap=True); info.get_style_context().add_class("lmg-sub")
        self.body.pack_start(info, False, False, 0)
        row = Gtk.Box(spacing=8); row.set_halign(Gtk.Align.END)
        b_new = Gtk.Button(label=t("ins_fresh")); b_new.get_style_context().add_class("suggested-action" if not newer else "destructive-action"); b_new.connect("clicked", self.confirm_fresh)
        b_up = Gtk.Button(label=t("ins_upgrade")); b_up.get_style_context().add_class("suggested-action"); b_up.connect("clicked", self.start_upgrade); b_up.set_sensitive(bool(newer))
        row.pack_start(b_new, False, False, 0); row.pack_start(b_up, False, False, 0); self.body.pack_end(row, False, False, 0)
        self.body.show_all()

    def unlock(self, *_):
        d = Gtk.Dialog(title=t("ins_unlock"), transient_for=self, modal=True)
        e = Gtk.Entry(visibility=False, activates_default=True); e.set_margin_start(16); e.set_margin_end(16); e.set_margin_top(12); e.set_margin_bottom(8)
        d.get_content_area().pack_start(Gtk.Label(label=t("ins_pass")), False, False, 8); d.get_content_area().pack_start(e, False, False, 0)
        d.add_button(t("close"), Gtk.ResponseType.CANCEL); ok = d.add_button("OK", Gtk.ResponseType.OK); ok.set_can_default(True); d.set_default_response(Gtk.ResponseType.OK)
        d.show_all(); r = d.run(); pw = e.get_text(); d.destroy()
        if r != Gtk.ResponseType.OK: return
        self.busy_label(t("ins_scanning"))
        def work():
            unlock_luks(pw); return find_installs()
        in_thread(work, lambda res: self.found2(res))

    def found2(self, res):
        self.luks_tried = True
        if isinstance(res, Exception) or not res:
            self.clear(); self.body.pack_start(Gtk.Label(label=t("ins_nothing"), xalign=0, wrap=True), False, False, 0)
            b = Gtk.Button(label=t("ins_fresh")); b.set_halign(Gtk.Align.END); b.connect("clicked", self.fresh); self.body.pack_end(b, False, False, 0); self.body.show_all(); return
        self.found(res)

    def confirm_fresh(self, *_):
        if confirm(self, t("ins_fresh_q"), t("ins_fresh_detail")): self.fresh()

    def start_upgrade(self, *_):
        if not confirm(self, t("ins_up_q"), t("ins_up_detail")): return
        self.clear()
        self.bar = Gtk.ProgressBar(show_text=True); self.lbl = Gtk.Label(label="", xalign=0)
        self.body.pack_start(Gtk.Label(label=t("ins_upgrading"), xalign=0), False, False, 0); self.body.pack_start(self.bar, False, False, 0); self.body.pack_start(self.lbl, False, False, 0); self.body.show_all()
        def prog(p, text): GLib.idle_add(self.set_prog, p, text)
        in_thread(lambda: run_upgrade(self.sel["dev"], prog), self.upgraded)

    def set_prog(self, p, text):
        self.bar.set_fraction(max(0, min(1, p / 100.0))); self.bar.set_text("%d%%" % p); self.lbl.set_text(text or "")

    def upgraded(self, res):
        ok, msg = res if isinstance(res, tuple) else (False, str(res))
        self.clear()
        self.body.pack_start(Gtk.Label(label=t("ins_done") if ok else (t("ins_failed") + "\n" + msg), xalign=0, wrap=True), False, False, 0)
        b = Gtk.Button(label=t("ins_restart") if ok else t("close")); b.get_style_context().add_class("suggested-action"); b.set_halign(Gtk.Align.END)
        b.connect("clicked", lambda *_: (subprocess.Popen(["systemctl", "reboot"]) if ok else Gtk.main_quit()))
        self.body.pack_end(b, False, False, 0); self.body.show_all()


def main():
    if "--fresh" in sys.argv:        # skip the search for an older system: straight to the installer
        os.execvp("sudo", ["sudo", "-E", "calamares"]) if os.geteuid() != 0 else os.execvp("calamares", ["calamares"])
    live = "boot=live" in open("/proc/cmdline").read()
    if not live:
        sys.exit("LMG OS is already installed.")
    if os.geteuid() != 0:
        os.execvp("sudo", ["sudo", "-E", sys.executable] + sys.argv)
    s = load_settings(); init_i18n(s); load_css()
    w = Win(); w.connect("destroy", Gtk.main_quit); Gtk.main()


if __name__ == "__main__":
    main()
