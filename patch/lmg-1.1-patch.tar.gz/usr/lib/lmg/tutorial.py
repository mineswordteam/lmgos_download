#!/usr/bin/python3
"""LMG OS Tutorial: animated, illustrated tour (screen mock-ups with glowing highlights and arrows)."""
import math, os, sys
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *
from gi.repository import GdkPixbuf, Gdk
import cairo

N = 10
NEON, CYAN = (0.12, 0.56, 1.0), (0.0, 0.82, 1.0)
_pb = {}

def pix(path, w, h):
    k = (path, w, h)
    if k not in _pb:
        try: _pb[k] = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, w, h, False)
        except Exception: _pb[k] = None
    return _pb[k]

def rr(cr, x, y, w, h, r):
    cr.new_sub_path(); cr.arc(x + w - r, y + r, r, -math.pi / 2, 0); cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi); cr.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); cr.close_path()

def glow(cr, x, y, w, h, t, r=10, strong=1.0):
    a = (0.55 + 0.45 * math.sin(t * 5)) * strong
    for lw, al in ((10, 0.10), (6, 0.18), (3, 0.5)):
        rr(cr, x, y, w, h, r); cr.set_source_rgba(*CYAN, al * a); cr.set_line_width(lw); cr.stroke()
    rr(cr, x, y, w, h, r); cr.set_source_rgba(*CYAN, 0.95); cr.set_line_width(1.6); cr.stroke()

def text(cr, s, x, y, size=13, col=(0.86, 0.91, 1.0), bold=False, center=False):
    cr.select_font_face("Noto Sans", 0, 1 if bold else 0); cr.set_font_size(size)
    ext = cr.text_extents(s)
    if center: x -= ext.width / 2
    cr.set_source_rgba(*col, 1) if len(col) == 3 else cr.set_source_rgba(*col)
    cr.move_to(x, y); cr.show_text(s)
    return ext.width

def label(cr, s, x, y, size=12):
    cr.select_font_face("Noto Sans", 0, 1); cr.set_font_size(size); e = cr.text_extents(s)
    rr(cr, x - 8, y - e.height - 7, e.width + 16, e.height + 14, 8); cr.set_source_rgba(0.03, 0.06, 0.13, 0.94); cr.fill_preserve()
    cr.set_source_rgba(*NEON, 1); cr.set_line_width(1); cr.stroke(); text(cr, s, x, y, size, bold=True)

def arrow(cr, x1, y1, x2, y2, t):
    ang = math.atan2(y2 - y1, x2 - x1); bob = math.sin(t * 6) * 4
    x2 -= math.cos(ang) * bob; y2 -= math.sin(ang) * bob
    cr.set_source_rgba(*CYAN, 0.95); cr.set_line_width(3); cr.set_line_cap(1)
    cr.move_to(x1, y1); cr.line_to(x2, y2); cr.stroke()
    for s in (-1, 1):
        cr.move_to(x2, y2); cr.line_to(x2 - 12 * math.cos(ang + s * 0.5), y2 - 12 * math.sin(ang + s * 0.5)); cr.stroke()

def pointer(cr, x, y):
    cr.move_to(x, y); cr.line_to(x, y + 20); cr.line_to(x + 5, y + 15); cr.line_to(x + 9, y + 24); cr.line_to(x + 12, y + 22.5)
    cr.line_to(x + 8, y + 14); cr.line_to(x + 15, y + 14); cr.close_path()
    cr.set_source_rgb(1, 1, 1); cr.fill_preserve(); cr.set_source_rgb(0, 0, 0); cr.set_line_width(1.2); cr.stroke()

class Scene:
    """Draws a miniature LMG desktop and exposes anchor rectangles."""
    def __init__(self, cr, W, H):
        self.cr = cr
        h = min(H - 20, (W - 20) * 0.62); w = h / 0.62
        self.x, self.y, self.w, self.h = (W - w) / 2, (H - h) / 2, w, h
        self.tb_h = h * 0.085

    def R(self, fx, fy, fw, fh): return (self.x + fx * self.w, self.y + fy * self.h, fw * self.w, fh * self.h)

    def desktop(self, sidebar_p=0.0, pinned=False, window=None):
        cr = self.cr
        cr.save(); rr(cr, self.x, self.y, self.w, self.h, 14); cr.clip()
        wp = pix("/usr/share/backgrounds/lmg/lmg-mountain.jpg", int(self.w), int(self.h))
        if wp: Gdk.cairo_set_source_pixbuf(cr, wp, self.x, self.y); cr.paint()
        else: cr.set_source_rgb(0.02, 0.04, 0.1); cr.paint()
        if window:
            wx, wy, ww, wh = window
            rr(cr, wx, wy, ww, wh, 8); cr.set_source_rgba(0.04, 0.07, 0.15, 0.96); cr.fill()
            rr(cr, wx, wy, ww, 20, 8); cr.set_source_rgba(0.06, 0.1, 0.22, 1); cr.fill()
            rr(cr, wx, wy, ww, wh, 8); cr.set_source_rgba(*NEON, 0.8); cr.set_line_width(1.2); cr.stroke()
        # taskbar
        ty = self.y + self.h - self.tb_h
        cr.rectangle(self.x, ty, self.w, self.tb_h); cr.set_source_rgba(0.03, 0.05, 0.11, 0.97); cr.fill()
        cr.rectangle(self.x, ty, self.w, 1.5); cr.set_source_rgba(*NEON, 1); cr.fill()
        s = self.tb_h * 0.66; yy = ty + (self.tb_h - s) / 2
        st = pix(SHARE + "/branding/logo-start.png", int(s), int(s))
        if st: Gdk.cairo_set_source_pixbuf(cr, st, self.x + 10, yy); cr.paint()
        for i in range(4):
            rr(cr, self.x + 14 + s + 8 + i * (s + 6), yy, s, s, 6); cr.set_source_rgba(*NEON, 0.30 + 0.1 * i); cr.fill()
        ox = self.x + 14 + s + 8 + 4 * (s + 6) + 14
        for i in range(2):
            rr(cr, ox + i * (s + 8), yy, s, s, 6); cr.set_source_rgba(0.05, 0.1, 0.22, 1); cr.fill_preserve(); cr.set_source_rgba(*CYAN, 0.95); cr.set_line_width(1.5); cr.stroke()
        text(cr, "04:17", self.x + self.w - 52, yy + s * 0.72, 11)
        for i in range(3): cr.arc(self.x + self.w - 80 - i * 16, yy + s / 2, 3.5, 0, 6.3); cr.set_source_rgba(0.6, 0.75, 1, 0.8); cr.fill()
        self.rect_start = (self.x + 10, yy, s, s)
        self.rect_pinned = (self.x + 14 + s + 8, yy, 4 * (s + 6) - 6, s)
        self.rect_open = (ox, yy, 2 * s + 8, s)
        self.rect_tray = (self.x + self.w - 100, yy, 94, s)
        self.rect_bar = (self.x, ty, self.w, self.tb_h)
        # sidebar
        sw = self.w * 0.25; sx = self.x + self.w - sw * sidebar_p
        sh = self.h - self.tb_h
        self.sb = (sx, self.y, sw, sh)
        if sidebar_p > 0.001:
            cr.rectangle(sx, self.y, sw, sh); cr.set_source_rgba(0.02, 0.04, 0.09, 0.97); cr.fill()
            cr.rectangle(sx, self.y, 1.5, sh); cr.set_source_rgba(*NEON, 1); cr.fill()
            u = sh / 20.0
            self.sb_top = (sx + 6, self.y + 4, sw - 12, u * 1.6)
            self.sb_apps = (sx + 6, self.y + u * 2.1, sw - 12, u * 8.2)
            self.sb_graph = (sx + 6, self.y + u * 10.6, sw - 12, u * 5.2)
            self.sb_power = (sx + 6, self.y + u * 16.7, sw - 12, u * 2.6)
            lg = pix(SHARE + "/branding/logo-main.png", int(u * 1.2), int(u * 1.2))
            if lg: Gdk.cairo_set_source_pixbuf(cr, lg, sx + 12, self.y + 8); cr.paint()
            for i in range(2): rr(cr, sx + sw - 12 - (i + 1) * (u * 1.3), self.y + 8, u * 1.2, u * 1.2, 5); cr.set_source_rgba(*NEON, 0.5); cr.fill()
            for i in range(5): rr(cr, sx + 10, self.y + u * (2.3 + i * 1.6), sw - 20, u * 1.3, 6); cr.set_source_rgba(0.07, 0.12, 0.25, 1); cr.fill()
            for k in range(2):
                gy = self.y + u * (10.8 + k * 2.6); cr.set_source_rgba(*(NEON if k == 0 else CYAN), 1); cr.set_line_width(1.5)
                for i in range(30):
                    px = sx + 12 + i * (sw - 24) / 29; py = gy + u * 1.8 - (0.3 + 0.35 * (math.sin(i * 0.5 + k) + 1) / 2) * u * 1.6
                    (cr.move_to if i == 0 else cr.line_to)(px, py)
                cr.stroke()
            for i in range(3): rr(cr, sx + 10 + i * ((sw - 20) / 3), self.y + u * 16.9, (sw - 20) / 3 - 5, u * 2.2, 6); cr.set_source_rgba(0.18, 0.06, 0.12, 1); cr.fill()
        cr.restore()
        rr(cr, self.x, self.y, self.w, self.h, 14); cr.set_source_rgba(*NEON, 0.9); cr.set_line_width(2); cr.stroke()

# ---------------- scenes ----------------
def sc_intro(cr, W, H, t):
    lg = pix(SHARE + "/branding/logo-main.png", 190, 190)
    cx, cy = W / 2, H / 2 - 20
    for i in range(3): cr.arc(cx, cy, 120 + 18 * i + 6 * math.sin(t * 2 + i), 0, 6.3); cr.set_source_rgba(*NEON, 0.08); cr.fill()
    if lg: Gdk.cairo_set_source_pixbuf(cr, lg, cx - 95, cy - 95); cr.paint_with_alpha(0.85 + 0.15 * math.sin(t * 3))
    text(cr, "LMG OS", cx, cy + 150, 34, CYAN, True, True); text(cr, "Minesword Team", cx, cy + 180, 14, (0.55, 0.65, 0.8), False, True)

def sc_taskbar(cr, W, H, t):
    s = Scene(cr, W, H); s.desktop()
    k = int(t / 1.6) % 4
    if k == 0: glow(cr, *s.rect_start, t, 8); label(cr, "Start", s.rect_start[0] + 20, s.rect_start[1] - 70); arrow(cr, s.rect_start[0] + 22, s.rect_start[1] - 56, s.rect_start[0] + 14, s.rect_start[1] - 4, t)
    if k == 1: glow(cr, *s.rect_pinned, t, 8); x = s.rect_pinned[0] + 20; label(cr, "Pinned apps", x, s.rect_pinned[1] - 70); arrow(cr, x + 40, s.rect_pinned[1] - 56, x + 60, s.rect_pinned[1] - 4, t)
    if k == 2: glow(cr, *s.rect_open, t, 8); x = s.rect_open[0]; label(cr, "Open apps: logo only", x - 10, s.rect_open[1] - 70); arrow(cr, x + 40, s.rect_open[1] - 56, x + 40, s.rect_open[1] - 4, t)
    if k == 3: glow(cr, *s.rect_tray, t, 8); x = s.rect_tray[0]; label(cr, "Tray and clock", x - 40, s.rect_tray[1] - 70); arrow(cr, x + 50, s.rect_tray[1] - 56, x + 50, s.rect_tray[1] - 4, t)

def sc_edge(cr, W, H, t):
    ph = (t % 4.0) / 4.0
    p = min(1.0, max(0.0, (ph - 0.45) / 0.2)) if ph < 0.8 else max(0.0, 1 - (ph - 0.8) / 0.2)
    s = Scene(cr, W, H); s.desktop(p)
    mx = s.x + s.w * (0.35 + 0.63 * min(1.0, ph / 0.45)) if ph < 0.8 else s.x + s.w * (0.98 - 0.4 * (ph - 0.8) / 0.2)
    my = s.y + s.h * 0.42
    if ph < 0.5: arrow(cr, s.x + s.w * 0.5, my + 50, s.x + s.w * 0.93, my + 50, t); label(cr, "Move to the right edge", s.x + s.w * 0.36, my + 90)
    glow(cr, s.x + s.w - 8, s.y + 4, 8, s.h - s.tb_h - 8, t, 4, 0.8)
    pointer(cr, mx, my)

def sc_sidebar(cr, W, H, t):
    s = Scene(cr, W, H); s.desktop(1.0)
    k = int(t / 1.8) % 4; names = ["Settings + Pin", "5 quick apps", "Live CPU and RAM", "Sign out, Restart, Shut down"]
    r = [s.sb_top, s.sb_apps, s.sb_graph, s.sb_power][k]
    glow(cr, *r, t, 8); label(cr, names[k], s.x + s.w * 0.30, r[1] + r[3] / 2 + 5); arrow(cr, s.x + s.w * 0.30 + 150 if k != 3 else s.x + s.w * 0.62, r[1] + r[3] / 2, r[0] - 4, r[1] + r[3] / 2, t)

def sc_pin(cr, W, H, t):
    pinned = int(t / 2.6) % 2 == 1
    s = Scene(cr, W, H); ww = s.w * (0.50 if pinned else 0.66)
    s.desktop(1.0, pinned, (s.x + 24, s.y + 30, ww, s.h * 0.6))
    top = s.sb_top; px = top[0] + top[2] - 22
    glow(cr, px - 26, top[1] + 2, 26, top[3] - 2, t, 6, 1.0 if pinned else 0.45)
    label(cr, "Pinned: windows make room" if pinned else "Not pinned: hides when you leave", s.x + 30, s.y + s.h * 0.78)
    arrow(cr, px - 60, top[1] + top[3] + 40, px - 14, top[1] + top[3] + 4, t)

def sc_panel(cr, W, H, t):
    mods = ["Welcome", "Update", "RAM", "Hardware", "Test", "Disk", "Settings", "Gaming"]
    cw, ch = 130, 80; gx = (W - (cw * 4 + 18 * 3)) / 2; gy = H / 2 - ch - 14; k = int(t / 1.2) % 8
    for i, m in enumerate(mods):
        x = gx + (i % 4) * (cw + 18); y = gy + (i // 4) * (ch + 18)
        rr(cr, x, y, cw, ch, 12); cr.set_source_rgba(0.05, 0.09, 0.19, 1); cr.fill()
        if i == k: glow(cr, x, y, cw, ch, t, 12)
        else: rr(cr, x, y, cw, ch, 12); cr.set_source_rgba(*NEON, 0.35); cr.set_line_width(1); cr.stroke()
        text(cr, "LMG " + m, x + cw / 2, y + ch / 2 + 5, 14, CYAN if i == k else (0.85, 0.9, 1), True, True)
    text(cr, "LMG OS Control Panel", W / 2, gy - 28, 20, CYAN, True, True)

def sc_tooltip(cr, W, H, t):
    cx = W / 2; lg = pix(SHARE + "/branding/logo-main.png", 22, 22)
    def tip(x, y, w, h, lines):
        rr(cr, x, y, w, h, 10); cr.set_source_rgba(0.03, 0.05, 0.11, 0.97); cr.fill_preserve(); cr.set_source_rgba(*NEON, 1); cr.set_line_width(1.2); cr.stroke()
        for lw, al in ((6, 0.12), (3, 0.25)): rr(cr, x, y, w, h, 10); cr.set_source_rgba(*NEON, al); cr.set_line_width(lw); cr.stroke()
        if lg: Gdk.cairo_set_source_pixbuf(cr, lg, x + 10, y + 9); cr.paint()
        for i, (l, b) in enumerate(lines): text(cr, l, x + 40 if i == 0 else x + 14, y + 26 + i * 20, 13, bold=b)
    rr(cr, cx - 250, H / 2 - 20, 60, 60, 12); cr.set_source_rgba(0.06, 0.1, 0.22, 1); cr.fill(); glow(cr, cx - 250, H / 2 - 20, 60, 60, t, 12)
    a = 0.5 + 0.5 * math.sin(t * 2)
    pointer(cr, cx - 232, H / 2 + 14)
    tip(cx - 270, H / 2 - 72, 130, 38, [("Firefox", True)])
    rr(cr, cx + 80, H / 2 - 20, 54, 64, 8); cr.set_source_rgba(0.9, 0.93, 1, 0.9); cr.fill()
    tip(cx + 20, H / 2 - 128, 240, 92, [("report-2026.pdf", True), ("Size: 2.4 MB", False), ("Modified: 14 Oct 2026, 18:30", False), ("Type: PDF document", False)])
    text(cr, "Apps and shortcuts show their name", cx - 205, H / 2 + 90, 13, (0.6, 0.72, 0.9), False, True)
    text(cr, "Files show name, size and date", cx + 140, H / 2 + 90, 13, (0.6, 0.72, 0.9), False, True)

def sc_modes(cr, W, H, t):
    on = int(t / 2) % 2 == 1; cx = W / 2
    for i, (title, sub) in enumerate((("Gaming mode", "Closes extra apps, boosts CPU and GPU"), ("Light mode", "No effects, for old computers"))):
        x = cx - 270 + i * 280; y = H / 2 - 80
        rr(cr, x, y, 260, 150, 14); cr.set_source_rgba(0.05, 0.09, 0.19, 1); cr.fill(); rr(cr, x, y, 260, 150, 14); cr.set_source_rgba(*NEON, 0.6); cr.set_line_width(1.2); cr.stroke()
        text(cr, title, x + 130, y + 40, 19, CYAN, True, True); text(cr, sub, x + 130, y + 68, 12, (0.7, 0.8, 0.95), False, True)
        sx, sy = x + 100, y + 92; rr(cr, sx, sy, 60, 28, 14); cr.set_source_rgba(*(NEON if on == (i == 0) else (0.12, 0.17, 0.3)), 1); cr.fill()
        kx = sx + (34 if (on == (i == 0)) else 2); cr.arc(kx + 12, sy + 14, 11, 0, 6.3); cr.set_source_rgb(1, 1, 1); cr.fill()
        if on == (i == 0): glow(cr, sx, sy, 60, 28, t, 14, 0.8)

def sc_apps(cr, W, H, t):
    cx = W / 2; items = [("Linux apps", "apt / Flatpak"), ("Windows apps", "Wine / Bottles"), ("Phones, USB", "appear in Files")]
    k = int(t / 1.5) % 3
    for i, (a, b) in enumerate(items):
        x = cx - 330 + i * 225; y = H / 2 - 60; rr(cr, x, y, 205, 120, 14); cr.set_source_rgba(0.05, 0.09, 0.19, 1); cr.fill()
        if i == k: glow(cr, x, y, 205, 120, t, 14)
        else: rr(cr, x, y, 205, 120, 14); cr.set_source_rgba(*NEON, 0.35); cr.set_line_width(1); cr.stroke()
        text(cr, a, x + 102, y + 50, 18, CYAN, True, True); text(cr, b, x + 102, y + 80, 13, (0.75, 0.85, 1), False, True)

def sc_done(cr, W, H, t):
    cx = W / 2; text(cr, "Ready!", cx, H / 2 - 70, 36, CYAN, True, True)
    for i, s in enumerate(("Alt + Tab   switch windows", "Print   screenshot", "Right edge   sidebar", "Start   everything else")):
        a = min(1.0, max(0.0, t * 1.2 - i * 0.4)); text(cr, s, cx, H / 2 - 20 + i * 32, 16, (0.86, 0.91, 1.0, a), False, True)

SCENES = [sc_intro, sc_taskbar, sc_edge, sc_sidebar, sc_pin, sc_panel, sc_tooltip, sc_modes, sc_apps, sc_done]

class Tour(Gtk.Window):
    def __init__(self):
        super().__init__(title=t("tut_title")); self.set_default_size(1060, 640); self.set_icon_name("lmg-tutorial"); self.idx = 0; self.t0 = GLib.get_monotonic_time()
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); self.add(root)
        mid = Gtk.Box(); root.pack_start(mid, True, True, 0)
        self.area = Gtk.DrawingArea(); self.area.connect("draw", self.on_draw); mid.pack_start(self.area, True, True, 0)
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10); side.set_border_width(24); side.set_size_request(330, -1); side.get_style_context().add_class("lmg-side"); mid.pack_start(side, False, False, 0)
        self.step = Gtk.Label(xalign=0); self.step.get_style_context().add_class("lmg-sub"); side.pack_start(self.step, False, False, 0)
        self.title = Gtk.Label(xalign=0, wrap=True); self.title.get_style_context().add_class("lmg-title"); side.pack_start(self.title, False, False, 0)
        self.body = Gtk.Label(xalign=0, yalign=0, wrap=True); self.body.set_max_width_chars(34); side.pack_start(self.body, True, True, 0)
        tm = Gtk.Label(label=TEAM, xalign=0); tm.get_style_context().add_class("lmg-team"); side.pack_end(tm, False, False, 0)
        bar = Gtk.Box(spacing=10); bar.set_border_width(12); root.pack_start(bar, False, False, 0)
        self.back = Gtk.Button(label=t("tut_back")); self.back.connect("clicked", lambda *_: self.go(-1)); bar.pack_start(self.back, False, False, 0)
        self.dots = Gtk.DrawingArea(); self.dots.set_size_request(-1, 24); self.dots.connect("draw", self.draw_dots); bar.pack_start(self.dots, True, True, 0)
        skip = Gtk.Button(label=t("tut_skip")); skip.connect("clicked", lambda *_: self.destroy()); bar.pack_end(skip, False, False, 0)
        self.next = Gtk.Button(); self.next.get_style_context().add_class("suggested-action"); self.next.connect("clicked", lambda *_: self.go(1)); bar.pack_end(self.next, False, False, 0)
        self.connect("key-press-event", self.on_key); self.refresh()
        if not load_settings().get("light_mode"): GLib.timeout_add(33, self.tick)
        else: GLib.timeout_add(250, self.tick)

    def tick(self): self.area.queue_draw(); return self.get_visible()
    def now(self): return (GLib.get_monotonic_time() - self.t0) / 1e6
    def go(self, d):
        if d > 0 and self.idx == N - 1: self.destroy(); return
        self.idx = max(0, min(N - 1, self.idx + d)); self.t0 = GLib.get_monotonic_time(); self.refresh()
    def on_key(self, w, e):
        k = Gdk.keyval_name(e.keyval)
        if k in ("Right", "space", "Return"): self.go(1)
        elif k == "Left": self.go(-1)
        elif k == "Escape": self.destroy()
    def refresh(self):
        i = self.idx + 1
        self.step.set_text(f"{i} / {N}"); self.title.set_text(t(f"tut_{i}_t"))
        self.body.set_text("\n\n".join("•  " + t(f"tut_{i}_{j}") for j in (1, 2, 3)))
        self.back.set_sensitive(self.idx > 0); self.next.set_label(t("tut_finish") if self.idx == N - 1 else t("tut_next")); self.dots.queue_draw()
    def on_draw(self, w, cr):
        W, H = w.get_allocated_width(), w.get_allocated_height()
        cr.set_source_rgb(0.024, 0.04, 0.08); cr.paint()
        SCENES[self.idx](cr, W, H, self.now()); return False
    def draw_dots(self, w, cr):
        W, H = w.get_allocated_width(), w.get_allocated_height(); x0 = W / 2 - N * 9
        for i in range(N):
            cr.arc(x0 + i * 18 + 9, H / 2, 4.5 if i == self.idx else 3.2, 0, 6.3)
            cr.set_source_rgba(*(CYAN if i == self.idx else (0.2, 0.3, 0.5)), 1); cr.fill()
        return False

def main():
    s = load_settings(); init_i18n(s); load_css(); w = Tour(); w.connect("destroy", Gtk.main_quit); w.show_all(); Gtk.main()

if __name__ == "__main__": main()
