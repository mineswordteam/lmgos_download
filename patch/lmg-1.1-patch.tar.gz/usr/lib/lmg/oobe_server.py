"""LMG OS first-run welcome: the small local web server behind the full-screen page (no GTK in here, so it can be tested anywhere).
Serves /usr/share/lmg/oobe, the wallpapers and the logo, and applies the choices when the page says "finish"."""
import json, os, secrets, subprocess, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

WEB = os.environ.get("LMG_OOBE_WEB", "/usr/share/lmg/oobe")
WALLS = os.environ.get("LMG_WALLS", "/usr/share/backgrounds/lmg")
LOGO = os.environ.get("LMG_LOGO", "/usr/share/lmg/branding/logo-main.png")
LOGO_START = os.environ.get("LMG_LOGO_START", os.path.join(os.path.dirname(LOGO), "logo-start.png"))
HOME = os.environ.get("LMG_USER_HOME") or os.path.expanduser("~")
CONF = os.path.join(HOME, ".config", "lmg")
MARKER = os.path.join(CONF, "oobe-pending")
TRIES = os.path.join(HOME, ".cache", "lmg", "oobe-tries")
MOCK = os.environ.get("LMG_OOBE_MOCK") == "1"          # tests / video: change nothing on the machine
LOCALES = {"en", "fa", "ar", "tr", "ru", "de", "fr", "es", "it", "pt", "zh", "ja", "ko", "hi", "ur"}
LAYOUTS = {"fa": "us,ir", "ar": "us,ara", "ru": "us,ru", "uk": "us,ua", "he": "us,il", "ur": "us,pk", "hi": "us,in", "el": "us,gr"}
WALL_NAMES = ["lmg-mountain", "lmg-neon-grid", "lmg-aurora", "lmg-nebula", "lmg-waves", "lmg-circuit", "lmg-sunset", "lmg-hexagons", "lmg-logo-glow"]
BOOL_KEYS = ("fancy_animations", "light_mode", "sound_enabled", "sidebar_enabled")


def _json(path, default=None):
    try: return json.load(open(path))
    except Exception: return {} if default is None else default


def save_choices(d, home=HOME):
    """Write the user's choices into ~/.config/lmg/settings.json (merge, nothing else touched)."""
    p = os.path.join(home, ".config", "lmg", "settings.json")
    s = _json(p); os.makedirs(os.path.dirname(p), exist_ok=True)
    lang = d.get("lang", "en")
    s["language"] = lang if lang in ("en", "fa") else "en"      # LMG's own apps are translated to English and Persian
    s["system_language"] = lang if lang in LOCALES else "en"
    for k in BOOL_KEYS:
        if k in d: s[k] = bool(d[k])
    if d.get("wall") in WALL_NAMES: s["wallpaper"] = d["wall"]
    json.dump(s, open(p, "w"), ensure_ascii=False)
    return s


def finish_markers(home=HOME):
    os.makedirs(os.path.join(home, ".config", "lmg"), exist_ok=True)
    open(os.path.join(home, ".config", "lmg", "first-run-done"), "a").close()     # the old one-time tutorial is covered by this welcome
    for f in (os.path.join(home, ".config", "lmg", "oobe-pending"), os.path.join(home, ".cache", "lmg", "oobe-tries")):
        try: os.remove(f)
        except OSError: pass


def apply_choices(d):
    """Everything outside settings.json. Runs after the response is sent; the admin steps go to the background so a slow
    password prompt (non-admin user) can never keep the person locked in."""
    s = save_choices(d)
    if MOCK: return s
    wall = d.get("wall")
    if wall in WALL_NAMES:
        try:
            import lmg_walls
            lmg_walls.set_wallpaper(os.path.join(WALLS, wall + ".jpg"))
        except Exception: pass
    lang = d.get("lang", "en")
    if lang in LAYOUTS:
        lay = LAYOUTS[lang]; open(os.path.join(CONF, "keyboard.sh"), "w").write("#!/bin/sh\nsetxkbmap -layout %s -option grp:alt_shift_toggle\n" % lay)
        os.chmod(os.path.join(CONF, "keyboard.sh"), 0o755)
    jobs = []
    if lang in LOCALES: jobs.append(["pkexec", "/usr/lib/lmg/bin/lmg-helper", "locale-set", lang])
    if d.get("fastboot"): jobs.append(["pkexec", "/usr/lib/lmg/bin/lmg-helper", "fastboot-on"])
    if "usb_guard" in d: jobs.append(["pkexec", "/usr/lib/lmg/bin/lmg-helper", "usb-config", "guard", "on" if d["usb_guard"] else "off"])
    # run after this window is gone, detached: the welcome must never wait for them (or keep a black screen up)
    import shlex
    script = "sleep 1; lmg-session-apply >/dev/null 2>&1; " + "; ".join("timeout 90 " + " ".join(shlex.quote(x) for x in j) + " >/dev/null 2>&1" for j in jobs)
    subprocess.Popen(["sh", "-c", script], start_new_session=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return s


class Server:
    def __init__(self, on_done=None, on_ready=None):
        self.token = secrets.token_urlsafe(12); self.on_done = on_done; self.on_ready = on_ready
        self.result = None; self.ready = False
        srv = self
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _send(self, code, body, ctype="application/json"):
                if isinstance(body, (dict, list)): body = json.dumps(body).encode()
                self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(body)
            def _file(self, path, ctype):
                try: data = open(path, "rb").read()
                except OSError: return self._send(404, b"", "text/plain")
                self._send(200, data, ctype)
            def do_GET(self):
                p = self.path.split("?")[0]
                if p == "/":
                    try: html = open(os.path.join(WEB, "index.html"), encoding="utf-8").read().replace("__TOKEN__", srv.token)
                    except OSError: return self._send(404, b"", "text/plain")
                    return self._send(200, html.encode(), "text/html; charset=utf-8")
                if p == "/logo.png": return self._file(LOGO, "image/png")
                if p == "/logo-start.png": return self._file(LOGO_START, "image/png")
                if p.startswith("/walls/") or p.startswith("/thumbs/"):
                    n = os.path.basename(p)
                    if n[:-4] in WALL_NAMES and n.endswith(".jpg"):
                        return self._file(os.path.join(WALLS, "thumbs" if p.startswith("/thumbs/") else "", n), "image/jpeg")
                    return self._send(404, b"", "text/plain")
                if p == "/api/info":
                    return self._send(200, {"user": os.environ.get("USER", ""), "mock": MOCK, "walls": WALL_NAMES,
                                            "sudo": _in_sudo(), "dev": os.environ.get("LMG_OOBE_DEV") == "1"})
                if p.startswith("/f/"):               # fonts shipped with the page (optional)
                    return self._file(os.path.join(WEB, "fonts", os.path.basename(p)), "font/ttf")
                self._send(404, b"", "text/plain")
            def do_POST(self):
                if self.headers.get("X-Token") != srv.token: return self._send(403, {"ok": False})
                n = int(self.headers.get("Content-Length", 0) or 0)
                try: d = json.loads(self.rfile.read(n) or b"{}")
                except Exception: d = {}
                p = self.path.split("?")[0]
                if p == "/api/ready":
                    srv.ready = True
                    if srv.on_ready: srv.on_ready()
                    return self._send(200, {"ok": True})
                if p == "/api/wall":
                    if d.get("name") in WALL_NAMES and not MOCK:
                        try:
                            import lmg_walls; lmg_walls.set_wallpaper(os.path.join(WALLS, d["name"] + ".jpg"))
                        except Exception: pass
                    return self._send(200, {"ok": True})
                if p == "/api/finish":
                    srv.result = d
                    try: apply_choices(d)
                    except Exception as e: return self._send(200, {"ok": False, "error": str(e)})
                    finish_markers() if not MOCK else None
                    self._send(200, {"ok": True})
                    if srv.on_done: threading.Timer(2.2, srv.on_done).start()
                    return
                self._send(404, {"ok": False})
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    @property
    def url(self): return "http://127.0.0.1:%d/" % self.port
    def stop(self): self.httpd.shutdown()


def _in_sudo():
    try:
        import grp
        return os.environ.get("USER", "") in grp.getgrnam("sudo").gr_mem or os.getgid() in (grp.getgrnam("sudo").gr_gid,)
    except Exception:
        return False
