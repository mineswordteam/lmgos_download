#!/usr/bin/python3
"""Runs at every sign-in. Puts the desktop shortcuts that came with a newer LMG OS on the user's desktop - ONCE each
(like Windows' shared desktop): a shortcut the user deleted is never brought back. Items live in /usr/share/lmg/desktop-items."""
import json, os, shutil, subprocess

SRC = os.environ.get("LMG_DESKTOP_ITEMS", "/usr/share/lmg/desktop-items")
STATE = os.path.expanduser("~/.config/lmg/desktop-offered.json")

def desktop_dir():
    try:
        d = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True, text=True, timeout=5).stdout.strip()
        if d and d != os.path.expanduser("~"): return d
    except Exception: pass
    return os.path.expanduser("~/Desktop")

def main():
    try: done = set(json.load(open(STATE)))
    except Exception: done = set()
    try: items = sorted(f for f in os.listdir(SRC) if f.endswith(".desktop"))
    except OSError: return
    dd = desktop_dir(); os.makedirs(dd, exist_ok=True); changed = False
    for f in items:
        if f in done: continue
        dst = os.path.join(dd, f)
        if not os.path.exists(dst):
            shutil.copy(os.path.join(SRC, f), dst); os.chmod(dst, 0o755)
            subprocess.run(["gio", "set", dst, "metadata::trusted", "true"], capture_output=True)
        done.add(f); changed = True
    if changed:
        os.makedirs(os.path.dirname(STATE), exist_ok=True)
        json.dump(sorted(done), open(STATE, "w"))

if __name__ == "__main__":
    main()
