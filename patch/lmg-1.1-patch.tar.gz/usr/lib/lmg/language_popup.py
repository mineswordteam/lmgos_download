#!/usr/bin/python3
import sys
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *

class Win(Gtk.Window):
    def __init__(self):
        super().__init__(title=t("lang_title")); self.set_default_size(380, 200); self.set_position(Gtk.WindowPosition.CENTER); self.set_icon_name("lmg-language")
        b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=18); self.add(b)
        b.pack_start(heading(t("lang_title"), t("lang_hint")), False, False, 0)
        row = Gtk.Box(spacing=10); b.pack_start(row, False, False, 0)
        self.btns = []
        for code, name in (("en", "English"), ("fa", "فارسی")):
            x = Gtk.Button(label=name); x.get_style_context().add_class("suggested-action"); x.connect("clicked", self.pick, code); row.pack_start(x, True, True, 0); self.btns.append(x)
        self.msg = Gtk.Label(label="", wrap=True, xalign=0); b.pack_start(self.msg, False, False, 0)
        self.out = Gtk.Button(label=t("lang_signout")); self.out.set_no_show_all(True); self.out.connect("clicked", lambda *_: spawn(["xfce4-session-logout", "--logout"])); b.pack_start(self.out, False, False, 0)
    def pick(self, _b, code):
        s = load_settings(); s["language"] = code; save_settings(s)
        for b in self.btns: b.set_sensitive(False)
        init_i18n(s); self.msg.set_text(t("lang_applying"))
        def done(rc):
            for b in self.btns: b.set_sensitive(True)
            self.msg.set_text(t("lang_restart") if rc == 0 else t("lang_restart") + " (" + t("lang_sys_fail") + ")")
            self.out.set_label(t("lang_signout")); self.out.show()
        apply_system_language(code, done)

def main():
    s = load_settings(); init_i18n(s); load_css(); w = Win(); w.connect("destroy", Gtk.main_quit); w.show_all(); w.out.hide(); Gtk.main()
if __name__ == "__main__": main()
