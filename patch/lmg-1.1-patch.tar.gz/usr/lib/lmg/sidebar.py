#!/usr/bin/python3
"""LMG OS right-edge sidebar: hot edge, slide animation, pin (dock/overlay), quick apps, CPU/RAM graphs, power."""
import os, subprocess, sys, time
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *
import psutil
import cairo
from gi.repository import GdkPixbuf
try:
    gi.require_version("GdkX11", "3.0")
    from gi.repository import GdkX11
except Exception:
    GdkX11 = None

W = 300
TASKBAR_FALLBACK = 0

class Graph(Gtk.DrawingArea):
    def __init__(self, color):
        super().__init__(); self.set_size_request(-1, 54); self.data = [0.0] * 60; self.color = color
    def push(self, v):
        self.data.append(v); self.data = self.data[-60:]; self.queue_draw()
    def do_draw(self, cr):
        w, h = self.get_allocated_width(), self.get_allocated_height()
        r, g, b = self.color
        cr.set_source_rgba(0.04, 0.08, 0.16, 0.9); cr.rectangle(0, 0, w, h); cr.fill()
        cr.set_source_rgba(r, g, b, 0.18)
        cr.move_to(0, h)
        for i, v in enumerate(self.data): cr.line_to(i * w / 59.0, h - v * (h - 4))
        cr.line_to(w, h); cr.close_path(); cr.fill()
        cr.set_source_rgba(r, g, b, 1); cr.set_line_width(1.6)
        for i, v in enumerate(self.data):
            (cr.move_to if i == 0 else cr.line_to)(i * w / 59.0, h - v * (h - 4))
        cr.stroke()
        return False

class Sidebar(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL, title="LMG Sidebar")
        self.s = load_settings(); self._mtime = self._conf_mtime()
        self.set_decorated(False); self.set_resizable(False); self.set_keep_above(True); self.stick()
        self.set_skip_taskbar_hint(True); self.set_skip_pager_hint(True); self.set_accept_focus(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.shown = False; self.anim = 0; self.leave_t = None; self.strut_on = False
        self.pinned = bool(self.s.get("sidebar_pinned"))
        self.geom()
        self.set_size_request(W, self.hgt); self.set_default_size(W, self.hgt)
        self.get_style_context().add_class("lmg-sidebar")
        self.build()
        GLib.timeout_add(90, self.poll)
        GLib.timeout_add_seconds(1, self.sample)
        if self.pinned: self.show_panel(animate=False)

    # ---------- geometry ----------
    def geom(self):
        d = Gdk.Display.get_default(); mon = d.get_primary_monitor() or d.get_monitor(0)
        g = mon.get_geometry(); wa = mon.get_workarea()
        self.sx, self.sw = g.x, g.width; self.y0 = wa.y; self.hgt = max(300, wa.height)
        if self.strut_on:  # workarea already excludes our own strut width; fine for height
            pass
    def x_shown(self): return self.sx + self.sw - W
    def x_hidden(self): return self.sx + self.sw

    # ---------- ui ----------
    def build(self):
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10); root.set_border_width(14); self.add(root)
        top = Gtk.Box(spacing=8)
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_size(SHARE + "/branding/logo-main.png", 30, 30); self.logo = Gtk.Image.new_from_pixbuf(pb); top.pack_start(self.logo, False, False, 0)
        except Exception: pass
        nm = Gtk.Label(label="LMG OS"); nm.get_style_context().add_class("lmg-title"); top.pack_start(nm, False, False, 0)
        self.pin = Gtk.ToggleButton(); self.pin.set_tooltip_text(t("sb_pin")); self.pin.get_style_context().add_class("lmg-pin")
        self.pin.add(self._icon(["view-pin-symbolic", "starred-symbolic", "emblem-favorite-symbolic"], t("sb_pin")))
        self.pin.set_active(self.pinned); self.pin.connect("toggled", self.on_pin)
        st = Gtk.Button(); st.set_tooltip_text(t("sb_settings")); st.add(Gtk.Image.new_from_icon_name("preferences-system-symbolic", Gtk.IconSize.BUTTON))
        st.connect("clicked", lambda *_: spawn(["lmg-control-panel", "settings"]))
        top.pack_end(self.pin, False, False, 0); top.pack_end(st, False, False, 0)
        root.pack_start(top, False, False, 0)
        root.pack_start(Gtk.Separator(), False, False, 0)

        apps = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        for label, cmd, icon in self.s.get("quick_apps", [])[:5]:
            b = Gtk.Button(); b.get_style_context().add_class("lmg-sbtn"); h = Gtk.Box(spacing=12)
            h.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            l = Gtk.Label(label=label, xalign=0); h.pack_start(l, True, True, 0); b.add(h)
            b.connect("clicked", lambda _b, c=cmd: spawn(c.split())); apps.pack_start(b, False, False, 0)
        root.pack_start(apps, False, False, 0)
        root.pack_start(Gtk.Separator(), False, False, 0)

        self.cpu_l = Gtk.Label(label="CPU", xalign=0); self.cpu_g = Graph((0.12, 0.56, 1.0))
        self.ram_l = Gtk.Label(label="RAM", xalign=0); self.ram_g = Graph((0.0, 0.82, 1.0))
        for w in (self.cpu_l, self.cpu_g, self.ram_l, self.ram_g): root.pack_start(w, False, False, 0)
        root.pack_start(Gtk.Box(), True, True, 0)

        pw = Gtk.Box(spacing=8, homogeneous=True)
        for label, icon, mode in ((t("logout"), "system-log-out-symbolic", "logout"), (t("restart"), "system-reboot-symbolic", "restart"), (t("shutdown"), "system-shutdown-symbolic", "shutdown")):
            b = Gtk.Button(); b.get_style_context().add_class("lmg-power"); b.set_tooltip_text(label)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2); v.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            sl = Gtk.Label(label=label); sl.set_ellipsize(3); sl.set_max_width_chars(9); v.pack_start(sl, False, False, 0); b.add(v)
            b.connect("clicked", lambda _b, m=mode: spawn(["lmg-power", m])); pw.pack_start(b, True, True, 0)
        root.pack_start(pw, False, False, 0)
        tm = Gtk.Label(label=f"{TEAM}  ·  LMG OS {VERSION}"); tm.get_style_context().add_class("lmg-team"); root.pack_start(tm, False, False, 0)
        root.show_all()

    def _icon(self, names, fallback):
        th = Gtk.IconTheme.get_default()
        for n in names:
            if th.has_icon(n): return Gtk.Image.new_from_icon_name(n, Gtk.IconSize.BUTTON)
        return Gtk.Label(label=fallback)

    # ---------- behaviour ----------
    def _conf_mtime(self):
        try: return os.stat(CONF).st_mtime
        except Exception: return 0

    def sample(self):
        if not self.shown: return True
        if hasattr(self, "logo") and not self.s.get("light_mode"):
            import math; self._ph = getattr(self, "_ph", 0.0) + 0.9; self.logo.set_opacity(0.8 + 0.2 * math.sin(self._ph))
        c = psutil.cpu_percent(interval=None); m = psutil.virtual_memory()
        self.cpu_g.push(c / 100.0); self.ram_g.push(m.percent / 100.0)
        self.cpu_l.set_text(f"{t('cpu_use')}  {c:.0f}%"); self.ram_l.set_text(f"{t('ram_use')}  {human(m.total - m.available)} / {human(m.total)}  ({m.percent:.0f}%)")
        return True

    def on_pin(self, btn):
        self.pinned = btn.get_active(); self.s["sidebar_pinned"] = self.pinned; save_settings(self.s); self._mtime = self._conf_mtime()
        self.apply_strut()

    def apply_strut(self):
        want = self.pinned and self.s.get("sidebar_mode", "dock") == "dock" and self.shown
        if want == self.strut_on and not want: return
        win = self.get_window()
        if not (win and GdkX11 and isinstance(win, GdkX11.X11Window)): return
        xid = win.get_xid()
        vals = f"0,{W},0,0,0,0,{self.y0},{self.y0 + self.hgt},0,0,0,0" if want else "0,0,0,0,0,0,0,0,0,0,0,0"
        v4 = f"0,{W},0,0" if want else "0,0,0,0"
        try:
            subprocess.run(["xprop", "-id", str(xid), "-format", "_NET_WM_STRUT_PARTIAL", "32c", "-set", "_NET_WM_STRUT_PARTIAL", vals], timeout=3, capture_output=True)
            subprocess.run(["xprop", "-id", str(xid), "-format", "_NET_WM_STRUT", "32c", "-set", "_NET_WM_STRUT", v4], timeout=3, capture_output=True)
        except Exception: pass
        self.strut_on = want

    def animate_to(self, x_to, done=None):
        if self.anim: GLib.source_remove(self.anim); self.anim = 0
        x_from = self.get_position()[0]; light = bool(self.s.get("light_mode")); t0 = time.time(); dur = 0.0 if light else 0.20
        def step():
            p = 1.0 if dur == 0 else min(1.0, (time.time() - t0) / dur)
            e = 1 - (1 - p) ** 3
            self.move(int(x_from + (x_to - x_from) * e), self.y0)
            if p >= 1.0:
                self.anim = 0
                if done: done()
                return False
            return True
        self.anim = GLib.timeout_add(12, step)

    def show_panel(self, animate=True):
        if self.shown: return
        self.geom(); self.set_size_request(W, self.hgt); self.resize(W, self.hgt)
        self.move(self.x_hidden(), self.y0); self.show_all(); self.shown = True
        GLib.idle_add(self.apply_strut)
        if animate: self.animate_to(self.x_shown())
        else: self.move(self.x_shown(), self.y0)
        self.sample()

    def hide_panel(self):
        if not self.shown: return
        self.shown = False
        def fin(): self.hide(); self.apply_strut()
        self.animate_to(self.x_hidden(), fin)

    def poll(self):
        m = self._conf_mtime()
        if m != self._mtime:
            self._mtime = m; self.s = load_settings(); p = bool(self.s.get("sidebar_pinned"))
            if p != self.pinned:
                self.pinned = p; self.pin.handler_block_by_func(self.on_pin); self.pin.set_active(p); self.pin.handler_unblock_by_func(self.on_pin)
                if p: self.show_panel()
            self.apply_strut()
        if not self.s.get("sidebar_enabled", True):
            if self.shown:
                self.shown = False; self.hide(); self.apply_strut()
            return True
        disp = Gdk.Display.get_default(); seat = disp.get_default_seat()
        if not seat: return True
        _s, x, y = seat.get_pointer().get_position()
        right = self.sx + self.sw
        in_edge = x >= right - 1 and self.y0 <= y <= self.y0 + self.hgt
        in_panel = self.shown and x >= right - W - 4
        if in_edge and not self.shown: self.show_panel()
        if self.shown and not self.pinned:
            if in_panel: self.leave_t = None
            else:
                if self.leave_t is None: self.leave_t = time.time()
                elif time.time() - self.leave_t > 0.45 and not self.has_modal(): self.leave_t = None; self.hide_panel()
        if self.pinned and not self.shown: self.show_panel()
        return True

    def has_modal(self):
        return any(w is not self and w.get_visible() and w.get_modal() for w in Gtk.Window.list_toplevels())

def main():
    s = load_settings(); init_i18n(s); load_css()
    sb = Sidebar(); Gtk.main()

if __name__ == "__main__":
    main()
