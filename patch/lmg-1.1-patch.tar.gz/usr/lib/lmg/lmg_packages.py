#!/usr/bin/python3
"""LMG Package Manager: a graphical `apt`. Search, install and remove packages; system packages are locked."""
import os, subprocess, sys
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *

BASE_LIST = SHARE + "/base-packages.txt"

def read_base():
    try: return set(l.strip() for l in open(BASE_LIST) if l.strip())
    except Exception: return set()

def read_installed():
    out = {}
    r = subprocess.run(["dpkg-query", "-W", "-f", "${Package}\t${Version}\t${db:Status-Abbrev}\n"], capture_output=True, text=True)
    for l in r.stdout.splitlines():
        p = l.split("\t")
        if len(p) == 3 and p[2].startswith("ii"): out[p[0]] = p[1]
    return out

def read_all():
    r = subprocess.run(["apt-cache", "search", "."], capture_output=True, text=True, env=dict(os.environ, LC_ALL="C"))
    res = []
    for l in r.stdout.splitlines():
        n, _, d = l.partition(" - ")
        if n: res.append((n, d))
    return res

class Win(Gtk.Window):
    def __init__(self):
        super().__init__(title=t("pm_title")); self.set_default_size(980, 640); self.set_icon_name("lmg-packages")
        self.base, self.inst, self.busy = read_base(), {}, False
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8); root.set_margin_start(14); root.set_margin_end(14); root.set_margin_top(12); root.set_margin_bottom(12)
        self.add(root)
        root.pack_start(heading(t("pm_title"), t("pm_sub")), False, False, 0)
        bar = Gtk.Box(spacing=8)
        self.entry = Gtk.SearchEntry(placeholder_text=t("pm_search")); self.entry.connect("search-changed", lambda *_: self.later()); bar.pack_start(self.entry, True, True, 0)
        self.mode = Gtk.ComboBoxText()
        for k, v in (("all", "pm_all"), ("inst", "pm_installed"), ("avail", "pm_available")): self.mode.append(k, t(v))
        self.mode.set_active_id("inst"); self.mode.connect("changed", lambda *_: self.later()); bar.pack_start(self.mode, False, False, 0)
        self.btn_ref = Gtk.Button(label=t("pm_refresh")); self.btn_ref.connect("clicked", self.on_refresh); bar.pack_start(self.btn_ref, False, False, 0)
        root.pack_start(bar, False, False, 0)
        self.store = Gtk.ListStore(str, str, str, str)   # name, version, status, description
        self.rows, self.low, self.timer = [], [], 0                   # every package (name, version, status, description, search text) - only the first MAX_ROWS matches go in the list
        tv = Gtk.TreeView(model=self.store); self.tv = tv
        for i, (title, w) in enumerate(((t("pm_name"), 230), (t("pm_version"), 150), (t("pm_status"), 120), (t("pm_desc"), 400))):
            c = Gtk.TreeViewColumn(title, Gtk.CellRendererText(ellipsize=3), text=i); c.set_resizable(True); c.set_min_width(w if i < 3 else 100); c.set_expand(i == 3); tv.append_column(c)
        tv.connect("cursor-changed", self.on_sel)
        sw = Gtk.ScrolledWindow(); sw.add(tv); sw.set_vexpand(True); root.pack_start(sw, True, True, 0)
        act = Gtk.Box(spacing=8)
        self.info = Gtk.Label(label=t("pm_loading"), xalign=0); act.pack_start(self.info, True, True, 0)
        self.btn_i = Gtk.Button(label=t("pm_install")); self.btn_i.connect("clicked", lambda *_: self.act("install")); self.btn_i.set_sensitive(False)
        self.btn_r = Gtk.Button(label=t("pm_remove")); self.btn_r.connect("clicked", lambda *_: self.act("remove")); self.btn_r.set_sensitive(False)
        act.pack_end(self.btn_r, False, False, 0); act.pack_end(self.btn_i, False, False, 0)
        root.pack_start(act, False, False, 0)
        self.log = Gtk.TextView(editable=False, monospace=True); ls = Gtk.ScrolledWindow(); ls.set_size_request(-1, 110); ls.add(self.log); root.pack_start(ls, False, False, 0)
        self.show_all(); self.reload()

    # data
    MAX_ROWS = 300

    def later(self):
        if self.timer: GLib.source_remove(self.timer)
        self.timer = GLib.timeout_add(250, self.show_rows)

    def reload(self):
        self.info.set_text(t("pm_loading"))
        def work(): return read_installed(), read_all()
        def done(res):
            if isinstance(res, Exception): self.info.set_text(str(res)); return
            self.inst, allp = res
            self.rows = []; seen = set()
            for n, d in allp:
                seen.add(n); self.rows.append((n, d))
            for n in self.inst:
                if n not in seen: self.rows.append((n, ""))
            self.low = [(n + " " + (d or "")).lower() for n, d in self.rows]
            self.show_rows()
            self.info.set_text(t("pm_ready").format(len(self.inst), len(allp)))
        in_thread(work, done)

    def show_rows(self):
        self.timer = 0
        q = self.entry.get_text().strip().lower(); m = self.mode.get_active_id(); out = []
        for (n, d), low in zip(self.rows, self.low):
            isin = n in self.inst
            if m == "inst" and not isin: continue
            if m == "avail" and isin: continue
            if q and q not in low: continue
            out.append([n, self.inst.get(n, ""), self.status(n), d])
            if len(out) >= self.MAX_ROWS: break
        self.tv.set_model(None); self.store.clear()
        for r in out: self.store.append(r)
        self.tv.set_model(self.store)
        return False

    def status(self, n):
        if n in self.base: return t("pm_system")
        return t("pm_installed") if n in self.inst else t("pm_available")

    def current(self):
        m, p = self.tv.get_selection().get_selected()
        return (m[p][0], m) if p else (None, None)

    def on_sel(self, *_):
        n, _m = self.current()
        if not n or self.busy: return
        isin, sysp = n in self.inst, n in self.base
        self.btn_i.set_sensitive(not isin); self.btn_r.set_sensitive(isin and not sysp)
        self.info.set_text(n + (" - " + t("pm_locked") if sysp else ""))

    # actions
    def say(self, line):
        b = self.log.get_buffer(); b.insert(b.get_end_iter(), line + "\n")
        self.log.scroll_mark_onscreen(b.get_insert())

    def set_busy(self, on):
        self.busy = on; self.btn_ref.set_sensitive(not on); self.btn_i.set_sensitive(False); self.btn_r.set_sensitive(False)
        if not on: self.on_sel()

    def run_admin(self, args, after):
        self.set_busy(True); self.info.set_text(t("pm_working"))
        def done(rc):
            self.set_busy(False); after(rc)
        stream_cmd(admin_cmd(*args), self.say, done)

    def on_refresh(self, *_):
        self.run_admin(["pkg-update"], lambda rc: self.reload())

    def act(self, what):
        n, _m = self.current()
        if not n: return
        if what == "install":
            if not confirm(self, t("pm_confirm_install").format(n)): return
            self.run_admin(["pkg-install", n], self.finish)
        else:
            if n in self.base: self.say(t("pm_blocked")); return
            self.set_busy(True); self.info.set_text(t("pm_working"))
            def plan(): return subprocess.run(admin_cmd("pkg-plan", n), capture_output=True, text=True)
            def got(r):
                self.set_busy(False)
                if isinstance(r, Exception) or r.returncode != 0:
                    self.say((getattr(r, "stderr", "") or str(r)).strip() or t("pm_failed")); return
                extra = [x for x in r.stdout.split() if x != n]
                detail = (t("pm_also") + ": " + ", ".join(extra)) if extra else None
                if confirm(self, t("pm_confirm_remove").format(n), detail): self.run_admin(["pkg-remove", n], self.finish)
            in_thread(plan, got)

    def finish(self, rc):
        self.say(t("pm_done") if rc == 0 else (t("pm_blocked") if rc == 5 else t("pm_failed"))); self.reload()

def main():
    s = load_settings(); init_i18n(s); load_css()
    w = Win(); w.connect("destroy", Gtk.main_quit); Gtk.main()

if __name__ == "__main__":
    main()
