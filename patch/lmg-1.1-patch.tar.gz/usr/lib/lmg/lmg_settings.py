#!/usr/bin/python3
"""LMG Settings: its own app (moved out of the Control Panel). Category list on the left, one section per page."""
import importlib, sys
sys.path.insert(0, "/usr/lib/lmg"); sys.path.insert(0, "/usr/lib/lmg/modules")
from lmgcommon import *

CATS = [("appearance", "applications-graphics-symbolic", "appearance"), ("sidebar", "view-sidebar-symbolic", "sidebar"),
        ("startup", "system-run-symbolic", "set_startup"), ("keyboard", "input-keyboard-symbolic", "keyboard"),
        ("tools", "preferences-system-symbolic", "system_tools")]

class Win(Gtk.Window):
    def __init__(self, start="appearance"):
        super().__init__(title=t("settings")); self.set_default_size(900, 620); self.set_icon_name("lmg-settings")
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL); self.add(paned)
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); side.get_style_context().add_class("lmg-side")
        title = Gtk.Label(label=t("settings")); title.get_style_context().add_class("lmg-title"); title.set_margin_top(16); title.set_margin_bottom(10)
        side.pack_start(title, False, False, 0)
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=150)
        self.btns = {}
        mod = importlib.import_module("settings")
        for key, icon, label in CATS:
            b = Gtk.Button(); b.get_style_context().add_class("lmg-nav"); b.set_relief(Gtk.ReliefStyle.NONE)
            h = Gtk.Box(spacing=8); h.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON), False, False, 0)
            h.pack_start(Gtk.Label(label=t(label), xalign=0), True, True, 0); b.add(h)
            b.connect("clicked", lambda _b, k=key: self.show(k)); side.pack_start(b, False, False, 0); self.btns[key] = b
            page = mod.Page(self, section=key); page.show_all(); self.stack.add_named(page, key)
        paned.pack1(side, False, False); paned.pack2(self.stack, True, False); paned.set_position(210)
        self.show_all(); self.show(start if start in self.btns else "appearance")

    def show(self, k):
        self.stack.set_visible_child_name(k)
        for n, b in self.btns.items():
            (b.get_style_context().add_class if n == k else b.get_style_context().remove_class)("active")

def main():
    s = load_settings(); init_i18n(s); load_css()
    w = Win(sys.argv[1] if len(sys.argv) > 1 else "appearance"); w.connect("destroy", Gtk.main_quit); Gtk.main()

if __name__ == "__main__":
    main()
