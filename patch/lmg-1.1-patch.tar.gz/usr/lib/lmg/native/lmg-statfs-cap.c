/* LMG OS: older 32-bit Windows games (e.g. Call of Duty 4) read the free disk space into a 32-bit number. On a big disk it overflows,
 * the game thinks "less than 5 MB free" and refuses to save its settings. This library (LD_PRELOAD, only for 32-bit Windows programs
 * started through lmg-wine-run) reports at most ~1.9 GB of free space and a disk of at most ~1.95 GB.
 * Build: gcc -O2 -shared -fPIC -o lmg-statfs-cap.so lmg-statfs-cap.c -ldl */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <sys/statfs.h>
#include <sys/statvfs.h>

#define CAP_FREE  (1900ULL << 20)
#define CAP_TOTAL (1950ULL << 20)

static void cap_statfs(struct statfs *s) {
    unsigned long long bs = s->f_bsize ? (unsigned long long)s->f_bsize : 4096ULL;
    if (s->f_bavail * bs > CAP_FREE) s->f_bavail = CAP_FREE / bs;
    if (s->f_bfree * bs > CAP_FREE) s->f_bfree = CAP_FREE / bs;
    if (s->f_blocks * bs > CAP_TOTAL) s->f_blocks = CAP_TOTAL / bs;
}
static void cap_statvfs(struct statvfs *s) {
    unsigned long long bs = s->f_frsize ? (unsigned long long)s->f_frsize : 4096ULL;
    if (s->f_bavail * bs > CAP_FREE) s->f_bavail = CAP_FREE / bs;
    if (s->f_bfree * bs > CAP_FREE) s->f_bfree = CAP_FREE / bs;
    if (s->f_blocks * bs > CAP_TOTAL) s->f_blocks = CAP_TOTAL / bs;
}
int statfs(const char *p, struct statfs *s)      { static int (*f)(const char *, struct statfs *); if (!f) f = dlsym(RTLD_NEXT, "statfs");   int r = f(p, s);  if (!r) cap_statfs(s);  return r; }
int fstatfs(int fd, struct statfs *s)            { static int (*f)(int, struct statfs *);          if (!f) f = dlsym(RTLD_NEXT, "fstatfs");  int r = f(fd, s); if (!r) cap_statfs(s);  return r; }
int statvfs(const char *p, struct statvfs *s)    { static int (*f)(const char *, struct statvfs *); if (!f) f = dlsym(RTLD_NEXT, "statvfs"); int r = f(p, s);  if (!r) cap_statvfs(s); return r; }
int fstatvfs(int fd, struct statvfs *s)          { static int (*f)(int, struct statvfs *);          if (!f) f = dlsym(RTLD_NEXT, "fstatvfs"); int r = f(fd, s); if (!r) cap_statvfs(s); return r; }
int statfs64(const char *p, struct statfs64 *s)   { static int (*f)(const char *, struct statfs64 *); if (!f) f = dlsym(RTLD_NEXT, "statfs64");   int r = f(p, s);  if (!r) cap_statfs((struct statfs *)s);  return r; }
int fstatfs64(int fd, struct statfs64 *s)         { static int (*f)(int, struct statfs64 *);          if (!f) f = dlsym(RTLD_NEXT, "fstatfs64");  int r = f(fd, s); if (!r) cap_statfs((struct statfs *)s);  return r; }
int statvfs64(const char *p, struct statvfs64 *s) { static int (*f)(const char *, struct statvfs64 *); if (!f) f = dlsym(RTLD_NEXT, "statvfs64"); int r = f(p, s);  if (!r) cap_statvfs((struct statvfs *)s); return r; }
int fstatvfs64(int fd, struct statvfs64 *s)       { static int (*f)(int, struct statvfs64 *);          if (!f) f = dlsym(RTLD_NEXT, "fstatvfs64"); int r = f(fd, s); if (!r) cap_statvfs((struct statvfs *)s); return r; }
