"""LMG OS 1.1: "LMG Upgrade" was never a separate app (upgrades live in the Control Panel): take its shortcuts back."""
def migrate(ctx):
    ctx.undo_shortcut("lmg-upgrade.desktop", "LMG-Upgrade.desktop")
