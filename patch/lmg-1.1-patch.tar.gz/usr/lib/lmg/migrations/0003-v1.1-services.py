"""LMG OS 1.1: Minesword Services appears in the Start menu's Favorites tab (the desktop shortcut comes from desktop_sync)."""
def migrate(ctx):
    ctx.start_menu_favorites(["minesword-services.desktop"])
