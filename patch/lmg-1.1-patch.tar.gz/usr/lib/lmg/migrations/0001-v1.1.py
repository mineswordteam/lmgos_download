"""LMG OS 1.1: new defaults for users who had 1.0 (only where they have no value of their own)."""
def migrate(ctx):
    # no screen lock / screensaver by default (it asked for an unknown password in the live session)
    ctx.xfconf_default("xfce4-screensaver", "/saver/enabled", "bool", "false")
    ctx.xfconf_default("xfce4-screensaver", "/saver/idle-activation/enabled", "bool", "false")
    ctx.xfconf_default("xfce4-screensaver", "/lock/enabled", "bool", "false")
    ctx.xfconf_default("xfce4-screensaver", "/lock/saver-activation/enabled", "bool", "false")
    ctx.xfconf_default("xfce4-power-manager", "/xfce4-power-manager/lock-screen-suspend-hibernate", "bool", "false")
    # the sidebar can be switched off in 1.1: on by default
    ctx.setting_default("sidebar_enabled", True)
