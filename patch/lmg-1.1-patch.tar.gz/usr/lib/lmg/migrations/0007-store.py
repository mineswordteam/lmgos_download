"""LMG OS 1.1: the LMG Store is in the Start menu's Favorites tab."""
def migrate(ctx):
    ctx.start_menu_favorites(["lmg-store.desktop"])
