"""LMG OS 1.1: every LMG app is in the Start menu's Favorites tab."""
def migrate(ctx):
    ctx.start_menu_favorites(["lmg-control-panel.desktop", "lmg-settings.desktop", "lmg-packages.desktop",
        "minesword-services.desktop", "lmg-connector.desktop", "minesword-playbox.desktop",
        "lmg-tutorial.desktop", "lmg-taskmgr.desktop"])
