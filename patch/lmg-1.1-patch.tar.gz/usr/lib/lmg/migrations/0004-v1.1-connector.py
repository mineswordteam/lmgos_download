"""LMG OS 1.1: LMG Connector appears in the Start menu's Favorites tab."""
def migrate(ctx):
    ctx.start_menu_favorites(["lmg-connector.desktop"])
