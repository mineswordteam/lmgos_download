"""LMG OS 1.1: the new apps appear in the Start menu's Favorites tab (existing favorites stay as they are)."""
def migrate(ctx):
    ctx.start_menu_favorites(["lmg-settings.desktop", "lmg-packages.desktop", "minesword-playbox.desktop"])
