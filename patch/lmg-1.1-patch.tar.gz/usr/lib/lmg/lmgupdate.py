"""LMG OS update engine (runs as root). Used by lmg-helper (check / download / prepare) and by lmg-offline-update
(install / verify / optimize / finalize / rollback while the system is restarted into the update screen).

Nothing here is a simulation: every step runs the real command and reports real progress.
"""
import glob, json, os, re, shutil, subprocess, time

VAR = os.environ.get("LMG_VAR", "/var/lib/lmg")
RUN = os.environ.get("LMG_RUN", "/run/lmg")
LOG = os.environ.get("LMG_LOG", "/var/log/lmg-update.log")
ARCHIVES = os.environ.get("LMG_ARCHIVES", "/var/cache/apt/archives")
DPKG_STATUS = os.environ.get("LMG_DPKG_STATUS", "/var/lib/dpkg/status")
DPKG_INFO = os.environ.get("LMG_DPKG_INFO", "/var/lib/dpkg/info")
ROOT = os.environ.get("LMG_ROOT", "/")
RB = VAR + "/rollback"
STATE = RUN + "/update-state.json"          # live progress (read by the Control Panel)
INFO = VAR + "/update-info.json"            # result of the last check
PLAN = VAR + "/update-plan.json"            # what the prepared update will change (used to verify it)
RESULT = VAR + "/update-result.json"        # outcome of the last install / rollback (shown after the restart)

APT_OPTS = ["-y", "-o", "Dpkg::Options::=--force-confdef", "-o", "Dpkg::Options::=--force-confold",
            "-o", "Dpkg::Use-Pty=0", "-o", "APT::Color=0"]


# ------------------------------------------------------------------ small helpers
def env():
    return dict(os.environ, DEBIAN_FRONTEND="noninteractive", LC_ALL="C", APT_LISTCHANGES_FRONTEND="none",
                NEEDRESTART_MODE="a", PATH=os.environ.get("LMG_PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"))


def log(msg):
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        with open(LOG, "a", encoding="utf-8", errors="replace") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + str(msg).rstrip("\n") + "\n")
    except Exception:
        pass


def write_json(path, obj, mode=0o644):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def set_state(**kw):
    st = read_json(STATE, {}) or {}
    st.update(kw)
    st["ts"] = int(time.time())
    try:
        write_json(STATE, st)
    except Exception:
        pass
    return st


def is_live():
    try:
        return "boot=live" in open("/proc/cmdline").read()
    except Exception:
        return False


def tail_log(n=60):
    try:
        with open(LOG, encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-n:])
    except Exception:
        return ""


def human(n):
    n = float(n)
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


def run_logged(cmd, pass_fd_cb=None, timeout=None):
    """Run cmd, append its output to the log. pass_fd_cb(line) receives apt's machine-readable status lines
    (apt is told to write them to a private pipe). Returns the exit code."""
    log("$ " + " ".join(cmd))
    with open(LOG, "ab") as lf:
        if pass_fd_cb is None:
            try:
                return subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT, env=env(), timeout=timeout).returncode
            except Exception as e:
                log(f"error: {e}")
                return 1
        r, w = os.pipe()
        full = list(cmd)
        i = full.index("{FD}") if "{FD}" in full else -1
        if i >= 0:
            full[i] = f"APT::Status-Fd={w}"
        p = subprocess.Popen(full, stdout=lf, stderr=subprocess.STDOUT, env=env(), pass_fds=(w,))
        os.close(w)
        with os.fdopen(r, encoding="utf-8", errors="replace") as rf:
            for line in rf:
                try:
                    pass_fd_cb(line.strip())
                except Exception:
                    pass
        return p.wait()


def parse_status_line(line):
    """apt status-fd lines: 'dlstatus:1:23.4:Downloading ...' / 'pmstatus:pkg:45.0:Installing pkg (ver)'.
    Returns (kind, percent, message) or None."""
    parts = line.split(":", 3)
    if len(parts) < 4 or parts[0] not in ("dlstatus", "pmstatus"):
        return None
    try:
        pct = float(parts[2])
    except ValueError:
        return None
    return parts[0], pct, parts[3]


# ------------------------------------------------------------------ package sources
def _drop_src_types(txt, deb822):
    """Source-code indexes (deb-src, ~14 MB) are never needed to update: drop them."""
    if deb822:
        return re.sub(r"(?m)^(Types:.*?)\s*\bdeb-src\b", lambda m: m.group(1), txt)
    return "\n".join(l for l in txt.splitlines() if not l.lstrip().startswith("deb-src")) + ("\n" if txt.endswith("\n") else "")

def clean_sources():
    """Remove stale sources (the install medium) and source-code indexes so one dead source can never block the updates."""
    changed = False
    files = ["/etc/apt/sources.list"] + glob.glob("/etc/apt/sources.list.d/*")
    for f in files:
        try:
            if not os.path.isfile(f):
                continue
            txt = open(f, encoding="utf-8", errors="replace").read()
            new_txt = _drop_src_types(txt, f.endswith(".sources"))
            if new_txt != txt:
                open(f, "w").write(new_txt); txt = new_txt; changed = True
            if "/run/live/medium" not in txt and "cdrom:" not in txt:
                continue
            if f.endswith(".sources"):
                blocks = re.split(r"\n\s*\n", txt)
                keep = [b for b in blocks if "/run/live/medium" not in b and "cdrom:" not in b]
                new = "\n\n".join(keep).strip()
                if new:
                    open(f, "w").write(new + "\n")
                else:
                    os.remove(f)
            else:
                lines = [l for l in txt.splitlines() if "/run/live/medium" not in l and "cdrom:" not in l]
                if any(l.strip() and not l.strip().startswith("#") for l in lines):
                    open(f, "w").write("\n".join(lines) + "\n")
                elif f != "/etc/apt/sources.list":
                    os.remove(f)
                else:
                    open(f, "w").write("\n".join(lines) + "\n")
            changed = True
        except Exception as e:
            log(f"clean_sources {f}: {e}")
    return changed

def apt_update():
    """apt-get update. Only the things that matter must succeed: the Release files and the amd64 package lists.
    A failing translation / source / extra index (flaky mirror, slow link) does not make the check 'offline'."""
    r = subprocess.run(["apt-get", "update", "-o", "Acquire::Retries=2", "-o", "Acquire::http::Timeout=20",
                        "-o", "Acquire::https::Timeout=20", "-o", "Acquire::Languages=none"], capture_output=True, text=True, env=env())
    out = (r.stdout or "") + (r.stderr or "")
    log("$ apt-get update\n" + out)
    if r.returncode == 0:
        return True
    lines = out.splitlines()
    debian_ok = any(l.startswith(("Hit:", "Get:")) and "debian" in l for l in lines)
    def critical(l):
        if not l.startswith(("Err:", "E:")):
            return False
        if "debian" not in l:
            return False
        return bool(re.search(r"InRelease|/Release|Release file|amd64 Packages|binary-amd64", l))
    return debian_ok and not any(critical(l) for l in lines)


# ------------------------------------------------------------------ what would change
def pending():
    r = subprocess.run(["apt-get", "-s", "dist-upgrade"], capture_output=True, text=True, env=env())
    out = []
    for l in r.stdout.splitlines():
        m = re.match(r"^Inst (\S+)(?: \[([^\]]+)\])? \((\S+) ", l)
        if m:
            out.append({"name": m.group(1), "old": m.group(2), "new": m.group(3)})
    return out


def remaining_bytes():
    """Bytes still to download (apt does not list what is already in the cache)."""
    r = subprocess.run(["apt-get", "--print-uris", "-y", "dist-upgrade"], capture_output=True, text=True, env=env())
    total = 0
    for l in r.stdout.splitlines():
        if l.startswith("'"):
            p = l.split()
            if len(p) >= 3 and p[2].isdigit():
                total += int(p[2])
    return total


def cached_bytes(pk):
    tot = 0
    for p in pk:
        n = p["name"].split(":")[0]
        for f in glob.glob(f"{ARCHIVES}/{n}_*.deb"):
            try:
                tot += os.path.getsize(f)
            except OSError:
                pass
    return tot


def check():
    """Look for updates. Writes INFO. Returns the info dict (or {'error': ...})."""
    if is_live():
        return {"live": True}
    clean_sources()
    set_state(phase="checking", percent=0, error=None)
    if not apt_update():
        info = read_json(INFO, {}) or {}
        info.update({"error": "offline", "checked": int(time.time())})
        write_json(INFO, info)
        set_state(phase="idle", error="offline")
        return info
    pk = pending()
    rem = remaining_bytes() if pk else 0
    info = {"checked": int(time.time()), "count": len(pk), "remaining": rem,
            "total": rem + (cached_bytes(pk) if pk else 0),
            "downloaded": bool(pk) and rem == 0,
            "packages": [p["name"] for p in pk[:12]], "error": None}
    write_json(INFO, info)
    set_state(phase="ready" if info["downloaded"] else "idle", percent=100 if info["downloaded"] else 0,
              count=info["count"], error=None)
    return info


# ------------------------------------------------------------------ download (step 1)
def download():
    """Download every update, install nothing. Progress goes to STATE (the panel shows percent + bar, no log)."""
    if is_live():
        return 3
    set_state(phase="downloading", percent=0, error=None, message="")
    cmd = ["apt-get"] + APT_OPTS + ["-d", "-o", "{FD}", "-o", "Acquire::Retries=3", "dist-upgrade"]

    def cb(line):
        s = parse_status_line(line)
        if s and s[0] == "dlstatus":
            set_state(phase="downloading", percent=round(s[1], 1))
    rc = run_logged(cmd, cb)
    if rc != 0:
        err = tail_log(25)
        set_state(phase="error", error="download", message=err)
        return 1
    info = check_after_download()
    set_state(phase="ready", percent=100, count=info.get("count", 0), error=None)
    return 0


def check_after_download():
    pk = pending()
    rem = remaining_bytes() if pk else 0
    info = read_json(INFO, {}) or {}
    info.update({"checked": int(time.time()), "count": len(pk), "remaining": rem,
                 "downloaded": bool(pk) and rem == 0, "error": None, "packages": [p["name"] for p in pk[:12]]})
    info["total"] = max(info.get("total", 0), rem + cached_bytes(pk))
    write_json(INFO, info)
    return info


# ------------------------------------------------------------------ prepare (running system) -> restart
def prepare():
    """Save what will change (for the rollback) and write the plan. Returns (rc, message)."""
    if is_live():
        return 3, "Updates can only be installed on an installed system, not in the live session."
    pk = pending()
    if not pk:
        return 6, "There is nothing to install."
    if remaining_bytes() > 0:
        return 7, "The update is not completely downloaded yet."
    old = [p["name"] for p in pk if p["old"]]
    os.makedirs(RB, exist_ok=True)
    for f in glob.glob(RB + "/*"):
        try:
            os.remove(f)
        except OSError:
            pass
    files = []
    for n in old:
        r = subprocess.run(["dpkg", "-L", n], capture_output=True, text=True)
        for f in r.stdout.splitlines():
            if os.path.lexists(f) and not os.path.isdir(f):
                files.append(f)
        files += glob.glob(f"{DPKG_INFO}/{n}.*") + glob.glob(f"{DPKG_INFO}/{n}:*.*")
    files = sorted(set(files))
    need = sum(os.path.getsize(f) for f in files if os.path.isfile(f) and not os.path.islink(f)) * 1.3 + 200e6
    if shutil.disk_usage(VAR if os.path.isdir(VAR) else "/").free < need:
        return 4, "Not enough free disk space to keep a rollback copy."
    with open(RB + "/files.lst", "w") as f:
        f.write("\n".join(files) + "\n")
    r = subprocess.run(["tar", "-czf", RB + "/files.tar.gz", "--no-recursion", "-T", RB + "/files.lst"],
                       capture_output=True, text=True)
    if r.returncode > 1:
        return 5, "Could not create the rollback copy."
    shutil.copy(DPKG_STATUS, RB + "/status.bak")
    write_json(RB + "/manifest.json", {"packages": old, "ts": int(time.time())})
    write_json(PLAN, {"packages": pk, "ts": int(time.time())})
    return 0, "ok"


# ------------------------------------------------------------------ stages run at the update screen
def install(progress):
    """Stage 1: extract and install every downloaded package. progress(percent, text)."""
    cmd = ["apt-get"] + APT_OPTS + ["--no-download", "-o", "{FD}", "dist-upgrade"]

    def cb(line):
        s = parse_status_line(line)
        if s and s[0] == "pmstatus":
            m = re.search(r"(Installing|Unpacking|Preparing|Configuring|Removing|Running)\s+(\S+)", s[2])
            progress(s[1], (m.group(1) + " " + m.group(2)) if m else s[2])
    rc = run_logged(cmd, cb)
    if rc != 0:
        log("install failed, trying to finish interrupted configuration")
        run_logged(["dpkg", "--configure", "-a", "--force-confdef", "--force-confold"])
        rc = run_logged(["apt-get"] + APT_OPTS + ["--no-download", "-f", "install"])
    return rc == 0, ("" if rc == 0 else "The packages could not be installed.")


def verify(progress):
    """Stage 2: check that the update really is installed and the package database is healthy."""
    problems = []
    plan = (read_json(PLAN, {}) or {}).get("packages", [])
    n = max(1, len(plan))
    for i, p in enumerate(plan):
        progress(100.0 * i / n, p["name"])
        r = subprocess.run(["dpkg-query", "-W", "-f", "${Version}|${db:Status-Abbrev}", p["name"]],
                           capture_output=True, text=True)
        v = (r.stdout or "").strip().split("|")
        if len(v) != 2 or v[0] != p["new"] or not v[1].startswith("ii"):
            problems.append(f"{p['name']}: expected {p['new']}, found {r.stdout.strip() or 'nothing'}")
    r = subprocess.run(["dpkg", "--audit"], capture_output=True, text=True)
    if r.stdout.strip():
        problems.append("dpkg reports broken packages:\n" + r.stdout.strip()[:600])
    r = subprocess.run(["apt-get", "check"], capture_output=True, text=True, env=env())
    if r.returncode != 0:
        problems.append("apt-get check failed:\n" + (r.stderr or r.stdout).strip()[:600])
    for p in problems:
        log("verify: " + p)
    progress(100, "")
    return (not problems), "; ".join(problems)


def _root_is_rotational():
    src = subprocess.run(["findmnt", "-no", "SOURCE", "/"], capture_output=True, text=True).stdout.strip()
    if not src.startswith("/dev/"):
        return False
    out = subprocess.run(["lsblk", "-s", "-n", "-o", "ROTA,TYPE", src], capture_output=True, text=True).stdout
    return any(l.split()[:2] and l.split()[0] == "1" and "disk" in l for l in out.splitlines())


def _root_fstype():
    return subprocess.run(["findmnt", "-no", "FSTYPE", "/"], capture_output=True, text=True).stdout.strip()


def optimize(progress, budget=600):
    """Stage 3: post-update optimisation. Refresh caches, free the downloaded packages, and
    defragment the files the update wrote when the system disk is a spinning disk (ext4);
    on an SSD run TRIM instead (defragmenting an SSD only wears it)."""
    steps = []
    t0 = time.monotonic()

    def step(name, fn):
        steps.append((name, fn))
    step("Library cache", lambda: run_logged(["ldconfig"]))
    step("Font cache", lambda: run_logged(["fc-cache", "-s"]) if shutil.which("fc-cache") else 0)
    step("Icon cache", lambda: run_logged(["gtk-update-icon-cache", "-f", "-t", "/usr/share/icons/hicolor"]) if shutil.which("gtk-update-icon-cache") else 0)
    step("Menus and file types", lambda: (run_logged(["update-desktop-database"]) if shutil.which("update-desktop-database") else 0,
                                          run_logged(["update-mime-database", "/usr/share/mime"]) if shutil.which("update-mime-database") else 0))
    step("Old package files", lambda: run_logged(["apt-get", "clean"]))
    rot = _root_is_rotational()
    fst = _root_fstype()
    plan = (read_json(PLAN, {}) or {}).get("packages", [])
    if rot and fst == "ext4" and shutil.which("e4defrag"):
        def defrag():
            files = []
            for p in plan:
                r = subprocess.run(["dpkg", "-L", p["name"].split(":")[0]], capture_output=True, text=True)
                files += [f for f in r.stdout.splitlines() if os.path.isfile(f) and not os.path.islink(f)]
            files = sorted(set(files))
            log(f"defragmenting {len(files)} files of the update")
            chunk = 150
            for i in range(0, len(files), chunk):
                if time.monotonic() - t0 > budget:
                    log("defrag time budget reached, stopping")
                    break
                subprocess.run(["e4defrag"] + files[i:i + chunk], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                progress(None, f"Defragmenting {min(len(files), i + chunk)}/{len(files)}")
            return 0
        step("Defragment (hard disk)", defrag)
    elif shutil.which("fstrim"):
        step("Trim (SSD)", lambda: run_logged(["fstrim", "-v", "/"]))
    step("Writing data to disk", lambda: run_logged(["sync"]))
    n = len(steps)
    for i, (name, fn) in enumerate(steps):
        progress(100.0 * i / n, name)
        try:
            fn()
        except Exception as e:
            log(f"optimize step {name}: {e}")
    progress(100, "")
    return True, ""


def finalize(progress):
    """Stage 4: final work (boot loader / initramfs only when the update touched them)."""
    plan = (read_json(PLAN, {}) or {}).get("packages", [])
    names = " ".join(p["name"] for p in plan)
    progress(10, "Checking boot files")
    if re.search(r"\b(linux-image|initramfs-tools|plymouth|lmg-)", names):
        run_logged(["update-initramfs", "-u", "-k", "all"])
    progress(60, "Boot menu")
    if re.search(r"\b(linux-image|grub)", names) and shutil.which("update-grub"):
        run_logged(["update-grub"])
    progress(90, "Saving")
    run_logged(["sync"])
    progress(100, "")
    return True, ""


# ------------------------------------------------------------------ rollback
def backup_ok():
    try:
        if not os.path.exists(RB + "/ready") and not os.path.exists(RB + "/files.tar.gz"):
            return False, "No backup of the previous version exists."
        if not os.path.getsize(RB + "/status.bak"):
            return False, "The backup of the package list is empty."
        r = subprocess.run(["tar", "-tzf", RB + "/files.tar.gz"], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        if r.returncode != 0:
            return False, "The backup archive is damaged."
        return True, ""
    except Exception as e:
        return False, f"The backup could not be read: {e}"


def rollback(progress):
    ok, why = backup_ok()
    if not ok:
        return False, why
    progress(10, "Restoring files")
    r = subprocess.run(["tar", "-xzf", RB + "/files.tar.gz", "-C", ROOT], capture_output=True, text=True)
    if r.returncode > 1:
        log("rollback tar: " + r.stderr[-400:])
        return False, "The previous files could not be restored."
    progress(55, "Restoring the package list")
    shutil.copy(RB + "/status.bak", DPKG_STATUS)
    progress(70, "Checking")
    run_logged(["dpkg", "--configure", "-a", "--force-confdef", "--force-confold"])
    run_logged(["ldconfig"])
    names = " ".join((read_json(RB + "/manifest.json", {}) or {}).get("packages", []))
    if re.search(r"\b(linux-image|initramfs-tools)", names):
        progress(80, "Boot files")
        run_logged(["update-initramfs", "-u", "-k", "all"])
        if shutil.which("update-grub"):
            run_logged(["update-grub"])
    run_logged(["sync"])
    progress(100, "")
    try:
        os.remove(RB + "/ready")
    except OSError:
        pass
    return True, ""


# ------------------------------------------------------------------ result (shown on the desktop after the restart)
def write_result(kind, ok, message="", **extra):
    """kind: update | rollback. Shown on the desktop after the restart (see lmg-update-notify)."""
    d = {"kind": kind, "ok": bool(ok), "message": message, "ts": int(time.time()),
         "log_tail": tail_log(80) if not ok else ""}
    d.update(extra)
    write_json(RESULT, d)
