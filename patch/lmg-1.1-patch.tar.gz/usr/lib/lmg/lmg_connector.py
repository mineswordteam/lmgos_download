#!/usr/bin/python3
"""LMG Connector (desktop side): shows the pairing code and controls the connector server that the Android app talks to."""
import json, os, signal, subprocess, sys, time
sys.path.insert(0, "/usr/lib/lmg")
from lmgcommon import *

SERVER = "/usr/lib/lmg/connector/lmg_connector_server.py"
STATUS = os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), "lmg-connector-%d.json" % os.getuid())
AUTOSTART = os.path.expanduser("~/.config/autostart/lmg-connector-server.desktop")


def pick_ip(ips):
    """The address a phone on the same network is most likely to reach: private ranges first."""
    for pre in ("192.168.", "10.", "172."):
        for ip in ips:
            if ip.startswith(pre): return ip
    return ips[0] if ips else ""


class QrArea(Gtk.DrawingArea):
    """A QR code for a text (here: the address of the phone app on this computer)."""
    def __init__(self, size=210):
        super().__init__(); self.set_size_request(size, size); self.size = size; self.matrix = None
        self.connect("draw", self.on_draw)

    def set_text(self, text):
        try:
            import qrcode
            q = qrcode.QRCode(border=2, error_correction=qrcode.constants.ERROR_CORRECT_M); q.add_data(text); q.make(fit=True)
            self.matrix = q.get_matrix() if text else None
        except Exception:
            self.matrix = None
        self.queue_draw()

    def on_draw(self, _w, cr):
        cr.set_source_rgb(1, 1, 1); cr.paint()
        if not self.matrix: return False
        n = len(self.matrix); cell = self.size / n; cr.set_source_rgb(0, 0, 0)
        for y, row in enumerate(self.matrix):
            for x, on in enumerate(row):
                if on: cr.rectangle(x * cell, y * cell, cell + 0.5, cell + 0.5)
        cr.fill(); return False


def read_status():
    try:
        d = json.load(open(STATUS))
        os.kill(d["pid"], 0)
        return d
    except Exception:
        return None


class Win(Gtk.Window):
    def __init__(self):
        super().__init__(title=t("cn_title")); self.set_default_size(560, 520); self.set_icon_name("lmg-connector")
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12); root.set_border_width(20); self.add(root)
        root.pack_start(heading(t("cn_title"), t("cn_sub")), False, False, 0)
        self.state = Gtk.Label(label="", xalign=0); self.state.get_style_context().add_class("lmg-title"); root.pack_start(card(self.state), False, False, 0)
        c = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        c.pack_start(Gtk.Label(label=t("cn_code"), xalign=0), False, False, 0)
        self.code = Gtk.Label(xalign=0); self.code.set_markup("<span size='xx-large' weight='bold'>------</span>"); self.code.set_selectable(True); c.pack_start(self.code, False, False, 0)
        self.addr = Gtk.Label(label="", xalign=0, wrap=True, selectable=True); c.pack_start(self.addr, False, False, 0)
        self.client = Gtk.Label(label="", xalign=0); c.pack_start(self.client, False, False, 0)
        self.audio = Gtk.Label(label="", xalign=0, wrap=True); c.pack_start(self.audio, False, False, 0)
        root.pack_start(card(c), False, False, 0)
        bar = Gtk.Box(spacing=8); root.pack_start(bar, False, False, 0)
        self.btn = Gtk.Button(label=t("cn_start")); self.btn.get_style_context().add_class("suggested-action"); self.btn.connect("clicked", self.toggle); bar.pack_start(self.btn, False, False, 0)
        self.btn_new = Gtk.Button(label=t("cn_newcode")); self.btn_new.connect("clicked", self.newcode); bar.pack_start(self.btn_new, False, False, 0)
        r = Gtk.Box(spacing=12); r.pack_start(Gtk.Label(label=t("cn_autostart"), xalign=0), True, True, 0)
        self.auto = Gtk.Switch(active=os.path.exists(AUTOSTART)); self.auto.connect("notify::active", self.set_auto); r.pack_end(self.auto, False, False, 0)
        root.pack_start(card(r), False, False, 0)
        self.qr_title = Gtk.Label(label=t("cn_qr"), xalign=0, wrap=True); root.pack_start(self.qr_title, False, False, 0)
        self.qr = QrArea(); self.qr.set_halign(Gtk.Align.START); root.pack_start(self.qr, False, False, 0); self.qr_text = None
        self.app = Gtk.Label(label="", xalign=0, wrap=True, selectable=True); root.pack_start(self.app, False, False, 0)
        tip = Gtk.Label(label=t("cn_tip"), xalign=0, wrap=True); tip.get_style_context().add_class("lmg-sub"); root.pack_start(tip, False, False, 0)
        self.s = load_settings(); self.show_all(); self.qr.set_visible(False); self.qr_title.set_visible(False); self.refresh(); GLib.timeout_add(1000, self.refresh)

    def refresh(self):
        d = read_status()
        if d:
            self.state.set_text(t("cn_running")); self.btn.set_label(t("cn_stop")); self.btn_new.set_sensitive(True)
            c = d["code"]; self.code.set_markup("<span size='xx-large' weight='bold'>%s %s</span>" % (c[:3], c[3:]))
            self.addr.set_text(t("cn_address") + ": " + ", ".join(d["ips"]) if d["ips"] else t("cn_noip"))
            self.client.set_text(t("cn_connected").format(d["client"]) if d["client"] else t("cn_waiting"))
            self.audio.set_text("Sound / صدا: " + str(d.get("audio", "")))
            ip = pick_ip(d["ips"]); url = "http://%s:%d/lmg-connector.apk" % (ip, d["http"]) if d.get("http") and ip else ""
            if url != self.qr_text: self.qr_text = url; self.qr.set_text(url)
            self.qr.set_visible(bool(url)); self.qr_title.set_visible(bool(url))
            self.app.set_text(t("cn_app").format(ip, d["http"]) if url else "")
        else:
            self.state.set_text(t("cn_stopped")); self.btn.set_label(t("cn_start")); self.btn_new.set_sensitive(False)
            self.code.set_markup("<span size='xx-large' weight='bold'>------</span>"); self.addr.set_text(""); self.client.set_text(""); self.audio.set_text(""); self.app.set_text(""); self.qr.set_visible(False); self.qr_title.set_visible(False)
        return True

    def toggle(self, *_):
        d = read_status()
        if d:
            try: os.kill(d["pid"], signal.SIGTERM)
            except OSError: pass
            return
        if not self.s.get("connector_fw"):                      # once: let the phone through the firewall (private networks only)
            try:
                subprocess.run(admin_cmd("connector-fw"), timeout=120); self.s["connector_fw"] = True; save_settings(self.s)
            except Exception: pass
        subprocess.Popen([sys.executable, SERVER], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)

    def newcode(self, *_):
        open(STATUS + ".newcode", "w").close()

    def set_auto(self, sw, _p):
        try:
            if sw.get_active():
                os.makedirs(os.path.dirname(AUTOSTART), exist_ok=True)
                open(AUTOSTART, "w").write("[Desktop Entry]\nType=Application\nName=LMG Connector\nExec=%s %s\nX-GNOME-Autostart-enabled=true\n" % (sys.executable, SERVER))
            elif os.path.exists(AUTOSTART): os.remove(AUTOSTART)
        except OSError: pass


def main():
    s = load_settings(); init_i18n(s); load_css()
    w = Win(); w.connect("destroy", Gtk.main_quit); Gtk.main()


if __name__ == "__main__":
    main()
