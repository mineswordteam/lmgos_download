"""LMG OS version upgrade engine (v1.1+). Used by the Control Panel (check, download), the boot-time upgrade screen
and the live installer ("upgrade the installed LMG OS"). Everything that touches files takes explicit roots so it can be
tested on fake directory trees.

The upgrade replaces the SYSTEM only. It never touches /home, /root, accounts, passwords, hostname, network
connections, SSH keys, disk table, language and login settings, or packages the user installed themselves.
"""
import hashlib, json, os, re, shutil, stat, subprocess, sys, time, urllib.request

VAR = os.environ.get("LMG_VAR", "/var/lib/lmg")
RUN = os.environ.get("LMG_RUN", "/run/lmg")
LOG = os.environ.get("LMG_LOG", "/var/log/lmg-update.log")
REPO = os.environ.get("LMG_RELEASE_REPO", "mineswordteam/lmgos_download")
UP = VAR + "/upgrade"
ISO_PATH = UP + "/lmg.iso"
INFO = VAR + "/upgrade-info.json"       # result of the last check
STATE = RUN + "/upgrade-state.json"     # live progress (Control Panel)


# ------------------------------------------------------------------ small helpers
def log(msg):
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        with open(LOG, "a", encoding="utf-8", errors="replace") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + "[upgrade] " + str(msg).rstrip("\n") + "\n")
    except Exception:
        pass


def write_json(path, obj, mode=0o644):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def set_state(**kw):
    st = read_json(STATE, {}) or {}
    st.update(kw)
    st["ts"] = int(time.time())
    try:
        write_json(STATE, st)
    except Exception:
        pass
    return st


def parse_version(s):
    m = re.search(r"(\d+(?:\.\d+)*)", s or "")
    return tuple(int(x) for x in m.group(1).split(".")) if m else ()


def is_newer(candidate, current):
    a, b = parse_version(candidate), parse_version(current)
    n = max(len(a), len(b))
    a += (0,) * (n - len(a)); b += (0,) * (n - len(b))
    return bool(candidate) and a > b


def current_version(root="/"):
    """VERSION_ID of the installed system (/etc/lmg-release or os-release)."""
    for rel in ("usr/lib/os-release", "etc/os-release"):
        try:
            for l in _slurp(os.path.join(root, rel)).splitlines():
                if l.startswith("VERSION_ID="):
                    return l.split("=", 1)[1].strip().strip('"')
        except Exception:
            pass
    try:
        return ".".join(map(str, parse_version(_slurp(os.path.join(root, "etc/lmg-release")))))
    except Exception:
        return ""


def is_lmg_root(root):
    try:
        return "LMG OS" in _slurp(os.path.join(root, "etc/lmg-release"))
    except Exception:
        return False


# ------------------------------------------------------------------ 1. find and download the new version
def _get(url, headers=None, timeout=25):
    req = urllib.request.Request(url, headers=dict({"User-Agent": "LMG-OS-upgrade", "Accept": "application/vnd.github+json"}, **(headers or {})))
    return urllib.request.urlopen(req, timeout=timeout)


def pick_release(releases, current):
    """Newest non-draft release whose version is higher than `current` and which carries an ISO (whole or in parts)."""
    best = None
    for r in releases or []:
        if r.get("draft"):
            continue
        ver = r.get("tag_name") or r.get("name") or ""
        assets = r.get("assets") or []
        iso = [a for a in assets if re.search(r"\.iso$", a["name"], re.I)]
        parts = sorted((a for a in assets if re.search(r"\.iso\.(part\d+|\d{3})$", a["name"], re.I)), key=lambda a: a["name"])
        sha = [a for a in assets if "sha256" in a["name"].lower()]
        files = iso[:1] or parts
        if not files:
            continue
        if not is_newer(ver, current):
            continue
        if best is None or is_newer(ver, best["version"]):
            best = {"version": ".".join(map(str, parse_version(ver))), "tag": ver, "name": r.get("name") or ver,
                    "notes": (r.get("body") or "")[:2000], "published": r.get("published_at", ""),
                    "files": [{"name": a["name"], "url": a["browser_download_url"], "size": a.get("size", 0)} for a in files],
                    "sha_url": sha[0]["browser_download_url"] if sha else "",
                    "size": sum(a.get("size", 0) for a in files)}
    return best


def check(current=None, fetch=None):
    """Ask GitHub (public API) for the newest release. Returns the info dict (also saved to INFO)."""
    cur = current or current_version()
    info = {"current": cur, "checked": int(time.time()), "available": False, "error": ""}
    try:
        if fetch is None:
            with _get("https://api.github.com/repos/%s/releases?per_page=15" % REPO) as r:
                rel = json.loads(r.read().decode("utf-8"))
        else:
            rel = fetch()
        best = pick_release(rel, cur)
        if best:
            info.update(best); info["available"] = True
    except Exception as e:
        info["error"] = str(e)
    try:
        write_json(INFO, info)
    except Exception:
        pass
    return info


def free_bytes(path):
    try:
        os.makedirs(path, exist_ok=True)
        s = os.statvfs(path)
        return s.f_bavail * s.f_frsize
    except Exception:
        return 0


def _download_file(url, dest, expect_size, progress, base, total):
    """Resumable download (HTTP Range). progress(done_bytes_total)."""
    have = os.path.getsize(dest) if os.path.exists(dest) else 0
    if expect_size and have > expect_size:
        os.remove(dest); have = 0
    if expect_size and have == expect_size:
        progress(base + have); return
    h = {"Range": "bytes=%d-" % have} if have else {}
    with _get(url, h, timeout=40) as r:
        if have and getattr(r, "status", 200) != 206:   # the server ignored Range: start again
            have = 0
        with open(dest, "ab" if have else "wb") as f:
            done = have
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk); done += len(chunk)
                progress(base + done)


def sha256_of(path, progress=None):
    h = hashlib.sha256(); n = 0
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(4 << 20), b""):
            h.update(b); n += len(b)
            if progress: progress(n)
    return h.hexdigest()


def download(info=None, progress=None):
    """Download the release in `info` to ISO_PATH (parts are joined), verify sha256 when published. Returns (ok, message)."""
    info = info or read_json(INFO, {})
    if not info or not info.get("available"):
        return False, "No newer version is available."
    progress = progress or (lambda pct, text: None)
    total = info["size"] or sum(f["size"] for f in info["files"])
    need = int(total * 2.1)           # the joined file (parts are removed) + room for the sync afterwards
    if free_bytes(UP) < need and not os.path.exists(ISO_PATH):
        return False, "Not enough free space for the upgrade: about %d MB are needed." % (need // 2**20)
    os.makedirs(UP, exist_ok=True)
    marker = UP + "/downloading.json"
    if (read_json(marker, {}) or {}).get("version") != info["version"]:
        for n in os.listdir(UP):
            try: os.remove(os.path.join(UP, n))
            except OSError: pass
        write_json(marker, {"version": info["version"]})
    done_marker = UP + "/ready.json"
    if (read_json(done_marker, {}) or {}).get("version") == info["version"] and os.path.exists(ISO_PATH):
        progress(100, "Downloaded"); return True, ""
    base = 0
    try:
        for f in info["files"]:
            part = os.path.join(UP, os.path.basename(f["name"]) + ".dl")
            _download_file(f["url"], part, f["size"], lambda d: progress(100.0 * d / max(1, total), "Downloading"), base, total)
            base += f["size"] or os.path.getsize(part)
        progress(100, "Checking the download")
        with open(ISO_PATH + ".tmp", "wb") as out:
            for f in info["files"]:
                part = os.path.join(UP, os.path.basename(f["name"]) + ".dl")
                with open(part, "rb") as src:
                    shutil.copyfileobj(src, out, 4 << 20)
                os.remove(part)
        os.replace(ISO_PATH + ".tmp", ISO_PATH)
        if info.get("sha_url"):
            with _get(info["sha_url"]) as r:
                txt = r.read().decode("utf-8", "replace")
            m = re.search(r"\b([0-9a-fA-F]{64})\b", txt)
            if m and sha256_of(ISO_PATH).lower() != m.group(1).lower():
                os.remove(ISO_PATH)
                return False, "The downloaded file is damaged (checksum mismatch). Try again."
        write_json(done_marker, {"version": info["version"], "size": os.path.getsize(ISO_PATH)})
        return True, ""
    except Exception as e:
        log("download: %r" % e)
        return False, "Download failed: %s" % e


# ------------------------------------------------------------------ 2. the data-preserving system sync
# Paths (relative, no leading slash) that the upgrade never writes or deletes. Prefix match on path components.
KEEP_PREFIX = (
    "home", "root", "proc", "sys", "dev", "run", "tmp", "mnt", "media", "lost+found", "srv",
    "boot/grub", "boot/efi", "swapfile", "swap.img",
    "var/lib/lmg", "var/lib/AccountsService", "var/lib/NetworkManager", "var/lib/bluetooth", "var/lib/systemd",
    "var/lib/flatpak", "var/lib/docker", "var/lib/libvirt", "var/lib/lightdm", "var/lib/upower", "var/lib/dpkg/status",
    "var/lib/dpkg/status-old", "var/lib/dpkg/available", "var/lib/dpkg/lock", "var/lib/dpkg/lock-frontend", "var/lib/dpkg/updates",
    "var/lib/apt/lists", "var/lib/random-seed", "var/log", "var/cache", "var/tmp", "var/mail", "var/spool",
    "etc/NetworkManager/system-connections", "etc/ssh/ssh_host", "etc/initramfs-tools/conf.d/resume",
    "etc/lightdm/lightdm.conf.d/60-lmg-autologin.conf", "etc/systemd/logind.conf.d/50-lmg-fastboot.conf",
    "etc/apt/sources.list", "etc/apt/sources.list.d", "etc/apt/trusted.gpg.d/user",
)
KEEP_EXACT = (
    "etc/passwd", "etc/passwd-", "etc/shadow", "etc/shadow-", "etc/group", "etc/group-", "etc/gshadow", "etc/gshadow-",
    "etc/subuid", "etc/subuid-", "etc/subgid", "etc/subgid-", "etc/fstab", "etc/crypttab", "etc/hostname", "etc/hosts",
    "etc/machine-id", "etc/mtab", "etc/resolv.conf", "etc/adjtime", "etc/localtime", "etc/timezone", "etc/locale.gen",
    "etc/default/locale", "etc/default/keyboard", "etc/default/grub", "etc/X11/xorg.conf.d/00-keyboard.conf",
    "etc/sudoers", "etc/cups/printers.conf", "etc/machine-info", "var/lib/dpkg/status", "etc/live",
)
KEEP_GLOB_RE = re.compile(r"^(boot/initrd\.img-.*|boot/System\.map-.*|boot/config-.*\.dpkg-.*|etc/ssh/ssh_host_.*|.*\.dpkg-(old|new|dist|tmp))$")
LIVE_PKG_RE = re.compile(r"^(live-boot.*|live-config.*|live-tools|calamares.*|user-setup|lmg-live.*)$")


def excluded(rel, extra=frozenset()):
    rel = rel.strip("/")
    if rel in extra or rel in KEEP_EXACT or KEEP_GLOB_RE.match(rel):
        return True
    for p in KEEP_PREFIX:
        if rel == p or rel.startswith(p + "/"):
            return True
    return False


def parse_status(text):
    """dpkg status text -> ordered list of (package, stanza_text)."""
    out = []
    for block in re.split(r"\n\n+", text.strip("\n")):
        m = re.match(r"Package: (\S+)", block)
        if m:
            out.append((m.group(1), block.strip("\n")))
    return out


def installed_pkgs(stanzas):
    return {n for n, b in stanzas if re.search(r"^Status: .* installed$", b, re.M)}


def _slurp(p):
    with open(p, encoding="utf-8", errors="replace") as f:
        return f.read()


def pkg_files(root, pkg):
    """Files that dpkg says belong to `pkg` in the tree `root` (relative paths, files and links only)."""
    res = []
    info = os.path.join(root, "var/lib/dpkg/info")
    for name in (pkg + ".list", pkg + ":amd64.list", pkg + ":all.list"):
        p = os.path.join(info, name)
        if os.path.exists(p):
            for l in _slurp(p).splitlines():
                l = l.strip()
                if l.startswith("/") and l != "/":
                    q = os.path.join(root, l.lstrip("/"))
                    if os.path.islink(q) or os.path.isfile(q):
                        res.append(l.lstrip("/"))
            break
    return res


def plan_packages(old_root, new_root):
    """Decide which packages are what. Returns dict with the merged status text, files to delete, files not to copy."""
    sp = os.path.join(old_root, "var/lib/dpkg/status")
    old_text = _slurp(sp) if os.path.exists(sp) else ""
    new_text = _slurp(os.path.join(new_root, "var/lib/dpkg/status"))
    old, new = parse_status(old_text), parse_status(new_text)
    old_names, new_names = installed_pkgs(old), installed_pkgs(new)
    live = {n for n in new_names if LIVE_PKG_RE.match(n)}
    try:
        old_base = {l.strip() for l in _slurp(os.path.join(old_root, "usr/share/lmg/base-packages.txt")).splitlines() if l.strip()}
    except Exception:
        old_base = old_names & new_names        # a v1.0 system has no list: what both versions share is "system"
    skip_files = set()
    for p in live:
        skip_files.update(pkg_files(new_root, p))
    # merged database: new stanzas (without live ones) + packages the user added on top (not in the old system list, not live)
    merged = [b for n, b in new if n not in live]
    kept_user = []
    new_all = {n for n, _ in new}
    for n, b in old:
        if n in new_all or n in old_base or LIVE_PKG_RE.match(n):
            continue
        kept_user.append(b)
    merged += kept_user
    # files of system packages that the new version no longer ships
    delete = set()
    for n in old_base & old_names:
        if n in new_names - live:
            old_f, new_f = set(pkg_files(old_root, n)), set(pkg_files(new_root, n))
            delete.update(old_f - new_f)
        elif n not in new_all:
            delete.update(pkg_files(old_root, n))      # the package was dropped from the system
    # never delete something that another kept package or the new tree still provides
    user_files = set()
    for n, b in old:
        if n in old_base or n in new_all:
            continue
        user_files.update(pkg_files(old_root, n))
    delete = {f for f in delete if not excluded(f) and f not in user_files and not os.path.lexists(os.path.join(new_root, f))}
    return {"status": "\n\n".join(merged) + "\n", "delete": sorted(delete), "skip": skip_files,
            "live": live, "kept_user": [re.match(r"Package: (\S+)", b).group(1) for b in kept_user]}


def _copy_xattrs(src, dst, follow=False):
    try:
        for k in os.listxattr(src, follow_symlinks=follow):
            try:
                os.setxattr(dst, k, os.getxattr(src, k, follow_symlinks=follow), follow_symlinks=follow)
            except OSError:
                pass
    except (OSError, AttributeError):
        pass


def _same_file(s, d, sst, dst):
    if not (stat.S_ISREG(sst.st_mode) and stat.S_ISREG(dst.st_mode) and sst.st_size == dst.st_size and int(sst.st_mtime) == int(dst.st_mtime)):
        return False
    if sst.st_size < (4 << 20):       # same size and time (reproducible builds): small files are compared byte for byte
        import filecmp
        return filecmp.cmp(s, d, shallow=False)
    return True


def count_files(src, skip=frozenset()):
    n = 0
    for dp, dn, fn in os.walk(src):
        rel_dir = os.path.relpath(dp, src).strip(".")
        dn[:] = [d for d in dn if not excluded(os.path.join(rel_dir, d), skip)]
        n += len(fn)
    return max(1, n)


def sync_tree(src, dst, skip=frozenset(), progress=None, total=None):
    """Copy the new system tree over the installed one. Per file: write next to the target, then rename (atomic).
    Existing files in dst that are not in src are left alone (the user's own data and programs). Returns stats."""
    total = total or count_files(src, skip)
    done = copied = 0
    inodes = {}
    stats = {"copied": 0, "same": 0, "errors": 0}
    for dp, dn, fn in os.walk(src):
        rel_dir = os.path.relpath(dp, src)
        rel_dir = "" if rel_dir == "." else rel_dir
        dn[:] = [d for d in dn if not excluded(os.path.join(rel_dir, d), skip)]
        tdir = os.path.join(dst, rel_dir)
        sdir_st = os.lstat(dp)
        if not os.path.isdir(tdir) or os.path.islink(tdir):
            try:
                if os.path.lexists(tdir):
                    os.remove(tdir)
                os.makedirs(tdir, exist_ok=True)
                os.chmod(tdir, stat.S_IMODE(sdir_st.st_mode)); os.chown(tdir, sdir_st.st_uid, sdir_st.st_gid)
            except OSError as e:
                log("dir %s: %s" % (tdir, e)); stats["errors"] += 1
                continue
        for name in dn:       # directory symlinks appear in dn: handle them as files
            sp = os.path.join(dp, name)
            if os.path.islink(sp):
                fn.append(name)
        for name in fn:
            rel = os.path.join(rel_dir, name)
            if excluded(rel, skip):
                continue
            sp, tp = os.path.join(dp, name), os.path.join(tdir, name)
            done += 1
            if progress and done % 400 == 0:
                progress(100.0 * done / total, "")
            try:
                sst = os.lstat(sp)
                try:
                    tst = os.lstat(tp)
                except FileNotFoundError:
                    tst = None
                if stat.S_ISLNK(sst.st_mode):
                    target = os.readlink(sp)
                    if tst is not None and stat.S_ISLNK(tst.st_mode) and os.readlink(tp) == target:
                        stats["same"] += 1; continue
                    tmp = tp + ".lmgnew"
                    if os.path.lexists(tmp): os.remove(tmp)
                    os.symlink(target, tmp); os.lchown(tmp, sst.st_uid, sst.st_gid)
                    if tst is not None and stat.S_ISDIR(tst.st_mode) and not stat.S_ISLNK(tst.st_mode):
                        shutil.rmtree(tp)
                    os.replace(tmp, tp); stats["copied"] += 1; continue
                if not stat.S_ISREG(sst.st_mode):
                    continue          # device nodes, sockets: /dev is not touched
                if tst is not None and _same_file(sp, tp, sst, tst):
                    stats["same"] += 1; continue
                key = (sst.st_dev, sst.st_ino)
                if sst.st_nlink > 1 and key in inodes and os.path.exists(inodes[key]):
                    tmp = tp + ".lmgnew"
                    if os.path.lexists(tmp): os.remove(tmp)
                    os.link(inodes[key], tmp); os.replace(tmp, tp); stats["copied"] += 1; continue
                tmp = tp + ".lmgnew"
                shutil.copyfile(sp, tmp)
                os.chmod(tmp, stat.S_IMODE(sst.st_mode)); os.chown(tmp, sst.st_uid, sst.st_gid)
                os.utime(tmp, ns=(sst.st_atime_ns, sst.st_mtime_ns)); _copy_xattrs(sp, tmp)
                if tst is not None and stat.S_ISDIR(tst.st_mode) and not stat.S_ISLNK(tst.st_mode):
                    shutil.rmtree(tp)
                os.replace(tmp, tp)
                if sst.st_nlink > 1: inodes[key] = tp
                stats["copied"] += 1
            except OSError as e:
                log("file %s: %s" % (tp, e)); stats["errors"] += 1
                try: os.remove(tp + ".lmgnew")
                except OSError: pass
    if progress: progress(100, "")
    return stats


def delete_vanished(dst, files):
    n = 0
    for rel in files:
        p = os.path.join(dst, rel)
        try:
            if os.path.islink(p) or os.path.isfile(p):
                os.remove(p); n += 1
                d = os.path.dirname(p)
                while d.rstrip("/") != dst.rstrip("/"):
                    try: os.rmdir(d)
                    except OSError: break
                    d = os.path.dirname(d)
        except OSError:
            pass
    return n


def upgrade_tree(src, dst, progress=None, backup_dir=None):
    """The whole data-preserving system upgrade of the installed tree `dst` from the new tree `src`."""
    progress = progress or (lambda pct, text: None)
    progress(1, "Comparing")
    plan = plan_packages(dst, src)
    skip = frozenset(plan["skip"])
    total = count_files(src, skip)
    old_status = os.path.join(dst, "var/lib/dpkg/status")
    if backup_dir and os.path.exists(old_status):
        os.makedirs(backup_dir, exist_ok=True)
        shutil.copy2(old_status, os.path.join(backup_dir, "dpkg-status.old"))
        for rel in ("etc/lmg-release", "usr/lib/os-release"):
            if os.path.exists(os.path.join(dst, rel)):
                shutil.copy2(os.path.join(dst, rel), os.path.join(backup_dir, os.path.basename(rel) + ".old"))
    stats = sync_tree(src, dst, skip, lambda p, t: progress(2 + p * 0.9, "Installing the new system"), total)
    progress(93, "Removing files that are no longer part of the system")
    removed = delete_vanished(dst, plan["delete"])
    # the package database: new system packages + the user's own packages
    tmp = old_status + ".lmgnew"
    os.makedirs(os.path.dirname(old_status), exist_ok=True)
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(plan["status"])
    os.replace(tmp, old_status)
    progress(97, "Package database")
    log("upgrade_tree: %s, removed %d old files, kept user packages: %s" % (stats, removed, ",".join(plan["kept_user"])))
    progress(100, "")
    return {"stats": stats, "removed": removed, "kept_user": plan["kept_user"], "live": sorted(plan["live"])}


# ------------------------------------------------------------------ 3. after the files: boot files, caches, disk optimisation
def _run(cmd, root=None, timeout=900):
    if root and root != "/":
        cmd = ["chroot", root] + cmd
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=dict(os.environ, LC_ALL="C", DEBIAN_FRONTEND="noninteractive"))
        if r.returncode != 0:
            log("%s -> %d %s" % (" ".join(cmd), r.returncode, (r.stderr or r.stdout)[-300:]))
        return r.returncode
    except Exception as e:
        log("%s: %r" % (" ".join(cmd), e)); return 1


def boot_files(root="/", progress=None):
    """Fresh initramfs for every kernel (never the live image's one), new boot menu."""
    progress = progress or (lambda p, t: None)
    mods = os.path.join(root, "lib/modules")
    vers = sorted(os.listdir(mods)) if os.path.isdir(mods) else []
    vers = [v for v in vers if os.path.exists(os.path.join(root, "boot/vmlinuz-" + v))]
    for i, v in enumerate(vers):
        progress(100.0 * i / max(1, len(vers) + 1), "Boot files")
        have = os.path.exists(os.path.join(root, "boot/initrd.img-" + v))
        _run(["update-initramfs", "-u" if have else "-c", "-k", v], root)
    progress(90, "Boot menu")
    if shutil.which("update-grub") or root != "/":
        _run(["update-grub"], root)
    progress(100, "")
    return bool(vers)


def finish_packages(root="/"):
    _run(["ldconfig"], root)
    _run(["dpkg", "--configure", "-a", "--force-confold"], root, timeout=600)
    for c in (["update-desktop-database"], ["update-mime-database", "/usr/share/mime"], ["fc-cache", "-s"],
              ["gtk-update-icon-cache", "-f", "-t", "/usr/share/icons/hicolor"], ["glib-compile-schemas", "/usr/share/glib-2.0/schemas"]):
        if root != "/" or shutil.which(c[0]):
            _run(c, root, timeout=300)


def _rotational(root="/"):
    src = subprocess.run(["findmnt", "-no", "SOURCE", root], capture_output=True, text=True).stdout.strip()
    if not src.startswith("/dev/"):
        return False
    out = subprocess.run(["lsblk", "-s", "-n", "-o", "ROTA,TYPE", src], capture_output=True, text=True).stdout
    return any(l.split()[:2] and l.split()[0] == "1" and "disk" in l for l in out.splitlines())


def optimize(root="/", progress=None, budget=900):
    """Optimising: caches, then TRIM on SSD or defragmentation of the system folders on a hard disk (ext4)."""
    progress = progress or (lambda p, t: None)
    steps = [("Caches", lambda: finish_packages(root)), ("Writing data to disk", lambda: _run(["sync"]))]
    fst = subprocess.run(["findmnt", "-no", "FSTYPE", root], capture_output=True, text=True).stdout.strip()
    if _rotational(root) and fst == "ext4" and shutil.which("e4defrag"):
        steps.insert(1, ("Defragmenting", lambda: _run(["e4defrag", os.path.join(root, "usr"), os.path.join(root, "lib"), os.path.join(root, "boot")], None, budget)))
    elif shutil.which("fstrim"):
        steps.insert(1, ("Trimming", lambda: _run(["fstrim", "-v", root])))
    for i, (name, fn) in enumerate(steps):
        progress(100.0 * i / len(steps), name)
        try: fn()
        except Exception as e: log("optimize %s: %r" % (name, e))
    progress(100, "")


# ------------------------------------------------------------------ 4. mounting the downloaded image (installed system) / finding the live image
def mount_image(iso=ISO_PATH, base="/run/lmg/newos"):
    """Loop-mount the ISO and its squashfs. Returns (path_of_new_root, [mounts to undo, last first])."""
    iso_m, sq_m = base + "/iso", base + "/root"
    os.makedirs(iso_m, exist_ok=True); os.makedirs(sq_m, exist_ok=True)
    mounts = []
    if _run(["mount", "-o", "loop,ro", iso, iso_m]) != 0:
        raise RuntimeError("The upgrade image could not be opened.")
    mounts.append(iso_m)
    sq = None
    for cand in ("live/filesystem.squashfs", "casper/filesystem.squashfs"):
        if os.path.exists(os.path.join(iso_m, cand)):
            sq = os.path.join(iso_m, cand); break
    if not sq:
        umount_all(mounts); raise RuntimeError("The upgrade image has no system in it.")
    if _run(["mount", "-t", "squashfs", "-o", "loop,ro", sq, sq_m]) != 0:
        umount_all(mounts); raise RuntimeError("The upgrade image could not be opened (squashfs).")
    mounts.append(sq_m)
    return sq_m, mounts


def umount_all(mounts):
    for m in reversed(mounts):
        subprocess.run(["umount", "-l", m], capture_output=True)


def live_source():
    """The new system when running from the live USB: the squashfs live-boot already mounted."""
    for p in ("/run/live/rootfs/filesystem.squashfs", "/usr/lib/live/mount/rootfs/filesystem.squashfs"):
        if os.path.isdir(p) and os.path.exists(os.path.join(p, "etc/lmg-release")):
            return p, []
    for p in ("/run/live/medium/live/filesystem.squashfs", "/usr/lib/live/mount/medium/live/filesystem.squashfs"):
        if os.path.exists(p):
            m = "/run/lmg/newos/root"
            os.makedirs(m, exist_ok=True)
            if _run(["mount", "-t", "squashfs", "-o", "loop,ro", p, m]) == 0:
                return m, [m]
    return None, []


def upgrade_installed(src, root="/", progress=None):
    """Files -> boot files -> caches/optimising is done by the caller (so the screen can show the right scene)."""
    progress = progress or (lambda p, t: None)
    res = upgrade_tree(src, root, lambda p, t: progress(p, t), backup_dir=VAR_ROOT(root) + "/upgrade-backup")
    return res


def VAR_ROOT(root):
    return os.path.join(root, "var/lib/lmg") if root != "/" else VAR


def write_marker(root, from_ver, to_ver):
    d = VAR_ROOT(root)
    os.makedirs(d, exist_ok=True)
    write_json(os.path.join(d, "upgrade-history.json"), {"from": from_ver, "to": to_ver, "ts": int(time.time())})
