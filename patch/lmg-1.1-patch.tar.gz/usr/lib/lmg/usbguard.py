"""LMG USB guard: checks a USB device / drive BEFORE the user gets access to it.

Pure functions (testable without root or hardware). Used by lmg-usb-guard (root service), lmg-helper and lmg-usb-ui.

What this can do:  recognise a "flash drive" that is really a keyboard / network card (BadUSB), check the file system,
scan the files for the typical USB malware patterns, repair file system errors.
"""
import json, os, re, subprocess, time

SYS_USB = os.environ.get("LMG_SYS_USB", "/sys/bus/usb/devices")
EVENTS = os.environ.get("LMG_USB_EVENTS", "/run/lmg/usb-events")
CONF = os.environ.get("LMG_USB_CONF", "/var/lib/lmg/usb-guard.json")
TRUST = os.environ.get("LMG_USB_TRUST", "/run/lmg/usb-trusted.json")
SCANROOT = os.environ.get("LMG_USB_SCANROOT", "/run/lmg/usb-scan")
JUDGED = os.environ.get("LMG_USB_JUDGED", "/run/lmg/usb-judged.json")
PROC_MOUNTS = os.environ.get("LMG_PROC_MOUNTS", "/proc/mounts")

CLS_AUDIO, CLS_CDC, CLS_HID, CLS_STORAGE, CLS_HUB, CLS_CDCDATA, CLS_WIRELESS, CLS_VENDOR = 0x01, 0x02, 0x03, 0x08, 0x09, 0x0A, 0xE0, 0xFF
# tools that exist to type for you / attack through USB (vendor:product)
ATTACK_IDS = {"16c0:0486": "Teensy", "16d0:0753": "Digispark", "2341:8036": "Arduino Leonardo", "1b4f:9205": "Pro Micro",
              "1b4f:9206": "Pro Micro", "2e8a:000a": "Raspberry Pi Pico (serial)", "0483:5740": "STM32 virtual COM"}
ATTACK_WORDS = ("rubber ducky", "badusb", "digispark", "o.mg", "omg cable", "flipper", "bash bunny", "malduino")

# Only real "Windows malware launchers". Ordinary files (.js, .jar, .cmd, .com, .sh, .desktop, links) are NOT suspicious on a normal drive.
SCRIPT_EXT = {".vbs", ".vbe", ".jse", ".wsf", ".wsh", ".hta", ".scr", ".pif", ".bat", ".ps1", ".cpl", ".lnk"}
EXE_EXT = {".exe", ".dll", ".msi", ".sys"}
DOC_EXT = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".mp3", ".mp4", ".avi", ".mkv", ".zip", ".rar"}


def _read(p, default=""):
    try:
        with open(p, errors="replace") as f:
            return f.read().strip()
    except Exception:
        return default


def _int(s, default=-1):
    try:
        return int(s, 16)
    except Exception:
        return default


# ------------------------------------------------------------------ the device itself (BadUSB)
def device_interfaces(devdir):
    out = []
    try:
        for n in sorted(os.listdir(devdir)):
            d = os.path.join(devdir, n)
            if ":" in n and os.path.isfile(d + "/bInterfaceClass"):
                out.append(_int(_read(d + "/bInterfaceClass")))
    except OSError:
        pass
    return out


def classify_device(devdir):
    """-> {'busid','vendor','product','name','classes','level':ok|warn|danger,'reasons':[...]}"""
    busid = os.path.basename(os.path.realpath(devdir))
    vid, pid = _read(devdir + "/idVendor"), _read(devdir + "/idProduct")
    name = (_read(devdir + "/manufacturer") + " " + _read(devdir + "/product")).strip()
    classes = set(device_interfaces(devdir))
    reasons, level = [], "ok"

    def bump(l, why):
        nonlocal level
        reasons.append(why)
        if l == "danger" or (l == "warn" and level == "ok"):
            level = l
    if CLS_STORAGE in classes:
        if classes & {CLS_HID}:
            bump("danger", "usb_composite_hid")        # a drive that is also a keyboard
        if classes & {CLS_CDC, CLS_CDCDATA, CLS_WIRELESS}:
            bump("danger", "usb_composite_net")        # a drive that is also a network / serial adapter
        elif CLS_VENDOR in classes:
            bump("warn", "usb_composite_vendor")
    key = f"{vid}:{pid}".lower()
    if key in ATTACK_IDS:
        bump("warn", "usb_attack_tool:" + ATTACK_IDS[key])
    low = name.lower()
    for w in ATTACK_WORDS:
        if w in low:
            bump("danger", "usb_attack_tool:" + w)
            break
    return {"busid": busid, "vendor": vid, "product": pid, "name": name, "classes": sorted(classes), "level": level, "reasons": reasons}


def set_authorized(busid, value):
    """Cut a device off (0) / let it work (1). Needs root. busid like '1-2' or '1-2.3'."""
    if not re.fullmatch(r"\d+-\d+(\.\d+)*", busid or ""):
        return False
    try:
        with open(f"{SYS_USB}/{busid}/authorized", "w") as f:
            f.write("1" if value else "0")
        return True
    except OSError:
        return False


# ------------------------------------------------------------------ the files (USB malware patterns)
def scan_tree(root, max_files=30000, max_secs=45):
    """Look for the typical USB malware patterns. Never follows links, never executes anything."""
    t0 = time.monotonic()
    findings, seen, truncated = [], 0, False
    top_files, top_scripts, top_lnk, top_dirs = [], [], [], 0
    disguised, dbl, desktop = [], [], []

    def add(level, key, detail=""):
        findings.append({"level": level, "key": key, "detail": detail})
    try:
        top = sorted(os.listdir(root))
    except OSError as e:
        return {"level": "warn", "findings": [{"level": "warn", "key": "usb_unreadable", "detail": str(e)}], "files": 0, "truncated": False}
    top_dirnames = set()
    for n in top:
        p = os.path.join(root, n)
        if os.path.isdir(p) and not os.path.islink(p):
            top_dirnames.add(n.lower())
        ext = os.path.splitext(n)[1].lower()
        if os.path.islink(p):
            continue                                  # links are normal on Linux drives; never followed
        elif os.path.isdir(p):
            top_dirs += 1
        else:
            top_files.append(n)
            if n.lower() == "autorun.inf":
                txt = _read(p).lower()
                add("danger" if re.search(r"(open|shellexecute|action)\s*=", txt) else "warn", "usb_autorun", n)
            if ext in SCRIPT_EXT and ext != ".lnk":
                top_scripts.append(n)
            if ext == ".lnk":
                top_lnk.append(n)
    for dirpath, dirs, files in os.walk(root, followlinks=False):
        if time.monotonic() - t0 > max_secs or seen > max_files:
            truncated = True
            break
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(dirpath, d))]
        for n in files:
            seen += 1
            p = os.path.join(dirpath, n)
            low = n.lower()
            ext = os.path.splitext(low)[1]
            parts = low.split(".")
            if len(parts) >= 3 and ("." + parts[-2]) in DOC_EXT and ("." + parts[-1]) in (EXE_EXT | SCRIPT_EXT):
                dbl.append(os.path.relpath(p, root))
            elif ext in DOC_EXT and not os.path.islink(p):
                try:
                    with open(p, "rb") as f:
                        head = f.read(4)
                    if head[:2] == b"MZ" or head == b"\x7fELF":
                        disguised.append(os.path.relpath(p, root))
                except OSError:
                    pass
            if seen > max_files:
                truncated = True
                break
    if dbl:
        add("danger", "usb_double_ext", ", ".join(dbl[:5]))
    if disguised:
        add("danger", "usb_disguised", ", ".join(disguised[:5]))
    # the classic "shortcut virus": a shortcut with the name of a folder + a program next to it (the folder itself is hidden)
    fake = [l for l in top_lnk if os.path.splitext(l)[0].lower() in top_dirnames]
    if fake and (any(os.path.splitext(f)[1].lower() in EXE_EXT | (SCRIPT_EXT - {".lnk"}) for f in top_files)):
        add("danger", "usb_shortcut_virus", ", ".join(fake[:5]))
    scripts = [f for f in top_scripts if not f.lower().endswith(".lnk")]
    if len(scripts) >= 3:
        add("warn", "usb_scripts", ", ".join(scripts[:5]))
    level = "danger" if any(f["level"] == "danger" for f in findings) else ("warn" if findings else "ok")
    return {"level": level, "findings": findings, "files": seen, "truncated": truncated}


# ------------------------------------------------------------------ file system check / repair
VALID_DEV = re.compile(r"^/dev/sd[a-z]{1,2}[0-9]*$")


def valid_usb_dev(dev):
    """Only USB-attached SCSI disks / partitions."""
    if not VALID_DEV.match(dev or ""):
        return False
    r = subprocess.run(["udevadm", "info", "-q", "property", "-n", dev], capture_output=True, text=True)
    return "ID_BUS=usb" in r.stdout


def props(dev):
    r = subprocess.run(["udevadm", "info", "-q", "property", "-n", dev], capture_output=True, text=True)
    d = {}
    for l in r.stdout.splitlines():
        if "=" in l:
            k, v = l.split("=", 1)
            d[k] = v
    return d


def _run(cmd, timeout=180):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, ((r.stdout or "") + (r.stderr or "")).strip()
    except FileNotFoundError:
        return 127, "tool missing: " + cmd[0]
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def fs_commands(fstype, dev, repair=False):
    if fstype == "vfat":
        return ["fsck.vfat", "-a" if repair else "-n", dev]
    if fstype == "exfat":
        return ["fsck.exfat", "-p" if repair else "-n", dev]
    if fstype == "ntfs":
        return ["ntfsfix", dev] if repair else ["ntfsfix", "-n", dev]
    if fstype in ("ext2", "ext3", "ext4"):
        return ["e2fsck", "-p", "-f", dev] if repair else ["e2fsck", "-n", "-f", dev]
    return None


def is_mounted(dev):
    try:
        with open(PROC_MOUNTS) as f:
            return any(l.split()[0] == dev for l in f if l.strip())
    except OSError:
        return False


def unmount(dev):
    for _ in range(3):
        if not is_mounted(dev):
            return True
        subprocess.run(["umount", dev], capture_output=True)
        time.sleep(0.3)
    return not is_mounted(dev)


def fs_state(fstype, rc, out=""):
    """Exit code of a read-only check -> 'ok' | 'errors' | 'unchecked'.
    Only a real "file system errors" answer is an error; a missing tool, a timeout, a usage problem are NOT."""
    if rc in (127, 124):
        return "unchecked"
    if rc == 0:
        return "ok"
    if fstype in ("vfat", "exfat"):
        return "errors" if rc == 1 else "unchecked"
    if fstype in ("ext2", "ext3", "ext4"):
        return "errors" if rc & 4 else "unchecked"
    if fstype == "ntfs":
        return "errors" if re.search(r"dirty|corrupt|inconsist|unclean|error", out, re.I) else "unchecked"
    return "unchecked"


def check_fs(dev, fstype):
    """-> (ok, message). Read-only check of an UNMOUNTED file system. 'Could not check' is never reported as an error."""
    cmd = fs_commands(fstype, dev)
    if not cmd:
        return True, "unchecked"
    if not unmount(dev):
        return True, "unchecked: in use"
    rc, out = _run(cmd)
    st = fs_state(fstype, rc, out)
    return st != "errors", out[-600:]


def repair_commands(fstype, dev):
    """Gentle first, then the stronger "answer yes to everything" pass (like Windows' scan and fix)."""
    if fstype == "vfat":
        return [["fsck.vfat", "-a", dev], ["fsck.vfat", "-y", dev]]
    if fstype == "exfat":
        return [["fsck.exfat", "-p", dev], ["fsck.exfat", "-y", dev]]
    if fstype == "ntfs":
        return [["ntfsfix", dev], ["ntfsfix", "-d", dev]]
    if fstype in ("ext2", "ext3", "ext4"):
        return [["e2fsck", "-p", "-f", dev], ["e2fsck", "-y", "-f", dev]]
    return []


def repair_fs(dev, fstype):
    """-> (clean_afterwards, message). Runs the repair passes until a read-only check comes back clean."""
    ladder = repair_commands(fstype, dev)
    if not ladder:
        return False, "no repair tool for this file system"
    if not unmount(dev):
        return False, "the drive is in use and could not be released"
    msgs = []
    for cmd in ladder:
        rc, out = _run(cmd, 900)
        msgs.append(f"$ {' '.join(cmd)} -> {rc}\n{out[-300:]}")
        if rc in (127, 124):
            continue
        ok, _m = check_fs(dev, fstype)
        if ok:
            return True, "\n".join(msgs)[-800:]
    return False, "\n".join(msgs)[-800:]


def scan_partition(dev, fstype):
    """Mount read-only in a private place (no exec, no suid, no devices), scan, unmount."""
    os.makedirs(SCANROOT, exist_ok=True)
    mp = f"{SCANROOT}/{os.path.basename(dev)}"
    os.makedirs(mp, exist_ok=True)
    opts = "ro,nosuid,nodev,noexec"
    if fstype == "ntfs":
        cmd = ["mount", "-t", "ntfs3", "-o", opts, dev, mp]
    else:
        cmd = ["mount", "-t", fstype, "-o", opts, dev, mp]
    rc, out = _run(cmd, 60)
    if rc != 0 and fstype == "ntfs":
        rc, out = _run(["mount", "-t", "ntfs-3g", "-o", opts, dev, mp], 60)
    if rc != 0:
        try:
            os.rmdir(mp)
        except OSError:
            pass
        return {"level": "ok", "findings": [], "files": 0, "truncated": False, "unscanned": out[-200:]}     # could not scan: not a reason to scare the user
    try:
        return scan_tree(mp)
    finally:
        subprocess.run(["umount", "-l", mp], capture_output=True)
        try:
            os.rmdir(mp)
        except OSError:
            pass


def check_partition(dev, after_repair=False):
    """Full check of one USB partition -> event dict (type 'result')."""
    p = props(dev)
    fstype = p.get("ID_FS_TYPE", "")
    ev = {"ts": int(time.time()), "type": "result", "dev": dev, "id": os.path.basename(dev), "label": p.get("ID_FS_LABEL", ""),
          "fstype": fstype, "model": (p.get("ID_VENDOR", "") + " " + p.get("ID_MODEL", "")).replace("_", " ").strip(),
          "fs_ok": True, "fs_msg": "", "level": "ok", "findings": [], "files": 0, "after_repair": bool(after_repair)}
    if fstype not in ("vfat", "exfat", "ntfs", "ext2", "ext3", "ext4"):
        return ev                                    # (encrypted, optical, swap ...): nothing we can check; the system handles it
    ok, msg = check_fs(dev, fstype)
    ev["fs_ok"], ev["fs_msg"] = ok, msg
    r = scan_partition(dev, fstype)
    ev["findings"], ev["files"] = r["findings"], r["files"]
    ev["level"] = r["level"]
    return ev


# ------------------------------------------------------------------ events / config / trust
def emit(ev):
    try:
        os.makedirs(os.path.dirname(EVENTS), exist_ok=True)
        with open(EVENTS, "a") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")
        os.chmod(EVENTS, 0o644)
    except OSError:
        pass


def config():
    d = {"guard": False, "panic_reboot": True}   # the scanner is OFF until the user switches it on in Settings
    try:
        d.update(json.load(open(CONF)))
    except Exception:
        pass
    return d


def trust_add(busid):
    d = {}
    try:
        d = json.load(open(TRUST))
    except Exception:
        pass
    d[busid] = int(time.time())
    os.makedirs(os.path.dirname(TRUST), exist_ok=True)
    with open(TRUST, "w") as f:
        json.dump(d, f)


def trusted_recent(window=300):
    try:
        d = json.load(open(TRUST))
    except Exception:
        return []
    now = time.time()
    return [b for b, ts in d.items() if now - ts < window]


# ------------------------------------------------------------------ what was already judged (survives the guard quitting)
def _judged_load():
    try:
        return json.load(open(JUDGED))
    except Exception:
        return {}


def judged(key, token=""):
    return _judged_load().get(key) == token


def judge_add(key, token=""):
    d = _judged_load()
    d[key] = token
    try:
        os.makedirs(os.path.dirname(JUDGED), exist_ok=True)
        with open(JUDGED, "w") as f:
            json.dump(d, f)
    except OSError:
        pass


def judge_forget(key):
    d = _judged_load()
    if d.pop(key, None) is not None:
        try:
            with open(JUDGED, "w") as f:
                json.dump(d, f)
        except OSError:
            pass


# ------------------------------------------------------------------ on-demand service helpers
IDLE_SECS = 120


def list_usb_busids():
    """USB devices (not interfaces, not root hubs) currently known to the kernel."""
    try:
        return sorted(n for n in os.listdir(SYS_USB) if re.fullmatch(r"\d+-\d+(\.\d+)*", n))
    except OSError:
        return []


def should_exit(now, last_activity, busy_checks=0, idle=IDLE_SECS):
    """The guard only runs while it is needed: it quits after a quiet time, never during a check or while the
    watchdog still protects a device the user trusted."""
    if busy_checks > 0 or trusted_recent(300):
        return False
    return now - last_activity > idle
