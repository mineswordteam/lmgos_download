"""LMG desktop folders - the data side (no GTK, so it can be tested anywhere).
State (~/.config/lmg/desktop-folders.json):
  folders: {id: {name, name_fa?, items:[file names]}}   pos: {key: [col,row]}   seeded: [file names already offered a default folder]
Keys: "f:<id>" is a folder tile, "a:<file>" is a file/app that sits on the desktop itself."""
import json, os

DEFAULTS = {  # file-name prefix -> (folder id, English name, Persian name)
    "LMG-": ("lmg-apps", "LMG Apps", "برنامه‌های LMG"),
    "Minesword-": ("minesword-apps", "Minesword Apps", "برنامه‌های Minesword"),
}
ORDER = ["lmg-apps", "minesword-apps"]

def default_for(fname):
    for p, v in DEFAULTS.items():
        if fname.startswith(p) and fname.endswith(".desktop"): return v
    return None

class Model:
    def __init__(self, path=None):
        self.path = path
        self.folders, self.pos, self.seeded = {}, {}, []
        if path:
            try:
                d = json.load(open(path))
                self.folders = {k: v for k, v in d.get("folders", {}).items() if isinstance(v, dict)}
                self.pos = {k: list(v) for k, v in d.get("pos", {}).items()}
                self.seeded = list(d.get("seeded", []))
            except Exception: pass
        for f in self.folders.values(): f.setdefault("items", [])

    def save(self):
        if not self.path: return
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        json.dump({"v": 1, "folders": self.folders, "pos": self.pos, "seeded": sorted(set(self.seeded))}, open(tmp, "w"), ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    # ---- queries
    def folder_of(self, fname):
        for fid, f in self.folders.items():
            if fname in f["items"]: return fid
        return None

    def keys(self, entries):
        """Everything that sits directly on the desktop, folders first."""
        ks = ["f:" + fid for fid in self.folders]
        ks += ["a:" + e for e in entries if self.folder_of(e) is None]
        return ks

    # ---- keeping in step with the Desktop directory
    def sync(self, entries, rows):
        es = set(entries)
        for f in self.folders.values():
            f["items"] = [i for i in f["items"] if i in es]
        for fid in list(self.folders):
            if not self.folders[fid]["items"] and fid not in ORDER: del self.folders[fid]
        for e in sorted(entries):  # first-time default folders (LMG apps / Minesword apps)
            d = default_for(e)
            if d and e not in self.seeded:
                self.seeded.append(e)
                if self.folder_of(e) is None:
                    fid, en, fa = d
                    self.folders.setdefault(fid, {"name": en, "name_fa": fa, "items": []})["items"].append(e)
        for fid in ORDER:  # a default folder that has become empty is not shown
            if fid in self.folders and not self.folders[fid]["items"]: del self.folders[fid]
        live = set(self.keys(entries))
        self.pos = {k: v for k, v in self.pos.items() if k in live}
        for k in self.keys(entries):
            if k not in self.pos: self.pos[k] = list(self.free_cell(rows))
        self.save()

    def free_cell(self, rows, ignore=None, near=None):
        used = {tuple(v) for k, v in self.pos.items() if k != ignore}
        rows = max(1, rows)
        if near is None:
            c = 0
            while True:
                for r in range(rows):
                    if (c, r) not in used: return (c, r)
                c += 1
        best, bd = None, 1e9
        for c in range(0, max(60, near[0] + 3)):
            for r in range(rows):
                if (c, r) in used: continue
                d = (c - near[0]) ** 2 + (r - near[1]) ** 2
                if d < bd: best, bd = (c, r), d
        return best

    # ---- actions
    def move(self, key, cell, rows):
        """Put an item on a cell. A free cell is used as is; a taken one sends the nearest free cell (the two do not merge)."""
        cell = (max(0, int(cell[0])), min(max(0, int(cell[1])), max(0, rows - 1)))
        self.pos[key] = list(self.free_cell(rows, ignore=key, near=cell))
        self.save(); return tuple(self.pos[key])

    def _new_id(self):
        n = 1
        while "user%d" % n in self.folders: n += 1
        return "user%d" % n

    def drop_on(self, src, dst, rows, new_name="Folder", new_name_fa="پوشه"):
        """src dropped on the middle of dst. Returns the key of the folder that now holds src, or None."""
        if src == dst: return None
        if not src.startswith("a:"):  # folders do not nest
            return None
        s = src[2:]
        if dst.startswith("f:"):
            fid = dst[2:]
            self.folders[fid]["items"].append(s)
        else:
            d = dst[2:]
            fid = self._new_id()
            self.folders[fid] = {"name": new_name, "name_fa": new_name_fa, "items": [d, s]}
            self.pos["f:" + fid] = list(self.pos.get(dst, self.free_cell(rows)))
            self.pos.pop(dst, None)
        self.pos.pop(src, None)
        self.save(); return "f:" + fid

    def take_out(self, fname, cell, rows):
        fid = self.folder_of(fname)
        if fid is None: return
        self.folders[fid]["items"].remove(fname)
        self.pos["a:" + fname] = list(self.free_cell(rows, near=cell))
        self.tidy(fid, rows)
        self.save()

    def tidy(self, fid, rows):
        """Android rule: a folder of one app goes away (the default folders stay), an empty one too."""
        f = self.folders.get(fid)
        if f is None: return
        n = len(f["items"])
        if n == 0 or (n == 1 and fid not in ORDER):
            at = self.pos.pop("f:" + fid, None)
            if n == 1:
                self.pos["a:" + f["items"][0]] = list(at) if at else list(self.free_cell(rows))
            del self.folders[fid]

    def ungroup(self, fid, rows):
        f = self.folders.pop(fid, None)
        if not f: return
        at = self.pos.pop("f:" + fid, (0, 0))
        for i, it in enumerate(f["items"]):
            self.pos["a:" + it] = list(self.free_cell(rows, near=at))
        self.save()

    def rename(self, fid, name):
        f = self.folders.get(fid)
        if f and name.strip():
            f["name"] = name.strip(); f.pop("name_fa", None); self.save()

    def title(self, fid, fa=False):
        f = self.folders[fid]
        return f.get("name_fa") if (fa and f.get("name_fa")) else f.get("name", "Folder")
