#!/usr/bin/python3
"""Open a Windows program (.exe/.msi/.bat/.lnk) like a native one. Log: ~/.cache/lmg/wine.log"""
import os, subprocess, sys, shutil, resource
PREFIX = os.path.expanduser("~/.wine")
LOGDIR = os.path.expanduser("~/.cache/lmg"); os.makedirs(LOGDIR, exist_ok=True)
LOG = LOGDIR + "/wine.log"
ENV = dict(os.environ, WINEPREFIX=PREFIX, WINEDEBUG="-all")

def raise_limits():
    """Windows games open thousands of files and map many memory areas: lift the soft open-files limit to the allowed maximum."""
    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        want = hard if hard != resource.RLIM_INFINITY else 1048576
        if soft < want: resource.setrlimit(resource.RLIMIT_NOFILE, (want, hard))
    except Exception: pass

def check_prefix():
    """The usual reasons for "cannot create file / cannot save": a Windows folder owned by root, a full disk, a read-only home."""
    problems = []; free = 0
    try:
        if os.path.isdir(PREFIX) and os.stat(PREFIX).st_uid != os.getuid():
            problems.append("owner")
            subprocess.run(["pkexec", "/usr/lib/lmg/bin/lmg-helper", "fix-home"], timeout=120)
        if os.path.isdir(PREFIX) and not os.access(PREFIX, os.W_OK): problems.append("readonly")
        free = shutil.disk_usage(os.path.expanduser("~")).free
        live = "boot=live" in open("/proc/cmdline").read()
        if free < 300 * 2**20 or (live and free < 4 * 2**30): problems.append("live-space" if live else "space")
    except Exception: pass
    if "live-space" in problems: note("Live session: the free storage here is only %d MB because it lives in RAM, so games report low storage. Install LMG OS to the disk for games." % (free // 2**20))
    if "live-space" in problems: note("Live session: the free storage here is only %d MB because it lives in RAM, so games report low storage. Install LMG OS to the disk for games." % (free // 2**20))
    if "space" in problems: note("Almost no free disk space is left - Windows programs cannot save. Free some space.")
    if "readonly" in problems: note("The Windows folder (~/.wine) is read-only, programs cannot save. See ~/.cache/lmg/wine.log")
    for d in ("Documents", "Downloads"):
        try: os.makedirs(os.path.expanduser("~/" + d), exist_ok=True)
        except Exception: pass
    with open(LOG, "a") as f:
        f.write("prefix check: %s\nmax_map_count=%s\n" % (problems or "ok", open("/proc/sys/vm/max_map_count").read().strip()))
        f.write(subprocess.run(["df", "-h", os.path.expanduser("~"), PREFIX], capture_output=True, text=True).stdout)

def note(txt):
    subprocess.Popen(["notify-send", "-u", "critical", "-t", "10000", "-i", "lmg-windows", "LMG OS", txt], stderr=subprocess.DEVNULL)

def run(cmd, env=None, timeout=None):
    with open(LOG, "a") as f:
        f.write("\n$ " + " ".join(cmd) + "\n"); f.flush()
        try: return subprocess.run(cmd, env=env or ENV, stdout=f, stderr=subprocess.STDOUT, timeout=timeout).returncode
        except Exception as e: f.write(str(e) + "\n"); return 1

def log_has(*words):
    try: t = open(LOG).read()
    except Exception: return False
    return any(w in t for w in words)

def is_pe32(path):
    try:
        d = open(path, "rb").read(4096); off = int.from_bytes(d[0x3c:0x40], "little")
        return d[off:off + 4] == b"PE\0\0" and int.from_bytes(d[off + 4:off + 6], "little") == 0x14c
    except Exception: return False

def have_wine32():
    return subprocess.run(["dpkg", "-s", "wine32:i386"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0

def install_wine32():
    note("Downloading the 32-bit Windows runtime (internet needed, one time)...")
    return subprocess.run(["pkexec", "/usr/lib/lmg/bin/lmg-helper", "wine32"]).returncode == 0

def make_prefix():
    env = dict(ENV, WINEDLLOVERRIDES="mscoree,mshtml=")        # no pop-ups asking for Mono/Gecko
    note("Preparing the Windows environment (first time only)...")
    open(LOG, "w").close()
    run(["wineboot", "-u"], env, timeout=900)
    if log_has("c0000135", "syswow64") and not have_wine32():     # Wine needs its 32-bit half
        if install_wine32():
            shutil.rmtree(PREFIX, ignore_errors=True); open(LOG, "w").close(); run(["wineboot", "-u"], env, timeout=900)
    run(["winecfg", "/v", "win10"], env, timeout=120)

def main():
    if len(sys.argv) < 2: return 1
    path = os.path.abspath(sys.argv[1]); low = path.lower()
    if low.endswith(".exe") and is_pe32(path) and not have_wine32():
        if not install_wine32(): note("Could not install the 32-bit runtime. See ~/.cache/lmg/wine.log"); return 1
    raise_limits(); check_prefix()
    if not os.path.isfile(PREFIX + "/system.reg"): make_prefix()
    os.chdir(os.path.dirname(path))
    cmd = ["wine", "msiexec", "/i", path] if low.endswith(".msi") else ["wine", "start", "/unix", path]
    env = ENV
    cap = "/usr/lib/lmg/native/lmg-statfs-cap.so"
    if low.endswith(".exe") and is_pe32(path) and os.path.exists(cap) and not os.environ.get("LMG_NO_STATFS_CAP"):
        # old 32-bit games overflow when they read a big free disk space ("less than 5 MB of storage"): report at most ~1.9 GB
        env = dict(ENV, LD_PRELOAD=cap + (":" + ENV["LD_PRELOAD"] if ENV.get("LD_PRELOAD") else ""))
    rc = run(cmd, env)
    if rc != 0: note("The Windows program reported an error. Details: ~/.cache/lmg/wine.log")
    return rc
sys.exit(main())
