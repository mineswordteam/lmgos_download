#!/usr/bin/python3
"""LMG OS desktop layer: the icons on the desktop, with Android-style folders.
- Drop an app on the middle of another app: they become a folder (translucent tile, neon blue edge, mini icons).
- Drop it near the corner of a cell: it only moves there.
- Click a folder: it opens in the middle of the screen with an animation; scroll with the wheel or the bar on its edge.
The layer is a transparent window that only takes mouse input where an icon is, so xfdesktop (wallpaper, right-click menu) keeps working under it."""
import os, sys, math, time, json
sys.path.insert(0, "/usr/lib/lmg")
import gi
gi.require_version("Gtk", "3.0"); gi.require_version("Gdk", "3.0"); gi.require_version("Pango", "1.0"); gi.require_version("PangoCairo", "1.0")
from gi.repository import Gtk, Gdk, GLib, Gio, GdkPixbuf, Pango, PangoCairo
import cairo
import dfmodel

CW, CH, ICON, MX, MY = 104, 108, 48, 14, 14
NEON = (0.15, 0.72, 1.0)
FA = (os.environ.get("LC_ALL") or os.environ.get("LANGUAGE") or os.environ.get("LANG") or "").startswith("fa")
STR = {"open": ("Open", "باز کردن"), "rename": ("Rename", "تغییر نام"), "ungroup": ("Ungroup folder", "باز کردن پوشه (حذف گروه)"),
       "trash": ("Move to Trash", "انتقال به سطل زباله"), "out": ("Take out of folder", "بیرون آوردن از پوشه"),
       "name": ("Folder name", "نام پوشه"), "ok": ("OK", "تأیید"), "cancel": ("Cancel", "لغو")}
def tr(k): return STR[k][1 if FA else 0]
def ease_out_back(t):
    c1 = 1.5; t -= 1; return 1 + (c1 + 1) * t ** 3 + c1 * t ** 2
def ease_out(t): return 1 - (1 - t) ** 3
def desktop_dir():
    try:
        import subprocess
        d = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True, text=True, timeout=5).stdout.strip()
        if d and d != os.path.expanduser("~"): return d
    except Exception: pass
    return os.path.expanduser("~/Desktop")
DESK = os.environ.get("LMG_DESKTOP_DIR") or desktop_dir()
STATE = os.environ.get("LMG_DFOLDERS_STATE") or os.path.expanduser("~/.config/lmg/desktop-folders.json")

_icons = {}
def icon_pb(name, size):
    k = (name, size)
    if k in _icons: return _icons[k]
    pb = None
    try:
        if name and os.path.isabs(name): pb = GdkPixbuf.Pixbuf.new_from_file_at_size(name, size, size)
        elif name: pb = Gtk.IconTheme.get_default().load_icon(name, size, Gtk.IconLookupFlags.FORCE_SIZE)
    except Exception: pb = None
    if pb is None:
        try: pb = Gtk.IconTheme.get_default().load_icon("application-x-executable", size, Gtk.IconLookupFlags.FORCE_SIZE)
        except Exception: pb = None
    _icons[k] = pb; return pb

class Entry:
    """One file on the Desktop: an app (.desktop), a folder or any file."""
    def __init__(self, fname):
        self.file = fname; self.path = os.path.join(DESK, fname); self.icon = None; self.name = fname; self.app = None
        if fname.endswith(".desktop"):
            self.exec = None
            try:
                kf = GLib.KeyFile(); kf.load_from_file(self.path, GLib.KeyFileFlags.NONE)
                self.name = kf.get_locale_string("Desktop Entry", "Name", None) or fname[:-8]
                self.icon = kf.get_string("Desktop Entry", "Icon"); self.exec = kf.get_string("Desktop Entry", "Exec")
            except Exception: self.name = fname[:-8]
            try: self.app = Gio.DesktopAppInfo.new_from_filename(self.path)
            except Exception: self.app = None
        else:
            try:
                info = Gio.File.new_for_path(self.path).query_info("standard::icon,standard::display-name", 0, None)
                self.name = info.get_display_name(); ic = info.get_icon()
                names = ic.get_names() if hasattr(ic, "get_names") else []
                th = Gtk.IconTheme.get_default()
                for n in names:
                    if th.has_icon(n): self.icon = n; break
            except Exception: pass
    def launch(self):
        try:
            if self.app is not None: self.app.launch([], None)
            elif getattr(self, "exec", None):
                import re; GLib.spawn_command_line_async(re.sub(r"%[a-zA-Z]", "", self.exec))
            else: Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(self.path).get_uri(), None)
        except Exception as e: print("launch failed", self.path, e, file=sys.stderr)

def list_entries():
    try: names = sorted(f for f in os.listdir(DESK) if not f.startswith("."))
    except OSError: names = []
    return names

def text(cr, s, cx, y, w, size=10, rgba=(1, 1, 1, 1), lines=2, shadow=True):
    lay = PangoCairo.create_layout(cr)
    lay.set_font_description(Pango.FontDescription("Sans %s" % size)); lay.set_width(int(w * Pango.SCALE))
    lay.set_wrap(Pango.WrapMode.WORD_CHAR); lay.set_ellipsize(Pango.EllipsizeMode.END); lay.set_height(-lines)
    lay.set_alignment(Pango.Alignment.CENTER); lay.set_text(s, -1)
    if shadow:
        cr.set_source_rgba(0, 0, 0, 0.75); cr.move_to(cx - w / 2 + 1, y + 1); PangoCairo.show_layout(cr, lay)
    cr.set_source_rgba(*rgba); cr.move_to(cx - w / 2, y); PangoCairo.show_layout(cr, lay)
    return lay.get_pixel_size()[1]

def rrect(cr, x, y, w, h, r):
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0); cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi); cr.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); cr.close_path()

def draw_icon(cr, pb, cx, cy, size, scale=1.0, alpha=1.0):
    if pb is None: return
    s = size * scale / max(pb.get_width(), 1)
    cr.save(); cr.translate(cx - pb.get_width() * s / 2, cy - pb.get_height() * s / 2); cr.scale(s, s)
    Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0); cr.paint_with_alpha(alpha); cr.restore()

def folder_tile(cr, cx, cy, size, icons, scale=1.0, glow=0.0):
    """The closed folder: translucent tile, neon blue edge, up to 9 mini icons."""
    s = size * scale; x, y = cx - s / 2, cy - s / 2
    if glow > 0:
        for i, a in ((10, .05), (7, .09), (4, .14)):
            rrect(cr, x - i * glow, y - i * glow, s + 2 * i * glow, s + 2 * i * glow, s * .28 + i * glow); cr.set_source_rgba(*NEON, a * glow * 2); cr.fill()
    rrect(cr, x, y, s, s, s * .28); cr.set_source_rgba(0.55, 0.75, 1.0, 0.16); cr.fill_preserve()
    cr.set_source_rgba(*NEON, 0.95); cr.set_line_width(2); cr.stroke()
    n = min(9, len(icons)); g = s / 3.5; ox, oy = cx - g * 1.5 + g / 2 - g / 2 * 0, cy - g * 1.5
    for i in range(n):
        r, c = divmod(i, 3)
        draw_icon(cr, icons[i], cx + (c - 1) * g, cy + (r - 1) * g, g * .86, 1.0)

class Layer(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL, title="LMG Desktop")
        self.set_decorated(False); self.set_skip_taskbar_hint(True); self.set_skip_pager_hint(True); self.set_accept_focus(False)
        # a normal window kept below all others (not a DESKTOP-type one: xfdesktop raises itself over those on a click and the icons would vanish)
        self.set_type_hint(Gdk.WindowTypeHint.NORMAL); self.set_keep_below(True); self.stick(); self.set_app_paintable(True)
        scr = self.get_screen(); vis = scr.get_rgba_visual()
        if vis: self.set_visual(vis)
        self.area = Gtk.DrawingArea(); self.add(self.area)
        self.area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK | Gdk.EventMask.POINTER_MOTION_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.area.connect("draw", self.on_draw); self.area.connect("button-press-event", self.on_press)
        self.area.connect("button-release-event", self.on_release); self.area.connect("motion-notify-event", self.on_motion)
        self.area.connect("leave-notify-event", lambda *a: self._hover(None))
        self.geom(); self.model = dfmodel.Model(STATE); self.entries = {}; self.cur = {}
        self.hover = None; self.press = None; self.drag = None; self.view = None; self.pop = {}; self.tick_id = 0; self.last_click = (None, 0)
        self.refresh()
        self.mon = Gio.File.new_for_path(DESK).monitor_directory(Gio.FileMonitorFlags.NONE, None)
        self.mon.connect("changed", lambda *a: GLib.timeout_add(300, self.refresh_once)); self._rf = False
        GLib.timeout_add_seconds(4, lambda: (self.refresh(), True)[1])
        self.connect("realize", lambda *a: self.shape()); self.connect("map-event", lambda *a: GLib.idle_add(self.shape) and False)
        self.show_all(); self.lower_window()
        self.connect("focus-in-event", lambda *a: (self.lower_window(), False)[1])

    def lower_window(self):
        w = self.get_window()
        if w: w.lower()

    def geom(self):
        d = Gdk.Display.get_default(); mon = d.get_primary_monitor() or d.get_monitor(0)
        wa = mon.get_workarea(); self.wx, self.wy, self.ww, self.wh = wa.x, wa.y, wa.width, wa.height
        self.mg = mon.get_geometry()
        self.rows = max(1, (self.wh - 2 * MY) // CH)
        self.move(self.wx, self.wy); self.set_default_size(self.ww, self.wh); self.resize(self.ww, self.wh)

    # ---- data
    def refresh_once(self):
        self.refresh(); return False
    def refresh(self):
        names = list_entries()
        for n in names:
            if n not in self.entries or not os.path.exists(self.entries[n].path): self.entries[n] = Entry(n)
        for n in list(self.entries):
            if n not in names: del self.entries[n]
        vis = [n for n in names if True]
        self.model.sync(vis, self.rows)
        self.layout_items()
        if self.view is not None: self.view.refresh()
        self.area.queue_draw(); self.shape(); return True

    def cellpos(self, c, r): return MX + c * CW + CW / 2, MY + r * CH + ICON / 2 + 12

    def layout_items(self):
        self.items = []
        for k in self.model.keys(list(self.entries)):
            c, r = self.model.pos[k]; x, y = self.cellpos(c, r)
            if k.startswith("f:"):
                f = self.model.folders[k[2:]]; label = self.model.title(k[2:], FA)
                icons = [icon_pb(self.entries[i].icon, 32) for i in f["items"] if i in self.entries]
            else:
                e = self.entries[k[2:]]; label = e.name; icons = [icon_pb(e.icon, ICON)]
            self.items.append({"key": k, "label": label, "icons": icons, "x": x, "y": y})
            cp = self.cur.get(k)
            if cp is None: self.cur[k] = [x, y]
        for k in list(self.cur):
            if k not in {i["key"] for i in self.items}: del self.cur[k]
        self.kick()

    def item_at(self, px, py, exclude=None):
        for it in reversed(self.items):
            if it["key"] == exclude: continue
            cx, cy = self.cur[it["key"]]
            if abs(px - cx) <= CW / 2 - 6 and cy - ICON / 2 - 8 <= py <= cy + ICON / 2 + 34: return it
        return None

    def center_hit(self, it, px, py):
        cx, cy = self.cur[it["key"]]
        return abs(px - cx) <= 30 and abs(py - cy) <= 30

    # ---- input region: only icons take the mouse (the rest falls through to xfdesktop)
    def shape(self):
        w = self.area.get_window() or self.get_window()
        if not w: return False
        if self.drag is not None or self.view is not None:
            reg = cairo.Region(cairo.RectangleInt(0, 0, self.ww, self.wh))
        else:
            reg = cairo.Region()
            for it in self.items:
                cx, cy = self.cur[it["key"]]
                reg.union(cairo.RectangleInt(int(cx - CW / 2 + 4), int(cy - ICON / 2 - 8), int(CW - 8), int(ICON + 46)))
        for win in (self.get_window(), self.area.get_window()):
            if win: win.input_shape_combine_region(reg, 0, 0)
        return False

    # ---- animation
    def kick(self):
        if not self.tick_id: self.tick_id = GLib.timeout_add(16, self.tick)
    def tick(self):
        busy = False; now = time.time()
        for it in self.items:
            if self.drag and self.drag["key"] == it["key"]: continue
            cp = self.cur[it["key"]]
            for i, tgt in enumerate((it["x"], it["y"])):
                d = tgt - cp[i]
                if abs(d) > 0.5: cp[i] += d * 0.28; busy = True
                else: cp[i] = tgt
        for k in list(self.pop):
            if now - self.pop[k] > 0.45: del self.pop[k]
            else: busy = True
        if self.drag: busy = True
        self.area.queue_draw()
        if not busy: self.tick_id = 0; self.shape(); return False
        return True

    def popscale(self, k):
        t0 = self.pop.get(k)
        if t0 is None: return 1.0
        t = min(1, (time.time() - t0) / 0.45); return 1 + 0.18 * math.sin(t * math.pi)

    # ---- drawing
    def on_draw(self, w, cr):
        cr.set_operator(cairo.OPERATOR_SOURCE); cr.set_source_rgba(0, 0, 0, 0); cr.paint(); cr.set_operator(cairo.OPERATOR_OVER)
        tgt = self.drag_target() if self.drag else None
        for it in self.items:
            if self.drag and self.drag["key"] == it["key"]: continue
            self.draw_item(cr, it, *self.cur[it["key"]], hot=(it["key"] == self.hover and not self.drag), glow=(tgt is not None and it["key"] == tgt["key"]))
        if self.drag:
            it = next(i for i in self.items if i["key"] == self.drag["key"])
            px, py = self.drag["x"], self.drag["y"]
            if tgt is None:  # where it would land
                c = self.drop_cell(px, py); x, y = self.cellpos(*c)
                rrect(cr, x - CW / 2 + 8, y - ICON / 2 - 6, CW - 16, ICON + 40, 14); cr.set_source_rgba(*NEON, 0.10); cr.fill_preserve(); cr.set_source_rgba(*NEON, 0.45); cr.set_line_width(1.5); cr.stroke()
            self.draw_item(cr, it, px, py, hot=False, glow=False, lift=True)
        return False

    def draw_item(self, cr, it, cx, cy, hot, glow, lift=False):
        if hot:
            rrect(cr, cx - CW / 2 + 6, cy - ICON / 2 - 8, CW - 12, ICON + 46, 12); cr.set_source_rgba(1, 1, 1, 0.13); cr.fill()
        sc = self.popscale(it["key"]) * (1.12 if lift else 1.0) * (1.12 if glow else 1.0)
        if it["key"].startswith("f:"): folder_tile(cr, cx, cy, ICON + 10, it["icons"], sc, 1.0 if glow else 0.0)
        else: draw_icon(cr, it["icons"][0], cx, cy, ICON, sc, 0.85 if lift else 1.0)
        if not lift: text(cr, it["label"], cx, cy + ICON / 2 + 8, CW - 10, 9.5)

    # ---- mouse
    def _hover(self, k):
        if k != self.hover: self.hover = k; self.area.queue_draw()
    def on_motion(self, w, ev):
        if self.press and not self.drag and (abs(ev.x - self.press["x0"]) > 6 or abs(ev.y - self.press["y0"]) > 6) and self.press["key"].startswith(("a:", "f:")):
            self.drag = {"key": self.press["key"], "x": ev.x, "y": ev.y, "dx": ev.x - self.press["cx"], "dy": ev.y - self.press["cy"]}
            self.shape(); self.kick()
        if self.drag:
            self.drag["x"], self.drag["y"] = ev.x - self.drag["dx"], ev.y - self.drag["dy"]; self.area.queue_draw()
        else:
            it = self.item_at(ev.x, ev.y); self._hover(it["key"] if it else None)
        return True

    def drag_target(self):
        d = self.drag
        if not d: return None
        it = self.item_at(d["x"], d["y"], exclude=d["key"])
        if it and self.center_hit(it, d["x"], d["y"]) and d["key"].startswith("a:"): return it
        return None

    def drop_cell(self, px, py):
        c = int(round((px - MX - CW / 2) / CW)); r = int(round((py - MY - ICON / 2 - 12) / CH))
        c = max(0, min(c, (self.ww - 2 * MX) // CW - 1)); r = max(0, min(r, self.rows - 1))
        return (c, r)

    def on_press(self, w, ev):
        it = self.item_at(ev.x, ev.y)
        if not it: return False
        if ev.button == 3:
            self.menu(it, ev); return True
        if ev.button != 1: return True
        cx, cy = self.cur[it["key"]]
        self.press = {"key": it["key"], "x0": ev.x, "y0": ev.y, "cx": cx, "cy": cy}
        return True

    def on_release(self, w, ev):
        p, d = self.press, self.drag; self.press = None
        if d:
            self.drag = None; tgt = None
            it = self.item_at(d["x"], d["y"], exclude=d["key"])
            if it and self.center_hit(it, d["x"], d["y"]) and d["key"].startswith("a:"): tgt = it
            if tgt:
                nk = self.model.drop_on(d["key"], tgt["key"], self.rows)
                self.refresh(); 
                if nk: self.pop[nk] = time.time()
            else:
                self.model.move(d["key"], self.drop_cell(d["x"], d["y"]), self.rows); self.refresh()
            self.shape(); self.kick(); return True
        if p and ev.button == 1:
            k = p["key"]
            if k.startswith("f:"): self.open_folder(k[2:])
            else:
                now = time.time(); lk, lt = self.last_click
                if lk == k and now - lt < 0.5:
                    self.entries[k[2:]].launch(); self.last_click = (None, 0)
                else: self.last_click = (k, now)
        return True

    def menu(self, it, ev):
        m = Gtk.Menu(); k = it["key"]
        def add(label, cb):
            mi = Gtk.MenuItem(label=label); mi.connect("activate", lambda *a: cb()); m.append(mi)
        if k.startswith("f:"):
            fid = k[2:]
            add(tr("open"), lambda: self.open_folder(fid)); add(tr("rename"), lambda: self.rename(fid))
            add(tr("ungroup"), lambda: (self.model.ungroup(fid, self.rows), self.refresh()))
        else:
            add(tr("open"), lambda: self.entries[k[2:]].launch())
            add(tr("trash"), lambda: self.trash(k[2:]))
        m.show_all(); m.popup_at_pointer(ev)

    def trash(self, fname):
        try: Gio.File.new_for_path(os.path.join(DESK, fname)).trash(None)
        except Exception as e: print("trash failed", e, file=sys.stderr)
        GLib.timeout_add(200, self.refresh_once)

    def rename(self, fid):
        dlg = Gtk.Dialog(title=tr("name"), flags=Gtk.DialogFlags.MODAL); dlg.set_keep_above(True)
        e = Gtk.Entry(); e.set_text(self.model.title(fid, FA)); e.set_activates_default(True)
        dlg.get_content_area().add(e); dlg.add_button(tr("cancel"), Gtk.ResponseType.CANCEL); b = dlg.add_button(tr("ok"), Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK); dlg.show_all()
        if dlg.run() == Gtk.ResponseType.OK: self.model.rename(fid, e.get_text()); self.refresh()
        dlg.destroy()

    # ---- the open folder
    def open_folder(self, fid):
        if self.view is not None: return
        k = "f:" + fid; cx, cy = self.cur.get(k, (self.ww / 2, self.wh / 2))
        self.view = FolderView(self, fid, (self.wx + cx, self.wy + cy)); self.shape()

    def folder_closed(self):
        self.view = None; self.shape(); self.area.queue_draw()

class FolderView(Gtk.Window):
    """Full-screen glass overlay with the folder panel in the middle."""
    PC, PCW, PCH = 4, 124, 128
    def __init__(self, layer, fid, origin):
        super().__init__(type=Gtk.WindowType.TOPLEVEL, title="LMG Folder")
        self.layer, self.fid, self.origin = layer, fid, origin
        self.set_decorated(False); self.set_skip_taskbar_hint(True); self.set_keep_above(True); self.set_app_paintable(True)
        vis = self.get_screen().get_rgba_visual()
        if vis: self.set_visual(vis)
        self.area = Gtk.DrawingArea(); self.add(self.area)
        self.area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK | Gdk.EventMask.POINTER_MOTION_MASK | Gdk.EventMask.SCROLL_MASK | Gdk.EventMask.SMOOTH_SCROLL_MASK)
        self.area.connect("draw", self.on_draw); self.area.connect("button-press-event", self.on_press)
        self.area.connect("button-release-event", self.on_release); self.area.connect("motion-notify-event", self.on_motion)
        self.area.connect("scroll-event", self.on_scroll); self.connect("key-press-event", self.on_key)
        g = layer.mg; self.set_default_size(g.width, g.height); self.move(g.x, g.y); self.sw, self.sh = g.width, g.height; self.gx, self.gy = g.x, g.y
        self.scroll = 0.0; self.sv = 0.0; self.hover = None; self.press = None; self.drag = None; self.bar_drag = None
        self.t0 = time.time(); self.closing = None; self.refresh()
        self.fullscreen(); self.show_all(); self.present_with_time(Gtk.get_current_event_time())
        GLib.timeout_add(16, self.tick)

    def refresh(self):
        L = self.layer; f = L.model.folders.get(self.fid)
        if f is None: self.begin_close(); return
        self.title = L.model.title(self.fid, FA)
        self.its = [(n, L.entries[n]) for n in f["items"] if n in L.entries]
        rows = max(1, math.ceil(len(self.its) / self.PC)); self.rows_total = rows
        self.pw = self.PC * self.PCW + 60; self.vis_rows = min(rows, 3)
        self.ph = 84 + self.vis_rows * self.PCH + 24
        self.px = (self.sw - self.pw) / 2; self.py = (self.sh - self.ph) / 2 - 10
        self.max_scroll = max(0, rows * self.PCH - self.vis_rows * self.PCH)
        self.scroll = min(self.scroll, self.max_scroll); self.sv = self.scroll

    def ph_progress(self):
        now = time.time()
        if self.closing is not None: return max(0.0, 1 - (now - self.closing) / 0.22)
        return min(1.0, (now - self.t0) / 0.32)
    def tick(self):
        if self.closing is not None and time.time() - self.closing > 0.23:
            self.layer.folder_closed(); self.destroy(); return False
        self.sv += (self.scroll - self.sv) * 0.3
        self.area.queue_draw(); return True

    def begin_close(self):
        if self.closing is None: self.closing = time.time()

    def item_rect(self, i):
        r, c = divmod(i, self.PC)
        x = self.px + 30 + c * self.PCW; y = self.py + 84 + r * self.PCH - self.sv
        return x, y, self.PCW, self.PCH
    def item_at(self, mx, my):
        if not (self.px < mx < self.px + self.pw and self.py + 84 <= my < self.py + 84 + self.vis_rows * self.PCH): return None
        for i, (n, e) in enumerate(self.its):
            x, y, w, h = self.item_rect(i)
            if x <= mx <= x + w and y <= my <= y + h: return i
        return None

    def on_draw(self, w, cr):
        p = self.ph_progress(); closing = self.closing is not None
        cr.set_operator(cairo.OPERATOR_SOURCE); cr.set_source_rgba(0, 0, 0, 0); cr.paint(); cr.set_operator(cairo.OPERATOR_OVER)
        cr.set_source_rgba(0.02, 0.05, 0.12, 0.42 * (ease_out(p))); cr.paint()
        s = ease_out(p) if closing else ease_out_back(p); s = max(0.05, s)
        ox, oy = self.origin[0] - self.gx, self.origin[1] - self.gy; tx, ty = self.sw / 2, self.py + self.ph / 2
        k = ease_out(p); cx = ox + (tx - ox) * k; cy = oy + (ty - oy) * k
        cr.save(); cr.translate(cx, cy); cr.scale(s, s); cr.translate(-self.sw / 2, -(self.py + self.ph / 2))
        cr.push_group()
        px, py, pw, ph = self.px, self.py, self.pw, self.ph
        for i, a in ((16, .04), (11, .06), (7, .09), (4, .13)):  # neon glow
            rrect(cr, px - i, py - i, pw + 2 * i, ph + 2 * i, 30 + i); cr.set_source_rgba(*NEON, a); cr.fill()
        rrect(cr, px, py, pw, ph, 30); cr.set_source_rgba(0.06, 0.11, 0.2, 0.62); cr.fill_preserve()
        cr.set_source_rgba(*NEON, 1.0); cr.set_line_width(2.5); cr.stroke()
        text(cr, self.title, self.sw / 2, py + 22, pw - 120, 15, (1, 1, 1, 1), 1)
        cr.save(); cr.rectangle(px + 10, py + 80, pw - 20, self.vis_rows * self.PCH + 6); cr.clip()
        for i, (n, e) in enumerate(self.its):
            x, y, w_, h = self.item_rect(i)
            if y + h < py + 80 or y > py + ph: continue
            if i == self.hover and not self.drag:
                rrect(cr, x + 6, y + 4, w_ - 12, h - 8, 14); cr.set_source_rgba(1, 1, 1, 0.14); cr.fill()
            if self.drag and self.drag["i"] == i: continue
            draw_icon(cr, icon_pb(e.icon, 64), x + w_ / 2, y + 44, 56)
            text(cr, e.name, x + w_ / 2, y + 80, w_ - 14, 10, (1, 1, 1, 1), 2)
        cr.restore()
        if self.max_scroll > 0:  # scroll bar on the edge
            th = self.vis_rows * self.PCH; bh = max(30, th * th / (th + self.max_scroll)); by = py + 84 + (th - bh) * (self.sv / self.max_scroll)
            rrect(cr, px + pw - 16, py + 84, 6, th, 3); cr.set_source_rgba(1, 1, 1, 0.12); cr.fill()
            rrect(cr, px + pw - 16, by, 6, bh, 3); cr.set_source_rgba(*NEON, 0.95); cr.fill()
        cr.pop_group_to_source(); cr.paint_with_alpha(min(1.0, p * 1.6)); cr.restore()
        if self.drag:
            e = self.its[self.drag["i"]][1]; draw_icon(cr, icon_pb(e.icon, 64), self.drag["x"], self.drag["y"], 60, 1.0, 0.9)
        return False

    def on_motion(self, w, ev):
        if self.bar_drag is not None:
            th = self.vis_rows * self.PCH; self.scroll = max(0, min(self.max_scroll, self.bar_drag[1] + (ev.y - self.bar_drag[0]) * (th + self.max_scroll) / th)); return True
        if self.press is not None and not self.drag and (abs(ev.x - self.press[1]) > 8 or abs(ev.y - self.press[2]) > 8):
            self.drag = {"i": self.press[0], "x": ev.x, "y": ev.y}
        if self.drag: self.drag["x"], self.drag["y"] = ev.x, ev.y
        else: self.hover = self.item_at(ev.x, ev.y)
        return True

    def on_press(self, w, ev):
        if self.closing is not None: return True
        if ev.button != 1: return True
        if self.max_scroll > 0 and self.px + self.pw - 22 <= ev.x <= self.px + self.pw - 6 and self.py + 84 <= ev.y <= self.py + 84 + self.vis_rows * self.PCH:
            self.bar_drag = (ev.y, self.scroll); return True
        if self.py <= ev.y <= self.py + 56 and self.px + 80 < ev.x < self.px + self.pw - 80:
            self.layer.rename(self.fid); self.refresh(); return True
        i = self.item_at(ev.x, ev.y)
        if i is not None: self.press = (i, ev.x, ev.y)
        elif not (self.px <= ev.x <= self.px + self.pw and self.py <= ev.y <= self.py + self.ph): self.begin_close()
        return True

    def on_release(self, w, ev):
        self.bar_drag = None; p, d = self.press, self.drag; self.press = None; self.drag = None
        if d is not None:
            if not (self.px <= ev.x <= self.px + self.pw and self.py <= ev.y <= self.py + self.ph):  # dropped outside: onto the desktop
                fname = self.its[d["i"]][0]; L = self.layer
                c = L.drop_cell(ev.x + self.gx - L.wx, ev.y + self.gy - L.wy)
                L.model.take_out(fname, c, L.rows)
                L.refresh(); self.begin_close()
            return True
        if p is not None:
            i = self.item_at(ev.x, ev.y)
            if i == p[0]:
                self.its[i][1].launch(); self.begin_close()
        return True

    def on_scroll(self, w, ev):
        if ev.direction == Gdk.ScrollDirection.UP: d = -self.PCH * 0.6
        elif ev.direction == Gdk.ScrollDirection.DOWN: d = self.PCH * 0.6
        elif ev.direction == Gdk.ScrollDirection.SMOOTH: d = ev.delta_y * self.PCH * 0.5
        else: return True
        self.scroll = max(0, min(self.max_scroll, self.scroll + d)); return True

    def on_key(self, w, ev):
        k = ev.keyval
        if k == Gdk.KEY_Escape: self.begin_close()
        elif k in (Gdk.KEY_Down, Gdk.KEY_Page_Down): self.scroll = min(self.max_scroll, self.scroll + self.PCH)
        elif k in (Gdk.KEY_Up, Gdk.KEY_Page_Up): self.scroll = max(0, self.scroll - self.PCH)
        return True

def main():
    scr = Gdk.Screen.get_default()
    for _ in range(40):  # no compositor = a transparent window would be black: wait for it, else step aside
        if scr.is_composited() and scr.get_rgba_visual(): break
        time.sleep(0.5)
    else:
        print("no compositor - leaving the icons to xfdesktop", file=sys.stderr); sys.exit(3)
    L = Layer()
    L.connect("destroy", Gtk.main_quit)
    Gtk.main()

if __name__ == "__main__":
    main()
