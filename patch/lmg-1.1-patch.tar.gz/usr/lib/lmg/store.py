#!/usr/bin/python3
"""LMG Store window: WebKit on the local page."""
import os, sys
sys.path.insert(0, "/usr/lib/lmg")
os.environ.setdefault("WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS", "1")
import gi
gi.require_version("Gtk", "3.0"); gi.require_version("Gdk", "3.0"); gi.require_version("WebKit2", "4.1")
from gi.repository import Gtk, Gdk, GLib, WebKit2
import store_server

def main():
    srv = store_server.Server()
    win = Gtk.Window(title="LMG Store"); win.set_default_size(1180, 760)
    try: win.set_icon_name("lmg-store")
    except Exception: pass
    win.set_wmclass("lmg-store", "LMG Store")
    win.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.02, 0.04, 0.09, 1))
    view = WebKit2.WebView.new_with_context(WebKit2.WebContext.new_ephemeral())
    st = view.get_settings(); st.set_enable_developer_extras(False); st.set_enable_smooth_scrolling(False)
    st.set_hardware_acceleration_policy(WebKit2.HardwareAccelerationPolicy.ON_DEMAND)
    view.set_background_color(Gdk.RGBA(0.02, 0.04, 0.09, 1))
    view.connect("context-menu", lambda *a: True)
    view.connect("web-process-terminated", lambda v, r: (view.reload(), True)[1])
    win.add(view); win.connect("destroy", Gtk.main_quit); win.show_all()
    view.load_uri(srv.url)
    Gtk.main()
    try: srv.stop()
    except Exception: pass

if __name__ == "__main__":
    main(); sys.stdout.flush(); os._exit(0)
