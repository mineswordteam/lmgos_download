"""LMG Store: the small local web server the store window talks to (127.0.0.1 only, token for anything that changes the machine)."""
import json, os, secrets, threading, urllib.parse
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import store_backend as B

WEB = os.environ.get("LMG_STORE_WEB", "/usr/share/lmg/store")
LOGO = os.environ.get("LMG_LOGO", "/usr/share/lmg/branding/logo-main.png")
HOME = B.HOME


CONF = os.path.join(HOME, ".config", "lmg", "store.json")

def _json(p):
    try: return json.load(open(p))
    except Exception: return {}

def language():
    """(language, asked): the store's own choice wins; before the first choice the system language is only a suggestion."""
    mine = _json(CONF).get("lang")
    if mine in ("en", "fa"): return mine, True
    return ("fa" if _json(os.path.join(HOME, ".config", "lmg", "settings.json")).get("language") == "fa" else "en"), False

def set_language(l):
    if l not in ("en", "fa"): return False
    d = _json(CONF); d["lang"] = l
    os.makedirs(os.path.dirname(CONF), exist_ok=True); json.dump(d, open(CONF, "w")); return True

def mark_installed(apps):
    fl = B.installed_flatpaks(); ap = B.installed_apt([a["id"] for a in apps if a["src"] == "apt"])
    for a in apps: a["installed"] = (a["id"] in fl) if a["src"] == "flatpak" else (a["id"] in ap)
    return apps

def home_data():
    with ThreadPoolExecutor(6) as ex:
        feat = list(ex.map(B.flathub_detail, B.FEATURED))
        pop, trend, rec = [ex.submit(B.flathub_list, k, 1, 16) for k in ("popular", "trending", "recently-updated")]
        feat = [d for d in feat if d and d.get("shots")]
        for d in feat: d["description"] = ""
        return {"featured": feat[:6], "popular": mark_installed(pop.result()), "trending": mark_installed(trend.result()), "recent": mark_installed(rec.result()),
                "cats": [{"id": i, "en": e, "fa": f} for i, e, f in B.CATS]}

def search(q):
    fl = B.flathub_search(q); ap = B.apt_search(q) if q else []
    seen = {a["name"].lower() for a in fl}
    return mark_installed(fl + [a for a in ap if a["name"].lower() not in seen][:12])


class Server:
    def __init__(self):
        self.token = secrets.token_urlsafe(12); self.ready = False
        srv = self
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _send(self, code, body, ctype="application/json", cache="no-store"):
                if isinstance(body, (dict, list)): body = json.dumps(body, ensure_ascii=False).encode()
                self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", cache); self.end_headers(); self.wfile.write(body)
            def _file(self, path, ctype):
                try: data = open(path, "rb").read()
                except OSError: return self._send(404, b"", "text/plain")
                self._send(200, data, ctype, "max-age=600")
            def do_GET(self):
                u = urllib.parse.urlparse(self.path); p = u.path; q = urllib.parse.parse_qs(u.query)
                g = lambda k, d="": (q.get(k) or [d])[0]
                try:
                    if p == "/":
                        html = open(os.path.join(WEB, "index.html"), encoding="utf-8").read().replace("__TOKEN__", srv.token)
                        return self._send(200, html.encode(), "text/html; charset=utf-8")
                    if p == "/logo.png": return self._file(LOGO, "image/png")
                    if p.startswith("/f/"): return self._file(os.path.join(WEB, "fonts", os.path.basename(p)), "font/ttf")
                    if p == "/img":
                        b, ct = B.fetch_image(g("u"))
                        return self._send(200, b, ct, "max-age=86400") if b else self._send(404, b"", "text/plain")
                    if p == "/api/info":
                        l, asked = language(); return self._send(200, {"lang": l, "asked": asked, "mock": B.MOCK})
                    if p == "/api/home": return self._send(200, home_data())
                    if p == "/api/list":
                        cat = g("cat"); kind = g("kind", "popular"); page = max(1, int(g("page", "1") or 1))
                        return self._send(200, mark_installed(B.flathub_list(kind, page, 24, cat or None)))
                    if p == "/api/search": return self._send(200, search(g("q").strip()))
                    if p == "/api/app":
                        d = B.flathub_detail(g("id")) if g("src") == "flatpak" else B.apt_detail(g("id"))
                        if not d: return self._send(404, {"error": "not found"})
                        d["installed"] = (g("id") in B.installed_flatpaks()) if d["src"] == "flatpak" else (g("id") in B.installed_apt([g("id")]))
                        d["download_h"] = B.human(d["download"]); d["installed_h"] = B.human(d["installed_size"])
                        return self._send(200, d)
                    if p == "/api/installed": return self._send(200, B.installed_list())
                    if p == "/api/windows":
                        return self._send(200, [{"src": "windows", "id": n, "name": n, "summary": s, "site": site, "cats": [c], "icon": ""} for n, s, site, c in B.WINDOWS])
                    if p == "/api/job":
                        j = B.job_info(g("id")); return self._send(200, j) if j else self._send(404, {})
                except Exception as e:
                    return self._send(500, {"error": str(e)})
                self._send(404, b"", "text/plain")
            def do_POST(self):
                if self.headers.get("X-Token") != srv.token: return self._send(403, {"ok": False})
                n = int(self.headers.get("Content-Length", 0) or 0)
                try: d = json.loads(self.rfile.read(n) or b"{}")
                except Exception: d = {}
                p = self.path.split("?")[0]
                if p in ("/api/install", "/api/remove"):
                    meta = {k: d.get(k, "") for k in ("name", "icon", "summary")}
                    j = B.start_job("install" if p.endswith("install") else "remove", d.get("src"), d.get("id"), meta)
                    return self._send(200, {"ok": bool(j.cmd), "job": j.id})
                if p == "/api/launch": return self._send(200, {"ok": B.launch(d.get("src"), d.get("id"))})
                if p == "/api/open":
                    u = d.get("url", "")
                    if u.startswith("https://"):
                        import subprocess; subprocess.Popen(["xdg-open", u], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return self._send(200, {"ok": True})
                if p == "/api/lang": return self._send(200, {"ok": set_language(d.get("lang"))})
                if p == "/api/ready": srv.ready = True; return self._send(200, {"ok": True})
                self._send(404, {"ok": False})
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    @property
    def url(self): return "http://127.0.0.1:%d/" % self.port
    def stop(self): self.httpd.shutdown()
