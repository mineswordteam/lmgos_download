#!/usr/bin/python3
"""After an upgrade, brings each user's own settings up to date WITHOUT touching their choices.
Rules for every migration in /usr/lib/lmg/migrations/NNNN-name.py (function migrate(ctx)):
  * only ADD new things (a new default setting, a new shortcut); never remove, reorder or overwrite what the user has;
  * set a default only when the user has none;
  * runs once per user (recorded in ~/.config/lmg/migrated.json); a copy of ~/.config/lmg and ~/.config/xfce4 is kept first."""
import importlib.util, json, os, shutil, subprocess, sys, time

MIG = os.environ.get("LMG_MIGRATIONS", "/usr/lib/lmg/migrations")
CONF = os.environ.get("LMG_USER_CONF", os.path.expanduser("~/.config"))
STATE = os.path.join(CONF, "lmg", "migrated.json")


class Ctx:
    def __init__(self):
        self.log = []

    def xfconf_default(self, channel, prop, vtype, value):
        """Set an xfconf property only if the user does not have it yet."""
        have = subprocess.run(["xfconf-query", "-c", channel, "-p", prop], capture_output=True, text=True)
        if have.returncode == 0:
            return False
        r = subprocess.run(["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", vtype, "-s", str(value)], capture_output=True, text=True)
        self.log.append("%s %s=%s (%s)" % (channel, prop, value, "ok" if r.returncode == 0 else "failed"))
        return r.returncode == 0

    def setting_default(self, key, value):
        """Same for ~/.config/lmg/settings.json."""
        p = os.path.join(CONF, "lmg", "settings.json")
        try: d = json.load(open(p))
        except Exception: d = {}
        if key in d: return False
        d[key] = value; os.makedirs(os.path.dirname(p), exist_ok=True); json.dump(d, open(p, "w"))
        self.log.append("settings %s=%s" % (key, value)); return True

    def start_menu_favorites(self, desktop_ids):
        """Add launchers to the Start menu's Favorites tab - only the ones missing, at the end, nothing removed or reordered."""
        rc = os.path.join(CONF, "xfce4", "panel", "whiskermenu-1.rc")
        try: lines = open(rc).read().split("\n")
        except OSError: return False
        for i, l in enumerate(lines):
            if l.startswith("favorites="):
                have = [x for x in l[len("favorites="):].split(",") if x]
                add = [d for d in desktop_ids if d not in have]
                if not add: return False
                lines[i] = "favorites=" + ",".join(have + add)
                with open(rc, "w") as f: f.write("\n".join(lines))
                self.log.append("start menu favorites + " + ",".join(add))
                subprocess.run(["xfce4-panel", "-r"], capture_output=True)       # the panel reads the file at start
                return True
        return False

    def undo_shortcut(self, desktop_id, desktop_file):
        """Take back a shortcut that LMG itself added by mistake (Start-menu favorite and the unmodified Desktop launcher). Nothing else is touched."""
        rc = os.path.join(CONF, "xfce4", "panel", "whiskermenu-1.rc"); changed = False
        try:
            lines = open(rc).read().split("\n")
            for i, l in enumerate(lines):
                if l.startswith("favorites="):
                    have = [x for x in l[len("favorites="):].split(",") if x]
                    if desktop_id in have:
                        lines[i] = "favorites=" + ",".join(x for x in have if x != desktop_id); changed = True
            if changed:
                open(rc, "w").write("\n".join(lines)); self.log.append("start menu favorites - " + desktop_id)
                subprocess.run(["xfce4-panel", "-r"], capture_output=True)
        except OSError:
            pass
        desk = os.environ.get("LMG_USER_DESKTOP") or os.path.join(os.path.dirname(CONF) if CONF.endswith(".config") else CONF, "Desktop")
        f = os.path.join(desk, desktop_file)
        try:
            src = "/usr/share/lmg/desktop-items/" + desktop_file
            if os.path.exists(f) and (not os.path.exists(src)):      # the shipped copy is gone: this was ours
                os.remove(f); self.log.append("desktop - " + desktop_file)
        except OSError:
            pass


def load(path):
    spec = importlib.util.spec_from_file_location(os.path.basename(path)[:-3].replace("-", "_"), path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def main():
    try: done = json.load(open(STATE))
    except Exception: done = {}
    try: names = sorted(f for f in os.listdir(MIG) if f.endswith(".py") and f[0].isdigit())
    except OSError: return 0
    todo = [n for n in names if n not in done]
    if not todo: return 0
    bk = os.path.join(CONF, "lmg", "backup-" + time.strftime("%Y%m%d-%H%M%S"))
    for sub in ("lmg", "xfce4"):
        src = os.path.join(CONF, sub)
        if os.path.isdir(src):
            try: shutil.copytree(src, os.path.join(bk, sub), ignore=shutil.ignore_patterns("backup-*"))
            except Exception: pass
    ctx = Ctx()
    for n in todo:
        try:
            load(os.path.join(MIG, n)).migrate(ctx); done[n] = int(time.time())
        except Exception as e:
            ctx.log.append("%s failed: %r" % (n, e))
    os.makedirs(os.path.dirname(STATE), exist_ok=True); json.dump(done, open(STATE, "w"))
    try: open(os.path.join(CONF, "lmg", "migrate.log"), "a").write("\n".join(ctx.log) + "\n")
    except Exception: pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
