import os, platform, json
from lmgcommon import *
import psutil

def dmi(name):
    try: return open(f"/sys/class/dmi/id/{name}").read().strip()
    except Exception: return "-"

def kv_grid(rows):
    g = Gtk.Grid(column_spacing=18, row_spacing=6); g.set_border_width(12)
    for i, (k, v) in enumerate(rows):
        a = Gtk.Label(label=k, xalign=0); a.get_style_context().add_class("lmg-sub")
        b = Gtk.Label(label=str(v), xalign=0, selectable=True, wrap=True, max_width_chars=60)
        g.attach(a, 0, i, 1, 1); g.attach(b, 1, i, 1, 1)
    return g

class Page(PageBase):
    def __init__(self, win=None):
        super().__init__(win)
        self.box.pack_start(heading(t("hw_title"), t("hw_sub")), False, False, 0)
        self.nb = Gtk.Notebook(); self.box.pack_start(self.nb, True, True, 0)
        self.loaded = False

    def on_show(self):
        if self.loaded: return
        self.loaded = True
        in_thread(self.collect, self.build)

    def collect(self):
        d = {}
        lscpu = {}
        for line in run(["lscpu"]).splitlines():
            if ":" in line:
                k, v = line.split(":", 1); lscpu.setdefault(k.strip(), v.strip())
        d["cpu"] = [("Model", lscpu.get("Model name", "-")), ("Vendor", lscpu.get("Vendor ID", "-")),
                    ("Architecture", lscpu.get("Architecture", "-")),
                    ("Cores / Threads", f"{psutil.cpu_count(logical=False)} / {psutil.cpu_count()}"),
                    ("Max MHz", lscpu.get("CPU max MHz", "-")), ("Min MHz", lscpu.get("CPU min MHz", "-")),
                    ("L2 cache", lscpu.get("L2 cache", "-")), ("L3 cache", lscpu.get("L3 cache", "-")),
                    ("Virtualization", lscpu.get("Virtualization", lscpu.get("Hypervisor vendor", "-"))),
                    ("Flags", (lscpu.get("Flags", "-")[:140] + "..."))]
        vm = psutil.virtual_memory(); sw = psutil.swap_memory()
        d["mem"] = [("Total RAM", human(vm.total)), ("Available", human(vm.available)), ("Swap", human(sw.total))]
        d["board"] = [("Vendor", dmi("board_vendor")), ("Board", dmi("board_name")), ("BIOS vendor", dmi("bios_vendor")),
                      ("BIOS version", dmi("bios_version")), ("BIOS date", dmi("bios_date")),
                      ("System", dmi("sys_vendor") + " " + dmi("product_name"))]
        gpus = [l.split(": ", 1)[-1] for l in run(["lspci"]).splitlines() if any(x in l for x in ("VGA", "3D controller", "Display controller"))]
        d["gpu"] = [(f"GPU {i+1}", g) for i, g in enumerate(gpus)] or [("GPU", "-")]
        rows = []
        try:
            j = json.loads(run(["lsblk", "-J", "-d", "-o", "NAME,MODEL,SIZE,ROTA,TYPE"]))
            for dev in j.get("blockdevices", []):
                if dev.get("type") == "disk":
                    rows.append((dev["name"], f"{dev.get('model') or '-'}  {dev.get('size')}  {'HDD' if str(dev.get('rota')) in ('1','True','true') else 'SSD/NVMe'}"))
        except Exception: pass
        d["disk"] = rows or [("Disk", "-")]
        osr = {}
        try:
            for l in open("/etc/os-release"):
                if "=" in l: k, v = l.strip().split("=", 1); osr[k] = v.strip('"')
        except Exception: pass
        d["sys"] = [("OS", osr.get("PRETTY_NAME", "LMG OS")), ("Kernel", platform.release()), ("Hostname", platform.node()),
                    ("Desktop", os.environ.get("XDG_CURRENT_DESKTOP", "XFCE")), ("Session", os.environ.get("XDG_SESSION_TYPE", "x11"))]
        net = []
        for n, a in psutil.net_if_addrs().items():
            ip = next((x.address for x in a if x.family.name == "AF_INET"), "-"); net.append((n, ip))
        d["net"] = net or [("-", "-")]
        temps = []
        try:
            for name, ents in (psutil.sensors_temperatures() or {}).items():
                for e in ents[:3]: temps.append((f"{name} {e.label}".strip(), f"{e.current:.0f} °C"))
        except Exception: pass
        bat = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
        if bat: temps.append(("Battery", f"{bat.percent:.0f}% {'(charging)' if bat.power_plugged else ''}"))
        d["sens"] = temps or [("Sensors", "-")]
        return d

    def build(self, d):
        if isinstance(d, Exception): return
        for key, label in (("cpu", t("cpu")), ("mem", t("memory")), ("board", t("mainboard")), ("gpu", t("gpu")),
                           ("disk", t("storage")), ("net", t("network")), ("sens", "Sensors"), ("sys", t("system"))):
            self.nb.append_page(kv_grid(d[key]), Gtk.Label(label=label))
        self.nb.show_all()
