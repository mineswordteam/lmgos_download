import os, signal
from lmgcommon import *
import psutil

class Page(PageBase):
    def __init__(self, win=None):
        super().__init__(win)
        self.box.pack_start(heading(t("ram_title"), t("ram_sub")), False, False, 0)
        self.bar = Gtk.LevelBar(min_value=0, max_value=1); self.bar.set_min_value(0); self.bar.set_max_value(1)
        self.lbl = Gtk.Label(xalign=0); self.swp = Gtk.Label(xalign=0)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        inner.pack_start(self.lbl, False, False, 0); inner.pack_start(self.bar, False, False, 0); inner.pack_start(self.swp, False, False, 0)
        fr = Gtk.Button(label=t("free_ram")); fr.set_halign(Gtk.Align.START)
        fr.connect("clicked", lambda *_: stream_cmd(admin_cmd("drop-caches"), lambda s: None, lambda rc: None))
        inner.pack_start(fr, False, False, 0)
        self.box.pack_start(card(inner), False, False, 0)

        l = Gtk.Label(label=t("apps"), xalign=0); l.get_style_context().add_class("lmg-title"); self.box.pack_start(l, False, False, 0)
        self.store = Gtk.ListStore(int, str, str, int)
        tv = Gtk.TreeView(model=self.store)
        for i, name in ((1, t("name")), (2, t("memory"))):
            r = Gtk.CellRendererText(); c = Gtk.TreeViewColumn(name, r, text=i); c.set_expand(i == 1); c.set_sort_column_id(3 if i == 2 else 1); tv.append_column(c)
        self.tv = tv
        sw = Gtk.ScrolledWindow(); sw.set_min_content_height(220); sw.add(tv); self.box.pack_start(sw, True, True, 0)
        end = Gtk.Button(label=t("end_task")); end.set_halign(Gtk.Align.START); end.get_style_context().add_class("destructive-action")
        end.connect("clicked", self.kill); self.box.pack_start(end, False, False, 0)

        l2 = Gtk.Label(label=t("startup"), xalign=0); l2.get_style_context().add_class("lmg-title"); self.box.pack_start(l2, False, False, 0)
        self.startup = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE); self.box.pack_start(self.startup, False, False, 0)
        self._src = 0; self.fill_startup()

    def on_show(self):
        self.refresh(); self._src = GLib.timeout_add_seconds(2, self.refresh)
    def on_hide(self):
        if self._src: GLib.source_remove(self._src); self._src = 0

    def refresh(self):
        vm = psutil.virtual_memory(); sw = psutil.swap_memory()
        self.lbl.set_text(f"{t('used')}: {human(vm.total - vm.available)} / {human(vm.total)}   |   {t('available')}: {human(vm.available)}")
        self.bar.set_value(vm.percent / 100.0)
        self.swp.set_text(f"{t('swap')}: {human(sw.used)} / {human(sw.total)}")
        rows = []
        for p in psutil.process_iter(["pid", "name", "memory_info", "username"]):
            try:
                if p.uids().real != os.getuid(): continue
                rss = p.info["memory_info"].rss
                lock = "\U0001F512 " if is_protected_proc(p.info["name"], " ".join(p.cmdline()), p.info["pid"]) else ""
                rows.append((p.info["pid"], lock + (p.info["name"] or ""), human(rss), rss))
            except Exception: pass
        rows.sort(key=lambda r: -r[3])
        sel = self.tv.get_selection().get_selected()[1]; selpid = self.store[sel][0] if sel else None
        self.store.clear()
        for r in rows[:40]: self.store.append(list(r))
        if selpid:
            for row in self.store:
                if row[0] == selpid: self.tv.get_selection().select_iter(row.iter)
        return True

    def kill(self, *_):
        m, it = self.tv.get_selection().get_selected()
        if it:
            try:
                p = psutil.Process(m[it][0])
                if is_protected_proc(p.name(), " ".join(p.cmdline()), p.pid):
                    d = Gtk.MessageDialog(transient_for=self.get_toplevel(), modal=True, message_type=Gtk.MessageType.INFO,
                                          buttons=Gtk.ButtonsType.OK, text=t("protected_msg")); d.run(); d.destroy(); return
                os.kill(p.pid, signal.SIGTERM)
            except Exception: pass

    def fill_startup(self):
        for ch in self.startup.get_children(): self.startup.remove(ch)
        seen = {}
        for d in ("/etc/xdg/autostart", os.path.expanduser("~/.config/autostart")):
            if not os.path.isdir(d): continue
            for fn in sorted(os.listdir(d)):
                if not fn.endswith(".desktop"): continue
                ent = {}
                try:
                    for line in open(os.path.join(d, fn), encoding="utf-8", errors="ignore"):
                        if "=" in line and not line.startswith("["):
                            k, v = line.strip().split("=", 1); ent.setdefault(k, v)
                except Exception: continue
                seen[fn] = (ent.get("Name", fn), ent.get("Hidden", "false") != "true" and ent.get("X-GNOME-Autostart-enabled", "true") != "false")
        for fn, (name, on) in sorted(seen.items(), key=lambda x: x[1][0].lower()):
            row = Gtk.ListBoxRow(); h = Gtk.Box(spacing=8); h.set_border_width(4)
            h.pack_start(Gtk.Label(label=name, xalign=0), True, True, 0)
            sw = Gtk.Switch(active=True if is_protected_autostart(fn) else on)
            if is_protected_autostart(fn):
                sw.set_sensitive(False); name = "\U0001F512 " + name
                h.get_children()[0].set_text(name)
            else:
                sw.connect("notify::active", self.toggle, fn)
            h.pack_end(sw, False, False, 0)
            row.add(h); self.startup.add(row)
        self.startup.show_all()

    def toggle(self, sw, _p, fn):
        if is_protected_autostart(fn): return
        dst = os.path.expanduser("~/.config/autostart"); os.makedirs(dst, exist_ok=True)
        src = "/etc/xdg/autostart/" + fn; mine = os.path.join(dst, fn)
        text = open(mine if os.path.exists(mine) else src, encoding="utf-8", errors="ignore").read() if (os.path.exists(mine) or os.path.exists(src)) else "[Desktop Entry]\nType=Application\n"
        lines = [l for l in text.splitlines() if not l.startswith("Hidden=")]
        lines.append("Hidden=" + ("false" if sw.get_active() else "true"))
        open(mine, "w").write("\n".join(lines) + "\n")
