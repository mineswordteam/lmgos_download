import json, os, time
from lmgcommon import *

STATE = "/run/lmg/update-state.json"
INFO = "/var/lib/lmg/update-info.json"
RESULT = "/var/lib/lmg/update-result.json"
LOG = "/var/log/lmg-update.log"
AUTO = "/var/lib/lmg/auto-download"


def jread(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def show_log(parent, title, text):
    """Separate window with the technical log (only ever opened on purpose, never inline)."""
    w = Gtk.Window(title=title, transient_for=parent)
    w.set_default_size(760, 460)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8); box.set_border_width(12); w.add(box)
    buf = Gtk.TextBuffer(); buf.set_text(text or "")
    tv = Gtk.TextView(buffer=buf, editable=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
    sw = Gtk.ScrolledWindow(); sw.add(tv); box.pack_start(sw, True, True, 0)
    b = Gtk.Button(label=t("close")); b.set_halign(Gtk.Align.END); b.connect("clicked", lambda *_: w.destroy())
    box.pack_start(b, False, False, 0)
    w.show_all()
    GLib.idle_add(lambda: tv.scroll_to_iter(buf.get_end_iter(), 0, False, 0, 0))
    return w


def read_log(n=400):
    try:
        with open(LOG, encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-n:])
    except Exception:
        return ""


class Page(PageBase):
    def __init__(self, win=None):
        super().__init__(win)
        self._busy = False
        self._timer = 0
        self.box.pack_start(heading(t("update_title"), t("update_sub")), False, False, 0)

        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.status = Gtk.Label(label="", xalign=0, wrap=True); self.status.get_style_context().add_class("lmg-title")
        self.size = Gtk.Label(label="", xalign=0, wrap=True); self.size.get_style_context().add_class("lmg-sub")
        self.bar = Gtk.ProgressBar(show_text=True); self.bar.set_no_show_all(True)
        inner.pack_start(self.status, False, False, 0)
        inner.pack_start(self.size, False, False, 0)
        inner.pack_start(self.bar, False, False, 0)
        row = Gtk.Box(spacing=8)
        self.btn_check = Gtk.Button(label=t("upd_check")); self.btn_check.connect("clicked", self.check)
        self.btn_dl = Gtk.Button(label=t("upd_download")); self.btn_dl.get_style_context().add_class("suggested-action")
        self.btn_dl.connect("clicked", self.download); self.btn_dl.set_no_show_all(True)
        self.btn_inst = Gtk.Button(label=t("upd_restart_btn")); self.btn_inst.get_style_context().add_class("suggested-action")
        self.btn_inst.connect("clicked", self.ask_install); self.btn_inst.set_no_show_all(True)
        self.btn_log = Gtk.Button(label=t("upd_show_log")); self.btn_log.connect("clicked", self.open_log); self.btn_log.set_no_show_all(True)
        for b in (self.btn_check, self.btn_dl, self.btn_inst, self.btn_log):
            row.pack_start(b, False, False, 0)
        inner.pack_start(row, False, False, 0)
        self.box.pack_start(card(inner), False, False, 0)

        ainner = Gtk.Box(spacing=12)
        self.auto = Gtk.Switch(); self.auto.set_valign(Gtk.Align.CENTER)
        self.auto.set_active(self._auto_on()); self.auto.connect("state-set", self.auto_toggled)
        al = Gtk.Label(label=t("upd_auto"), xalign=0, wrap=True)
        ainner.pack_start(self.auto, False, False, 0); ainner.pack_start(al, True, True, 0)
        self.box.pack_start(card(ainner), False, False, 0)

        self.box.pack_start(Gtk.Separator(), False, False, 6)
        self.box.pack_start(heading(t("rb_title")), False, False, 0)
        w = Gtk.Label(label=t("rb_warn"), xalign=0, wrap=True); w.get_style_context().add_class("lmg-warn")
        self.box.pack_start(w, False, False, 0)
        self.rb = Gtk.Button(label=t("rb_btn")); self.rb.set_halign(Gtk.Align.START); self.rb.connect("clicked", self.ask_rollback)
        self.rbl = Gtk.Label(label="", xalign=0)
        self.box.pack_start(self.rb, False, False, 0); self.box.pack_start(self.rbl, False, False, 0)
        self.refresh()

    # ---------------------------------------------------------------- state
    def _auto_on(self):
        try:
            return open(AUTO).read().strip() == "1"
        except Exception:
            return False

    def on_show(self):
        self.refresh()
        if not self._timer:
            self._timer = GLib.timeout_add(1000, self._tick)

    def on_hide(self):
        if self._timer:
            GLib.source_remove(self._timer); self._timer = 0

    def _tick(self):
        self.refresh(); return True

    def refresh(self):
        st, info = jread(STATE), jread(INFO)
        phase = st.get("phase", "idle")
        count = int(info.get("count") or 0)
        total, remaining = int(info.get("total") or 0), int(info.get("remaining") or 0)
        downloaded = bool(info.get("downloaded"))
        live = is_live()
        show_dl = show_inst = show_log = False
        bar = None
        if live:
            self.status.set_text(t("upd_live")); self.size.set_text("")
        elif phase == "checking" or (self._busy and phase not in ("downloading",)):
            self.status.set_text(t("upd_checking")); self.size.set_text("")
        elif phase == "downloading":
            pct = float(st.get("percent") or 0)
            self.status.set_text(t("upd_downloading"))
            self.size.set_text(f"{count} {t('upd_count')} · {human(total or remaining)}")
            bar = pct
        elif phase == "error" and st.get("error") == "download":
            self.status.set_text(t("upd_dl_failed")); self.size.set_text(t("upd_dl_failed_d")); show_dl = count > 0; show_log = True
        elif info.get("error") == "offline" and not count:
            self.status.set_text(t("upd_offline")); self.size.set_text(t("upd_offline_d"))
        elif count and downloaded:
            self.status.set_text(f"{count} {t('upd_ready')}")
            self.size.set_text(f"{human(total)}"); show_inst = True
        elif count:
            self.status.set_text(f"{count} {t('upd_available')}")
            self.size.set_text(f"{t('upd_size')}: {human(remaining or total)}"); show_dl = True
        elif info.get("checked"):
            self.status.set_text(t("upd_none"))
            self.size.set_text(t("upd_last") + " " + time.strftime("%Y-%m-%d %H:%M", time.localtime(info["checked"])))
        else:
            self.status.set_text(t("upd_unknown")); self.size.set_text("")
        res = jread(RESULT)
        if res and not res.get("ok") and not live and phase != "downloading":
            show_log = True
        if bar is None:
            self.bar.hide()
        else:
            self.bar.set_fraction(max(0.0, min(1.0, bar / 100.0))); self.bar.set_text(f"{int(bar)}%"); self.bar.show()
        for b, v in ((self.btn_dl, show_dl), (self.btn_inst, show_inst), (self.btn_log, show_log)):
            b.set_visible(v)
        self.btn_check.set_sensitive(not live and phase not in ("checking", "downloading") and not self._busy)
        self.btn_dl.set_sensitive(phase != "downloading")
        ok = os.path.exists("/var/lib/lmg/rollback/ready")
        self.rb.set_sensitive(ok and not live); self.rbl.set_text("" if ok else t("rb_disabled"))

    # ---------------------------------------------------------------- actions
    def check(self, *_):
        self._busy = True; self.refresh()
        def done(rc):
            self._busy = False; self.refresh()
        stream_cmd(admin_cmd("update-check"), lambda s: None, done)

    def download(self, *_):
        stream_cmd(admin_cmd("update-download"), lambda s: None, lambda rc: self.refresh())

    def auto_toggled(self, sw, state):
        stream_cmd(admin_cmd("auto-download", "on" if state else "off"), lambda s: None, lambda rc: None)
        return False

    def _dialog(self, text, yes):
        d = Gtk.MessageDialog(transient_for=self.get_toplevel(), modal=True, message_type=Gtk.MessageType.WARNING, text=text)
        d.add_button(t("upd_later"), Gtk.ResponseType.CANCEL); d.add_button(yes, Gtk.ResponseType.OK)
        play_sound("permission")
        r = d.run(); d.destroy(); return r == Gtk.ResponseType.OK

    def ask_install(self, *_):
        if self._dialog(t("upd_ask_body"), t("upd_restart_btn")):
            self.btn_inst.set_sensitive(False); self.status.set_text(t("upd_preparing"))
            self._out = []
            stream_cmd(admin_cmd("update-apply"), lambda s: self._out.append(s), self.applied)

    def applied(self, rc):
        self.btn_inst.set_sensitive(True)
        if rc != 0:
            self.status.set_text(t("failed")); self.size.set_text("\n".join(self._out[-3:]))

    def ask_rollback(self, *_):
        if self._dialog(t("rb_warn") + "\n\n" + t("rb_confirm"), t("rb_yes")):
            self._out = []
            stream_cmd(admin_cmd("rollback-apply"), lambda s: self._out.append(s), self.applied)

    def open_log(self, *_):
        res = jread(RESULT)
        text = (res.get("message", "") + "\n\n" if res.get("message") else "") + (read_log() or res.get("log_tail", ""))
        show_log(self.get_toplevel(), t("upd_log_title"), text)
