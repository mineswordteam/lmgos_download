import os, signal
from lmgcommon import *
import psutil


class Page(PageBase):
    """LMG Task Manager: every program of the user with CPU and memory. System parts are locked (cannot be ended)."""
    def __init__(self, win=None):
        super().__init__(win)
        self.procs = {}
        self._src = 0
        self.box.pack_start(heading(t("taskmgr_title"), t("taskmgr_sub")), False, False, 0)
        self.sum = Gtk.Label(label="", xalign=0); self.sum.get_style_context().add_class("lmg-sub")
        self.box.pack_start(self.sum, False, False, 0)
        # pid, name, cpu text, mem text, cpu num, mem num, locked
        self.store = Gtk.ListStore(int, str, str, str, float, int, bool)
        tv = Gtk.TreeView(model=self.store); self.tv = tv
        for i, (title, col) in enumerate(((t("name"), 1), ("CPU", 2), (t("memory"), 3))):
            r = Gtk.CellRendererText(); c = Gtk.TreeViewColumn(title, r, text=col); c.set_expand(col == 1)
            c.set_sort_column_id({1: 1, 2: 4, 3: 5}[col]); tv.append_column(c)
        self.store.set_sort_column_id(4, Gtk.SortType.DESCENDING)
        sw = Gtk.ScrolledWindow(); sw.set_min_content_height(380); sw.add(tv)
        self.box.pack_start(sw, True, True, 0)
        row = Gtk.Box(spacing=8)
        self.end = Gtk.Button(label=t("end_task")); self.end.get_style_context().add_class("destructive-action")
        self.end.connect("clicked", self.kill); row.pack_start(self.end, False, False, 0)
        self.note = Gtk.Label(label="", xalign=0); row.pack_start(self.note, True, True, 0)
        self.box.pack_start(row, False, False, 0)
        tv.get_selection().connect("changed", self.sel)
        self.end.set_sensitive(False)

    def on_show(self):
        self.refresh(); self._src = GLib.timeout_add_seconds(2, self.refresh)

    def on_hide(self):
        if self._src: GLib.source_remove(self._src); self._src = 0

    def sel(self, s):
        m, it = s.get_selected()
        locked = bool(it and m[it][6])
        self.end.set_sensitive(bool(it) and not locked)
        self.note.set_text(t("protected_msg") if locked else "")

    def refresh(self):
        cores = psutil.cpu_count() or 1
        vm = psutil.virtual_memory()
        self.sum.set_text(f"CPU {psutil.cpu_percent():.0f}%   |   {t('used')}: {human(vm.total - vm.available)} / {human(vm.total)}")
        uid = os.getuid(); seen = set(); rows = []
        for p in psutil.process_iter(["pid", "name", "memory_info"]):
            try:
                if p.uids().real != uid: continue
                pid = p.info["pid"]; seen.add(pid)
                if pid not in self.procs: self.procs[pid] = p; p.cpu_percent(None)
                cpu = self.procs[pid].cpu_percent(None) / cores
                rss = p.info["memory_info"].rss
                locked = is_protected_proc(p.info["name"], " ".join(p.cmdline()), pid)
                rows.append((pid, ("\U0001F512 " if locked else "") + (p.info["name"] or ""), f"{cpu:.0f}%", human(rss), cpu, rss, locked))
            except Exception: pass
        for pid in list(self.procs):
            if pid not in seen: del self.procs[pid]
        m, it = self.tv.get_selection().get_selected(); selpid = m[it][0] if it else None
        self.store.clear()
        for r in rows: self.store.append(list(r))
        if selpid:
            for row in self.store:
                if row[0] == selpid: self.tv.get_selection().select_iter(row.iter)
        return True

    def kill(self, *_):
        m, it = self.tv.get_selection().get_selected()
        if not it or m[it][6]: return
        try: os.kill(m[it][0], signal.SIGTERM)
        except Exception: pass
