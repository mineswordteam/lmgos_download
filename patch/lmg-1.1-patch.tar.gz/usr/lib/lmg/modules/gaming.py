import os, psutil, signal
from lmgcommon import *

PROTECTED = ["xfdesktop", "xfwm4", "xfce4", "xfsettingsd", "xfconf", "whisker", "/usr/lib/lmg/", "lmg-", "picom",
             "thunar --daemon", "tumbler", "nm-applet", "lxpolkit", "polkit", "pipewire", "wireplumber", "pulse", "dbus",
             "notifyd", "xdg-desktop-portal", "at-spi", "gvfs", "ibus", "fcitx", "light-locker", "blueman"]


class Page(PageBase):
    def __init__(self, win=None):
        super().__init__(win)
        self.s = load_settings()
        self.box.pack_start(heading(t("gaming_title"), t("gaming_sub")), False, False, 0)
        self.status = Gtk.Label(label="", xalign=0); self.status.get_style_context().add_class("lmg-title")
        self.sw = Gtk.Switch(); self.sw.set_halign(Gtk.Align.START)
        self._busy = False
        self.sw.connect("state-set", self.toggled)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        inner.pack_start(self.status, False, False, 0); inner.pack_start(self.sw, False, False, 0)
        self.box.pack_start(card(inner), False, False, 0)
        self.info = Gtk.Label(label="", xalign=0, wrap=True); self.info.get_style_context().add_class("lmg-sub")
        self.box.pack_start(self.info, False, False, 0)
        # run a program with gamemode (CPU/GPU boost for that program) and an optional FPS overlay (MangoHud)
        g = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        hl = Gtk.Label(label=t("gaming_run_title"), xalign=0); hl.get_style_context().add_class("lmg-title"); g.pack_start(hl, False, False, 0)
        sub = Gtk.Label(label=t("gaming_run_sub"), xalign=0, wrap=True); sub.get_style_context().add_class("lmg-sub"); g.pack_start(sub, False, False, 0)
        r = Gtk.Box(spacing=12); r.pack_start(Gtk.Label(label=t("gaming_fps"), xalign=0), True, True, 0)
        self.fps = Gtk.Switch(active=bool(self.s.get("gaming_fps", False))); self.fps.connect("notify::active", self._fps); r.pack_end(self.fps, False, False, 0)
        g.pack_start(r, False, False, 0)
        pick = Gtk.Button(label=t("gaming_run_pick")); pick.connect("clicked", self.run_program); g.pack_start(pick, False, False, 0)
        self.box.pack_start(card(g), False, False, 0)
        self.refresh_state()

    def _fps(self, w, _p):
        self.s["gaming_fps"] = w.get_active(); save_settings(self.s)

    def run_program(self, *_):
        d = Gtk.FileChooserNative(title=t("gaming_run_pick"), action=Gtk.FileChooserAction.OPEN, transient_for=self.get_toplevel())
        if d.run() == Gtk.ResponseType.ACCEPT:
            path = d.get_filename(); cmd = [path]
            if path.lower().endswith(".exe"): cmd = ["lmg-wine-run", path]
            if self.fps.get_active() and os.path.exists("/usr/bin/mangohud"): cmd = ["mangohud"] + cmd
            if os.path.exists("/usr/bin/gamemoderun"): cmd = ["gamemoderun"] + cmd
            spawn(cmd)

    def refresh_state(self):
        def done(res):
            on = (res == "on"); self._busy = True; self.sw.set_active(on); self._busy = False
            self.status.set_text(t("gaming_active") if on else t("gaming_inactive"))
        in_thread(lambda: run(admin_cmd("gaming-state")) if False else ("on" if os.path.exists("/run/lmg/gaming-state.json") else "off"), done)

    def candidates(self):
        wl = [w.lower() for w in self.s.get("gaming_whitelist", [])]
        me = os.getpid(); out = []
        wins = run(["wmctrl", "-lp"]).splitlines()
        pids = set()
        for l in wins:
            parts = l.split(None, 4)
            if len(parts) > 2 and parts[2].isdigit(): pids.add(int(parts[2]))
        for pid in pids:
            try:
                p = psutil.Process(pid)
                if p.uids().real != os.getuid() or pid == me: continue
                name = p.name()
                cmd = " ".join(p.cmdline()).lower()
                if any(w in name.lower() for w in wl): continue
                # the desktop itself (background, panel, sidebar, menus) and every LMG program is never closed
                if any(w in (name.lower() + " " + cmd) for w in PROTECTED): continue
                out.append((pid, name))
            except Exception: pass
        return out

    def toggled(self, sw, state):
        if self._busy: return False
        if state:
            apps = self.candidates()
            msg = t("gaming_close_list") + "\n" + ("\n".join(n for _, n in apps) if apps else t("gaming_none"))
            if not confirm(self.get_toplevel(), t("gaming_on") + "?", msg):
                GLib.idle_add(self.refresh_state); return True
            for pid, _ in apps:
                try: os.kill(pid, signal.SIGTERM)
                except Exception: pass
            stream_cmd(admin_cmd("gaming-on"), self._log, lambda rc: self.refresh_state())
            spawn(["lmg-session-apply", "gaming"])
        else:
            stream_cmd(admin_cmd("gaming-off"), self._log, lambda rc: self.refresh_state())
            spawn(["lmg-session-apply", "ensure"])
        return False
    def _log(self, s): self.info.set_text(s)
