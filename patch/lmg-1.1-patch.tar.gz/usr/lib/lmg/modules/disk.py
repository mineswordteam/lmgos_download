import os, shutil, time
from lmgcommon import *
import psutil

def dir_size(path):
    total = 0
    for root, dirs, files in os.walk(path, onerror=lambda e: None):
        for f in files:
            try: total += os.lstat(os.path.join(root, f)).st_size
            except Exception: pass
    return total

class Page(PageBase):
    def __init__(self, win=None):
        super().__init__(win)
        self.box.pack_start(heading(t("disk_title"), t("disk_sub")), False, False, 0)
        self.usage = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6); self.box.pack_start(card(self.usage), False, False, 0)
        self.fill_usage()
        sc = Gtk.Button(label=t("scan")); sc.set_halign(Gtk.Align.START); sc.connect("clicked", self.scan); self.box.pack_start(sc, False, False, 0)
        self.items = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); self.box.pack_start(self.items, False, False, 0)
        self.cb = Gtk.Button(label=t("clean_btn")); self.cb.set_halign(Gtk.Align.START); self.cb.get_style_context().add_class("destructive-action")
        self.cb.connect("clicked", self.clean); self.cb.set_sensitive(False); self.box.pack_start(self.cb, False, False, 0)
        self.checks = []
        self.box.pack_start(Gtk.Separator(), False, False, 6)
        self.sp = Gtk.Button(label=t("speed_btn")); self.sp.set_halign(Gtk.Align.START); self.sp.connect("clicked", self.speed)
        self.box.pack_start(self.sp, False, False, 0)
        self.spl = Gtk.Label(label="", xalign=0); self.box.pack_start(self.spl, False, False, 0)

    def fill_usage(self):
        for p in psutil.disk_partitions():
            if p.fstype in ("squashfs", "tmpfs", "devtmpfs", "overlay") and p.mountpoint not in ("/",): continue
            try: u = psutil.disk_usage(p.mountpoint)
            except Exception: continue
            self.usage.pack_start(Gtk.Label(label=f"{p.mountpoint}  -  {human(u.used)} / {human(u.total)}", xalign=0), False, False, 0)
            lb = Gtk.LevelBar(min_value=0, max_value=1); lb.set_value(u.percent / 100); self.usage.pack_start(lb, False, False, 0)

    def targets(self):
        home = os.path.expanduser("~")
        return [("Package cache (apt)", "/var/cache/apt/archives", "apt"), ("System logs (journal)", "/var/log/journal", "journal"),
                ("User cache", home + "/.cache", "path"), ("Trash", home + "/.local/share/Trash", "path"),
                ("Thumbnails", home + "/.cache/thumbnails", "path")]

    def scan(self, *_):
        for ch in self.items.get_children(): self.items.remove(ch)
        self.checks = []
        def work(): return [(n, p, k, dir_size(p) if os.path.exists(p) else 0) for n, p, k in self.targets()]
        def done(res):
            seen = set()
            for n, p, k, sz in res:
                if p in seen or (n == "Thumbnails"): continue
                seen.add(p); c = Gtk.CheckButton(label=f"{n}   ({human(sz)})"); c.set_active(sz > 0); c._t = (p, k); self.items.pack_start(c, False, False, 0); self.checks.append(c)
            self.items.show_all(); self.cb.set_sensitive(True)
        in_thread(work, done)

    def clean(self, *_):
        chosen = [c._t for c in self.checks if c.get_active()]
        if not chosen or not confirm(self.get_toplevel(), t("clean_confirm"), t("clean_detail") + "\n\n" + "\n".join(p for p, _ in chosen)): return
        for p, k in chosen:
            if k == "apt": stream_cmd(admin_cmd("clean-apt"), lambda s: None, lambda rc: None)
            elif k == "journal": stream_cmd(admin_cmd("clean-journal"), lambda s: None, lambda rc: None)
            else:
                for e in os.listdir(p) if os.path.isdir(p) else []:
                    fp = os.path.join(p, e)
                    try: shutil.rmtree(fp) if os.path.isdir(fp) and not os.path.islink(fp) else os.remove(fp)
                    except Exception: pass
        GLib.timeout_add(1500, lambda: (self.scan(), False)[1])

    def speed(self, *_):
        self.sp.set_sensitive(False); self.spl.set_text(t("running"))
        def work():
            path = os.path.expanduser("~/.lmg-speedtest.tmp"); size = 256 * 1024 * 1024; chunk = os.urandom(1024 * 1024)
            t0 = time.time()
            with open(path, "wb") as f:
                for _ in range(size // len(chunk)): f.write(chunk)
                f.flush(); os.fsync(f.fileno())
            w = size / (time.time() - t0)
            try:
                fd = os.open(path, os.O_RDONLY); os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED); os.close(fd)
            except Exception: pass
            t1 = time.time()
            with open(path, "rb") as f:
                while f.read(1024 * 1024): pass
            r = size / (time.time() - t1)
            try: os.remove(path)
            except Exception: pass
            return w, r
        def done(res):
            self.sp.set_sensitive(True)
            if isinstance(res, Exception): self.spl.set_text(t("failed")); return
            self.spl.set_text(f"{t('write')}: {human(res[0])}/s     {t('read')}: {human(res[1])}/s")
        in_thread(work, done)
