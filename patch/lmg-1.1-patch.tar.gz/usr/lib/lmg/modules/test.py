import os, shutil
from lmgcommon import *
import psutil

class Page(PageBase):
    def __init__(self, win=None):
        super().__init__(win)
        self.box.pack_start(heading(t("test_title"), t("test_sub")), False, False, 0)
        self.btn = Gtk.Button(label=t("test_btn")); self.btn.get_style_context().add_class("suggested-action")
        self.btn.set_halign(Gtk.Align.START); self.btn.connect("clicked", self.go); self.box.pack_start(self.btn, False, False, 0)
        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE); self.box.pack_start(self.list, False, False, 0)

    def checks(self):
        out = []
        def add(name, status, detail): out.append((name, status, detail))
        fw = run(["systemctl", "is-active", "ufw"]); add("Firewall (ufw)", "ok" if fw == "active" else "warn", fw or "unknown")
        aa = (open("/sys/module/apparmor/parameters/enabled").read().strip() if os.path.exists("/sys/module/apparmor/parameters/enabled") else "N")
        add("AppArmor", "ok" if aa == "Y" else "warn", "enabled" if aa == "Y" else "not enabled")
        failed = [l for l in run(["systemctl", "--failed", "--no-legend", "--plain"]).splitlines() if l.strip()]
        add("System services", "ok" if not failed else "bad", "all running" if not failed else f"{len(failed)} failed: " + failed[0].split()[0])
        du = shutil.disk_usage("/"); pct = du.used / du.total * 100
        add("Disk space (/)", "ok" if pct < 85 else ("warn" if pct < 95 else "bad"), f"{pct:.0f}% used, {human(du.free)} free")
        vm = psutil.virtual_memory(); add("Memory", "ok" if vm.percent < 85 else "warn", f"{vm.percent:.0f}% used")
        nm = run(["nmcli", "-t", "-f", "STATE", "general"]); add("Network", "ok" if nm.startswith("connected") else "warn", nm or "unknown")
        up = [l for l in run("apt list --upgradable 2>/dev/null", shell=True, timeout=30).splitlines() if "/" in l]
        add("Updates", "ok" if not up else "warn", "up to date" if not up else f"{len(up)} packages can be upgraded")
        ts = run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"]); add("Clock sync", "ok" if ts == "yes" else "warn", ts or "unknown")
        try:
            temps = [e.current for ents in (psutil.sensors_temperatures() or {}).values() for e in ents]
            if temps: add("Temperature", "ok" if max(temps) < 80 else "bad", f"max {max(temps):.0f} °C")
        except Exception: pass
        return out

    def go(self, *_):
        self.btn.set_sensitive(False)
        for ch in self.list.get_children(): self.list.remove(ch)
        in_thread(self.checks, self.show)

    def show(self, res):
        self.btn.set_sensitive(True)
        if isinstance(res, Exception): return
        sym = {"ok": ("✔", "lmg-good"), "warn": ("▲", "lmg-warn"), "bad": ("✖", "lmg-bad")}
        for name, st, detail in res:
            row = Gtk.ListBoxRow(); h = Gtk.Box(spacing=12); h.set_border_width(8)
            s = Gtk.Label(label=sym[st][0]); s.get_style_context().add_class(sym[st][1])
            h.pack_start(s, False, False, 0); h.pack_start(Gtk.Label(label=name, xalign=0), True, True, 0)
            d = Gtk.Label(label=detail, xalign=1); d.get_style_context().add_class("lmg-sub"); h.pack_end(d, False, False, 0)
            row.add(h); self.list.add(row)
        self.list.show_all()
