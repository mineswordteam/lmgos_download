from lmgcommon import *

class Page(PageBase):
    def __init__(self, win=None):
        super().__init__(win)
        top = Gtk.Box(spacing=16)
        try:
            from gi.repository import GdkPixbuf
            pb = GdkPixbuf.Pixbuf.new_from_file_at_size(SHARE + "/branding/logo-main.png", 96, 96)
            self.logo = Gtk.Image.new_from_pixbuf(pb); top.pack_start(self.logo, False, False, 0)
        except Exception:
            pass
        top.pack_start(heading(t("welcome_title"), t("welcome_sub")), True, True, 0)
        self.box.pack_start(top, False, False, 0)

        if is_live():
            note = Gtk.Label(label=t("live_note"), xalign=0, wrap=True); note.get_style_context().add_class("lmg-warn")
            self.box.pack_start(note, False, False, 0)
            b = Gtk.Button(label=t("install_btn")); b.get_style_context().add_class("suggested-action")
            b.connect("clicked", lambda *_: spawn(["lmg-install"])); b.set_halign(Gtk.Align.START)
            self.box.pack_start(b, False, False, 0)

        self.upd_box = Gtk.Box(spacing=12); self.upd_box.get_style_context().add_class("lmg-card")
        self.upd_lbl = Gtk.Label(label="", xalign=0, wrap=True); self.upd_lbl.get_style_context().add_class("lmg-title")
        ub = Gtk.Button(label=t("upd_open")); ub.get_style_context().add_class("suggested-action")
        ub.connect("clicked", lambda *_: win and win.show_page("update"))
        self.upd_box.pack_start(self.upd_lbl, True, True, 0); self.upd_box.pack_start(ub, False, False, 0)
        self.upd_box.set_no_show_all(True)
        self.box.pack_start(self.upd_box, False, False, 0)
        self.revealers = []
        grid = Gtk.Grid(column_spacing=12, row_spacing=12, column_homogeneous=True)
        feats = [("feat_light", "feat_light_d"), ("feat_secure", "feat_secure_d"), ("feat_apps", "feat_apps_d"),
                 ("feat_neon", "feat_neon_d"), ("feat_tools", "feat_tools_d")]
        for i, (a, d) in enumerate(feats):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            h = Gtk.Label(label=t(a), xalign=0); h.get_style_context().add_class("lmg-title")
            x = Gtk.Label(label=t(d), xalign=0, wrap=True, max_width_chars=34); x.get_style_context().add_class("lmg-sub")
            inner.pack_start(h, False, False, 0); inner.pack_start(x, False, False, 0)
            rv = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_UP, transition_duration=320, reveal_child=False)
            rv.add(card(inner)); self.revealers.append(rv)
            grid.attach(rv, i % 2, i // 2, 1, 1)
        self.box.pack_start(grid, False, False, 0)
        tb = Gtk.Button(label=t("start_tutorial")); tb.get_style_context().add_class("suggested-action"); tb.set_halign(Gtk.Align.START); tb.connect("clicked", lambda *_: spawn(["lmg-tutorial"])); self.box.pack_start(tb, False, False, 0)
        s = Gtk.Button(label=t("open_settings")); s.set_halign(Gtk.Align.START)
        s.connect("clicked", lambda *_: win and win.show_page("settings"))
        self.box.pack_start(s, False, False, 0)

        tm = Gtk.Label(label=f"{TEAM}  ·  LMG OS {VERSION}", xalign=0); tm.get_style_context().add_class("lmg-team")
        self.box.pack_start(tm, False, False, 0)

    def _update_banner(self):
        try:
            import json
            i = json.load(open("/var/lib/lmg/update-info.json"))
        except Exception:
            i = {}
        n = int(i.get("count") or 0)
        if n and not is_live():
            size = human(i.get("remaining") or i.get("total") or 0)
            key = "upd_banner_ready" if i.get("downloaded") else "upd_banner_new"
            self.upd_lbl.set_text(f"{t(key)}  ·  {n} {t('upd_count')}  ·  {size}")
            self.upd_box.show_all()
        else:
            self.upd_box.hide()

    def on_show(self):
        self._update_banner()
        for i, rv in enumerate(getattr(self, "revealers", [])):
            rv.set_reveal_child(False)
            GLib.timeout_add(120 + i * 110, lambda r=rv: (r.set_reveal_child(True), False)[1])
        if load_settings().get("light_mode") or not hasattr(self, "logo"): return
        import math
        self._ph = 0.0
        def pulse():
            self._ph += 0.12; self.logo.set_opacity(0.78 + 0.22 * math.sin(self._ph)); return True
        if getattr(self, "_src", 0): GLib.source_remove(self._src)
        self._src = GLib.timeout_add(80, pulse)

    def on_hide(self):
        if getattr(self, "_src", 0): GLib.source_remove(self._src); self._src = 0
