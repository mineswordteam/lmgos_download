import json
import os, subprocess
from lmgcommon import *

class Page(PageBase):
    SECTIONS = ["appearance", "sidebar", "startup", "keyboard", "tools"]

    def __init__(self, win=None, section=None):
        super().__init__(win)
        self.s = load_settings(); self.section = section
        if section is None: self.box.pack_start(heading(t("set_title"), t("set_sub")), False, False, 0)

        # appearance
        a = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        a.pack_start(self._h(t("appearance")), False, False, 0)
        lm = Gtk.Switch(active=bool(self.s.get("light_mode"))); lm.connect("notify::active", self.on_light)
        a.pack_start(self._row(t("light_mode"), lm), False, False, 0)
        fa = Gtk.Switch(active=bool(self.s.get("fancy_animations"))); fa.connect("notify::active", self.on_fancy)
        a.pack_start(self._row(t("fancy_animations"), fa), False, False, 0)
        fn = Gtk.Label(label=t("fancy_note"), xalign=0, wrap=True); fn.get_style_context().add_class("lmg-sub"); a.pack_start(fn, False, False, 0)
        sn = Gtk.Switch(active=bool(self.s.get("sound_enabled", True))); sn.connect("notify::active", lambda w, _p: self.set("sound_enabled", w.get_active()))
        a.pack_start(self._row(t("sound_enabled"), sn), False, False, 0)
        try: ug = json.load(open("/var/lib/lmg/usb-guard.json"))
        except Exception: ug = {}
        gs = Gtk.Switch(active=bool(ug.get("guard", False)))
        gs.connect("notify::active", lambda w, _p: stream_cmd(admin_cmd("usb-config", "guard", "on" if w.get_active() else "off"), lambda s: None, lambda rc: None))
        a.pack_start(self._row(t("usb_guard_set"), gs), False, False, 0)
        ps = Gtk.Switch(active=bool(ug.get("panic_reboot", True)))
        ps.connect("notify::active", lambda w, _p: stream_cmd(admin_cmd("usb-config", "panic", "on" if w.get_active() else "off"), lambda s: None, lambda rc: None))
        a.pack_start(self._row(t("usb_panic_set"), ps), False, False, 0)
        wp = Gtk.Button(label=t("choose")); wp.connect("clicked", self.pick_wall)
        a.pack_start(self._row(t("wallpaper"), wp), False, False, 0)
        self.lang = Gtk.ComboBoxText()
        for code, name in (("auto", "Auto"), ("en", "English"), ("fa", "فارسی")): self.lang.append(code, name)
        self.lang.set_active_id(self.s.get("language", "auto")); self.lang.connect("changed", self.on_lang)
        a.pack_start(self._row(t("language"), self.lang), False, False, 0)
        n = Gtk.Label(label=t("restart_note"), xalign=0); n.get_style_context().add_class("lmg-sub"); a.pack_start(n, False, False, 0)
        self._add("appearance", card(a))

        # sidebar
        sb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        sb.pack_start(self._h(t("sidebar")), False, False, 0)
        en = Gtk.Switch(active=bool(self.s.get("sidebar_enabled", True))); en.connect("notify::active", lambda w, _p: self.set("sidebar_enabled", w.get_active()))
        sb.pack_start(self._row(t("sidebar_enabled"), en), False, False, 0)
        pin = Gtk.Switch(active=bool(self.s.get("sidebar_pinned"))); pin.connect("notify::active", lambda w, _p: self.set("sidebar_pinned", w.get_active()))
        sb.pack_start(self._row(t("sidebar_pin"), pin), False, False, 0)
        dock = Gtk.Switch(active=self.s.get("sidebar_mode") == "dock"); dock.connect("notify::active", lambda w, _p: self.set("sidebar_mode", "dock" if w.get_active() else "overlay"))
        sb.pack_start(self._row(t("sidebar_dock"), dock), False, False, 0)
        self._add("sidebar", card(sb))

        # fast boot
        fb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        fb.pack_start(self._h(t("fb_title")), False, False, 0)
        self.fbsw = Gtk.Switch(active=os.path.exists("/var/lib/lmg/fastboot")); self._fb_busy = False
        self.fbsw.connect("notify::active", self.on_fastboot)
        fb.pack_start(self._row(t("fb_switch"), self.fbsw), False, False, 0)
        for key, cls in (("fb_note", "lmg-sub"), ("fb_warn", "lmg-warn")):
            l = Gtk.Label(label=t(key), xalign=0, wrap=True); l.get_style_context().add_class(cls); fb.pack_start(l, False, False, 0)
        self.fbl = Gtk.Label(label="", xalign=0, wrap=True); fb.pack_start(self.fbl, False, False, 0)
        self._add("startup", card(fb))

        # automatic login (installed system only)
        al = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        al.pack_start(self._h(t("al_title")), False, False, 0)
        live = os.path.exists("/run/live/medium")
        self.alsw = Gtk.Switch(active=os.path.exists("/var/lib/lmg/allow-autologin"), sensitive=not live); self._al_busy = False
        self.alsw.connect("notify::active", self.on_autologin)
        al.pack_start(self._row(t("al_switch"), self.alsw), False, False, 0)
        for key, cls in (("al_note", "lmg-sub"), ("al_warn", "lmg-warn")):
            l = Gtk.Label(label=t(key), xalign=0, wrap=True); l.get_style_context().add_class(cls); al.pack_start(l, False, False, 0)
        if live:
            l = Gtk.Label(label=t("al_live"), xalign=0, wrap=True); l.get_style_context().add_class("lmg-sub"); al.pack_start(l, False, False, 0)
        self._add("startup", card(al))

        # keyboard
        k = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        k.pack_start(self._h(t("keyboard")), False, False, 0)
        self.kb = Gtk.Entry(text=self._cur_layouts()); self.kb.set_width_chars(14)
        ap = Gtk.Button(label=t("apply")); ap.connect("clicked", self.apply_kb)
        h = Gtk.Box(spacing=8); h.pack_start(self.kb, False, False, 0); h.pack_start(ap, False, False, 0)
        k.pack_start(h, False, False, 0)
        hint = Gtk.Label(label=t("layouts_hint") + "  (Alt+Shift)", xalign=0); hint.get_style_context().add_class("lmg-sub"); k.pack_start(hint, False, False, 0)
        self._add("keyboard", card(k))

        # tools
        tl = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        tl.pack_start(self._h(t("system_tools")), False, False, 0)
        fl = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=3, column_spacing=8, row_spacing=8)
        for label, cmd in ((t("sound"), ["pavucontrol"]), (t("net"), ["nm-connection-editor"]), (t("display"), ["xfce4-display-settings"]),
                           (t("power"), ["xfce4-power-manager-settings"]), (t("apps_default"), ["xfce4-mime-settings"]),
                           (t("install_bottles"), ["xfce4-terminal", "-e", "bash -c 'flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo; flatpak install -y flathub com.usebottles.bottles; read -p Done...'"])):
            b = Gtk.Button(label=label); b.connect("clicked", lambda _b, c=cmd: spawn(c)); fl.add(b)
        tl.pack_start(fl, False, False, 0)
        self._add("tools", card(tl))

    def on_autologin(self, sw, _p):
        if self._al_busy: return
        import getpass
        on = sw.get_active()
        args = ("autologin", "on", getpass.getuser()) if on else ("autologin", "off")
        def done(rc):
            if rc != 0:
                self._al_busy = True; sw.set_active(not on); self._al_busy = False
        stream_cmd(admin_cmd(*args), lambda s: None, done)

    def on_fastboot(self, w, _p):
        if self._fb_busy: return
        want = w.get_active(); self._fb_busy = True; self.fbsw.set_sensitive(False); self.fbl.set_text(t("fb_working"))
        def line(_s): pass
        def done(rc):
            self.fbsw.set_sensitive(True)
            if rc != 0:
                self.fbsw.set_active(not want); self.fbl.set_text(t("fb_fail"))
            else: self.fbl.set_text(t("fb_ok") if want else t("fb_off"))
            self._fb_busy = False
        stream_cmd(admin_cmd("fastboot-on" if want else "fastboot-off"), line, done)

    def _add(self, name, w):
        if self.section in (None, name): self.box.pack_start(w, False, False, 0)

    def _h(self, txt):
        l = Gtk.Label(label=txt, xalign=0); l.get_style_context().add_class("lmg-title"); return l
    def _row(self, label, w):
        h = Gtk.Box(spacing=12); h.pack_start(Gtk.Label(label=label, xalign=0, wrap=True), True, True, 0); h.pack_end(w, False, False, 0); return h
    def set(self, k, v):
        self.s[k] = v; save_settings(self.s)
    def on_light(self, w, _p):
        on = w.get_active(); self.set("light_mode", on)
        spawn(["lmg-session-apply"])
    def on_fancy(self, w, _p):
        self.set("fancy_animations", w.get_active())
        spawn(["lmg-session-apply"])
    def on_lang(self, w):
        new = w.get_active_id()
        if new == self.s.get("language"): return          # also fired while the page is being built
        self.set("language", new); apply_system_language(new)
    def pick_wall(self, *_):
        from lmg_walls import choose_wall
        choose_wall(self.get_toplevel())
    def _cur_layouts(self):
        for l in run(["setxkbmap", "-query"]).splitlines():
            if l.startswith("layout:"): return l.split(":", 1)[1].strip()
        return "us"
    def apply_kb(self, *_):
        lay = self.kb.get_text().strip().replace(" ", "") or "us"
        subprocess.run(["setxkbmap", "-layout", lay, "-option", "grp:alt_shift_toggle"])
        os.makedirs(CONF_DIR, exist_ok=True)
        open(os.path.join(CONF_DIR, "keyboard.sh"), "w").write(f"#!/bin/sh\nsetxkbmap -layout {lay} -option grp:alt_shift_toggle\n")
        os.chmod(os.path.join(CONF_DIR, "keyboard.sh"), 0o755)
