import json, os
from lmgcommon import *

INFO = "/var/lib/lmg/upgrade-info.json"
READY = "/var/lib/lmg/upgrade/ready.json"


def jread(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def mb(n):
    return "%.1f GB" % (n / 2**30) if n >= 2**30 else "%d MB" % (n // 2**20)


class Page(PageBase):
    """LMG Upgrade: look in the public release repository for a newer LMG OS, download it, restart into the upgrade."""
    def __init__(self, win=None):
        super().__init__(win)
        self._busy = False; self.info = {}
        self.box.pack_start(heading(t("upg_title"), t("upg_sub")), False, False, 0)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.status = Gtk.Label(label="", xalign=0, wrap=True); self.status.get_style_context().add_class("lmg-title")
        self.detail = Gtk.Label(label="", xalign=0, wrap=True); self.detail.get_style_context().add_class("lmg-sub")
        self.bar = Gtk.ProgressBar(show_text=True); self.bar.set_no_show_all(True)
        inner.pack_start(self.status, False, False, 0); inner.pack_start(self.detail, False, False, 0); inner.pack_start(self.bar, False, False, 0)
        row = Gtk.Box(spacing=8)
        self.b_check = Gtk.Button(label=t("upd_check")); self.b_check.connect("clicked", self.check)
        self.b_dl = Gtk.Button(label=t("upg_download")); self.b_dl.get_style_context().add_class("suggested-action"); self.b_dl.connect("clicked", self.download); self.b_dl.set_no_show_all(True)
        self.b_go = Gtk.Button(label=t("upg_go")); self.b_go.get_style_context().add_class("suggested-action"); self.b_go.connect("clicked", self.go); self.b_go.set_no_show_all(True)
        for b in (self.b_check, self.b_dl, self.b_go): row.pack_start(b, False, False, 0)
        inner.pack_start(row, False, False, 4)
        self.box.pack_start(card(inner), False, False, 0)
        note = Gtk.Label(label=t("upg_note"), xalign=0, wrap=True); note.get_style_context().add_class("lmg-sub"); self.box.pack_start(note, False, False, 0)
        self.live = is_live()
        self.show_info(jread(INFO))

    def show_info(self, info):
        self.info = info or {}
        cur = self.info.get("current") or VERSION
        self.b_dl.hide(); self.b_go.hide(); self.bar.hide()
        if self.live:
            self.status.set_text(t("upg_live")); self.detail.set_text(""); self.b_check.set_sensitive(False); return
        if self.info.get("available"):
            ver = self.info["version"]
            ready = jread(READY).get("version") == ver
            self.status.set_text(t("upg_found").format(ver))
            self.detail.set_text(t("upg_size").format(mb(self.info.get("size", 0))) + ("\n" + t("upg_ready") if ready else ""))
            (self.b_go if ready else self.b_dl).show()
        elif self.info.get("error"):
            self.status.set_text(t("upg_offline")); self.detail.set_text("")
        elif self.info.get("checked"):
            self.status.set_text(t("upg_latest").format(cur)); self.detail.set_text("")
        else:
            self.status.set_text(t("upg_current").format(cur)); self.detail.set_text("")

    def _busy_on(self, on):
        self._busy = on; self.b_check.set_sensitive(not on); self.b_dl.set_sensitive(not on); self.b_go.set_sensitive(not on)

    def check(self, *_):
        if self._busy: return
        self._busy_on(True); self.status.set_text(t("upg_checking")); out = []
        stream_cmd(admin_cmd("upgrade-check"), out.append, lambda rc: self._checked(out))

    def _checked(self, out):
        self._busy_on(False)
        info = {}
        for l in reversed(out):
            if l.startswith("{"):
                try: info = json.loads(l); break
                except Exception: pass
        self.show_info(info or jread(INFO) or {"error": "x", "checked": 1})

    def download(self, *_):
        if self._busy: return
        self._busy_on(True); self.bar.show(); self.bar.set_fraction(0); self.bar.set_text("0%"); self.status.set_text(t("upg_downloading")); res = []
        def line(l):
            if l.startswith("PCT "):
                p = l.split(None, 2)
                try:
                    v = int(p[1]); self.bar.set_fraction(v / 100.0); self.bar.set_text("%d%%" % v)
                    if len(p) > 2: self.detail.set_text(p[2])
                except ValueError: pass
            elif l.startswith(("OK", "FAIL")): res.append(l)
        stream_cmd(admin_cmd("upgrade-download"), line, lambda rc: self._downloaded(res))

    def _downloaded(self, res):
        self._busy_on(False)
        if res and res[-1] == "OK":
            self.show_info(self.info)
        else:
            self.show_info(self.info); self.detail.set_text((res[-1][5:] if res else "") or t("upg_dl_fail"))

    def go(self, *_):
        if self._busy: return
        if not confirm(self.get_toplevel(), t("upg_confirm"), t("upg_confirm_detail")): return
        self._busy_on(True); self.status.set_text(t("upg_restarting"))
        stream_cmd(admin_cmd("upgrade-apply"), lambda l: self.detail.set_text(l), lambda rc: (self._busy_on(False), rc and self.status.set_text(t("upg_dl_fail"))))
