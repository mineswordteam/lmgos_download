"""LMG Store - everything behind the page (no GTK; tested without a display).
Sources: Flathub (thousands of desktop apps with icons, screenshots, sizes) and Debian (apt). Installed apps get a desktop shortcut."""
import hashlib, html, json, os, re, shlex, shutil, subprocess, threading, time, urllib.parse, urllib.request

HOME = os.environ.get("LMG_USER_HOME") or os.path.expanduser("~")
CACHE = os.environ.get("LMG_STORE_CACHE") or os.path.join(HOME, ".cache", "lmg-store")
STATE = os.path.join(HOME, ".config", "lmg", "store-installed.json")
FLATHUB = os.environ.get("LMG_FLATHUB", "https://flathub.org/api/v2")
HELPER = "/usr/lib/lmg/bin/lmg-helper"
MOCK = os.environ.get("LMG_STORE_MOCK") == "1"
IMG_HOSTS = ("flathub.org", "dl.flathub.org", "screenshots.debian.net", "debian.org")
CATS = [  # id (Flathub main category), English, Persian, emoji-free icon key
    ("AudioVideo", "Audio & Video", "صدا و تصویر"), ("Development", "Development", "برنامه‌نویسی"), ("Education", "Education", "آموزش"),
    ("Game", "Games", "بازی‌ها"), ("Graphics", "Graphics", "گرافیک"), ("Network", "Internet", "اینترنت"),
    ("Office", "Office", "اداری"), ("Science", "Science", "علمی"), ("System", "System", "سیستم"), ("Utility", "Utilities", "ابزارها")]
FEATURED = ["org.videolan.VLC", "org.blender.Blender", "com.obsproject.Studio", "org.gimp.GIMP", "com.valvesoftware.Steam",
            "org.telegram.desktop", "org.kde.krita", "org.libreoffice.LibreOffice"]
WINDOWS = [  # curated: LMG cannot ship these installers - the page sends people to the official site; lmg-wine-run opens the .exe
    ("Adobe Photoshop", "Image editing", "https://www.adobe.com/products/photoshop.html", "Graphics"),
    ("Microsoft Office", "Word, Excel, PowerPoint", "https://www.office.com", "Office"),
    ("Notepad++", "Code and text editor", "https://notepad-plus-plus.org/downloads/", "Development"),
    ("WinRAR", "Archives", "https://www.win-rar.com/download.html", "Utility"),
    ("Internet Download Manager", "Fast downloads", "https://www.internetdownloadmanager.com/download.html", "Network"),
    ("CorelDRAW", "Vector graphics", "https://www.coreldraw.com", "Graphics"),
    ("Sony Vegas Pro", "Video editing", "https://www.vegascreativesoftware.com", "AudioVideo"),
    ("FL Studio", "Music production", "https://www.image-line.com/fl-studio-download/", "AudioVideo"),
    ("Foobar2000", "Music player", "https://www.foobar2000.org/download", "AudioVideo"),
    ("IrfanView", "Image viewer", "https://www.irfanview.com", "Graphics"),
    ("7-Zip", "Archives", "https://www.7-zip.org/download.html", "Utility"),
    ("Everything", "Instant file search", "https://www.voidtools.com/downloads/", "Utility"),
]


# ------------------------------------------------------------------ fetching with a disk cache
def _cpath(key): return os.path.join(CACHE, hashlib.sha1(key.encode()).hexdigest() + ".json")

def fetch_json(url, ttl=6 * 3600, post=None, opener=None):
    """GET/POST JSON. Fresh cache first; on a network error an old cache is better than nothing."""
    key = url + (json.dumps(post, sort_keys=True) if post else "")
    p = _cpath(key)
    try:
        if time.time() - os.path.getmtime(p) < ttl: return json.load(open(p))
    except Exception: pass
    try:
        data = json.dumps(post).encode() if post is not None else None
        req = urllib.request.Request(url, data=data, headers={"User-Agent": "LMG-Store/2", "Content-Type": "application/json", "Accept": "application/json"})
        with (opener or urllib.request.urlopen)(req, timeout=20) as r: d = json.loads(r.read().decode("utf-8"))
        os.makedirs(CACHE, exist_ok=True); tmp = p + ".tmp"; json.dump(d, open(tmp, "w")); os.replace(tmp, p)
        return d
    except Exception:
        try: return json.load(open(p))
        except Exception: return None

def fetch_image(url):
    """(bytes, content-type) of an allowed image, cached on disk."""
    host = urllib.parse.urlparse(url).hostname or ""
    if not url.startswith("https://") or not any(host == h or host.endswith("." + h) for h in IMG_HOSTS): return None, None
    p = os.path.join(CACHE, "img-" + hashlib.sha1(url.encode()).hexdigest())
    try: return open(p, "rb").read(), (open(p + ".t").read() or "image/png")
    except Exception: pass
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "LMG-Store/2"}), timeout=20) as r:
            b = r.read(8 * 1024 * 1024); ct = r.headers.get("Content-Type", "image/png")
        os.makedirs(CACHE, exist_ok=True); open(p, "wb").write(b); open(p + ".t", "w").write(ct); return b, ct
    except Exception: return None, None


# ------------------------------------------------------------------ Flathub
def icon_url(app_id): return "https://dl.flathub.org/repo/appstream/x86_64/icons/128x128/%s.png" % app_id

def norm_hit(h):
    if not isinstance(h, dict): return None
    aid = h.get("app_id") or h.get("id") or h.get("flatpakAppId")
    if not aid: return None
    cats = h.get("main_categories") or h.get("categories") or []
    if isinstance(cats, str): cats = [cats]
    return {"src": "flatpak", "id": aid, "name": h.get("name") or aid.split(".")[-1], "summary": h.get("summary") or "",
            "icon": h.get("icon") or icon_url(aid), "cats": [c if isinstance(c, str) else str(c) for c in cats][:3],
            "dev": h.get("developer_name") or "", "installs": h.get("installs_last_month") or 0}

def _hits(d):
    if isinstance(d, list): return d
    if isinstance(d, dict):
        for k in ("hits", "apps", "items", "results"):
            if isinstance(d.get(k), list): return d[k]
    return []

def flathub_list(kind="popular", page=1, per_page=24, category=None):
    if category: url = "%s/collection/category/%s?page=%d&per_page=%d" % (FLATHUB, urllib.parse.quote(category), page, per_page)
    else: url = "%s/collection/%s?page=%d&per_page=%d" % (FLATHUB, kind, page, per_page)
    d = fetch_json(url, ttl=3 * 3600)
    return [x for x in (norm_hit(h) for h in _hits(d)) if x]

def flathub_search(q, per_page=30):
    d = fetch_json(FLATHUB + "/search", ttl=3600, post={"query": q, "hits_per_page": per_page})
    return [x for x in (norm_hit(h) for h in _hits(d)) if x]

_ALLOWED = re.compile(r"</?(p|ul|ol|li|em|strong|b|i|code|br)\s*/?>", re.I)
def clean_html(s):
    """Flathub descriptions are small HTML (p, ul, li ...): keep those tags, drop everything else."""
    s = s or ""
    parts = re.split(r"(<[^>]*>)", s); out = []
    for x in parts:
        if x.startswith("<"): out.append(re.sub(r"\s+[^>]*", "", x) if _ALLOWED.fullmatch(re.sub(r"\s+[^>]*(?=/?>)", "", x)) else "")
        else: out.append(html.escape(html.unescape(x), quote=False))
    return "".join(out)

def _shots(d):
    out = []
    for s in d.get("screenshots") or []:
        if isinstance(s, str): out.append({"src": s, "caption": ""}); continue
        if not isinstance(s, dict): continue
        sizes = s.get("sizes") or []
        best = None
        for z in sizes:
            try:
                if best is None or int(z.get("width") or 0) > int(best.get("width") or 0): best = z
            except Exception: pass
        src = (best or {}).get("src") or s.get("src") or s.get("url") or s.get("image")
        if src: out.append({"src": src, "caption": s.get("caption") or ""})
    return out

def flathub_detail(app_id):
    d = fetch_json("%s/appstream/%s?locale=en" % (FLATHUB, urllib.parse.quote(app_id)), ttl=12 * 3600)
    if not isinstance(d, dict): return None
    sm = fetch_json("%s/summary/%s" % (FLATHUB, urllib.parse.quote(app_id)), ttl=12 * 3600)
    sm = sm if isinstance(sm, dict) else {}
    rels = d.get("releases") or []
    r0 = rels[0] if rels and isinstance(rels[0], dict) else {}
    urls = d.get("urls") if isinstance(d.get("urls"), dict) else {}
    cats = d.get("categories") or []
    return {"src": "flatpak", "id": app_id, "name": d.get("name") or app_id, "summary": d.get("summary") or "",
            "icon": d.get("icon") or icon_url(app_id), "description": clean_html(d.get("description") or ""),
            "shots": _shots(d), "dev": d.get("developer_name") or d.get("developer") or "",
            "license": d.get("project_license") or "", "home": urls.get("homepage") or "",
            "version": r0.get("version") or "", "date": r0.get("timestamp") or "",
            "cats": [c for c in cats if isinstance(c, str)][:4],
            "download": int(sm.get("download_size") or 0), "installed_size": int(sm.get("installed_size") or 0)}


# ------------------------------------------------------------------ Debian (apt)
def _run(cmd, **kw):
    try: return subprocess.run(cmd, capture_output=True, text=True, timeout=kw.pop("timeout", 30), **kw).stdout
    except Exception: return ""

BAD_PKG = re.compile(r"^(lib|python3-|fonts-|linux-|gir1\.2|node-|golang-|ruby-|php|r-|texlive|task-|.*-(dev|dbg|doc|data|common|l10n|locales|headers)$)")
def apt_search(q, limit=20):
    out = []
    for l in _run(["apt-cache", "search", "--names-only", q] if len(q) > 1 else ["true"]).splitlines():
        if " - " not in l: continue
        n, s = l.split(" - ", 1)
        if BAD_PKG.match(n): continue
        out.append({"src": "apt", "id": n, "name": n, "summary": s, "icon": "", "cats": [], "dev": "", "installs": 0})
        if len(out) >= limit: break
    return out

def apt_detail(pkg):
    txt = _run(["apt-cache", "show", pkg])
    if not txt: return None
    f = {}; desc = []
    for l in txt.split("\n\n")[0].splitlines():
        if l.startswith(" "): desc.append("" if l.strip() == "." else l.strip())
        elif ": " in l: k, v = l.split(": ", 1); f.setdefault(k, v)
    d = html.escape("\n".join(desc))
    d = "".join("<p>%s</p>" % p.replace("\n", " ") for p in d.split("\n\n") if p.strip())
    try: inst = int(f.get("Installed-Size", "0")) * 1024
    except Exception: inst = 0
    try: dl = int(f.get("Size", "0"))
    except Exception: dl = 0
    return {"src": "apt", "id": pkg, "name": f.get("Package", pkg), "summary": (f.get("Description", "").split("\n")[0]), "icon": "",
            "description": d, "shots": [], "dev": f.get("Maintainer", "").split("<")[0].strip(), "license": "", "home": f.get("Homepage", ""),
            "version": f.get("Version", ""), "date": "", "cats": [f.get("Section", "")] if f.get("Section") else [], "download": dl, "installed_size": inst}


# ------------------------------------------------------------------ what is installed
def installed_flatpaks():
    out = _run(["flatpak", "list", "--app", "--columns=application"])
    return {l.strip() for l in out.splitlines() if l.strip() and "." in l}

def installed_apt(names):
    names = [n for n in names if re.fullmatch(r"[a-z0-9][a-z0-9+.\-]*", n or "")]
    if not names: return set()
    out = _run(["dpkg-query", "-W", "-f", "${Package} ${Status}\n"] + names)
    return {l.split()[0] for l in out.splitlines() if l.endswith("install ok installed")}

def load_state():
    try: return json.load(open(STATE))
    except Exception: return {}

def save_state(s):
    os.makedirs(os.path.dirname(STATE), exist_ok=True); json.dump(s, open(STATE, "w"), indent=1)

def installed_list():
    """Everything installed through the store (state) that is still installed."""
    st = load_state(); fl = installed_flatpaks(); res = []
    ap = installed_apt([k.split(":", 1)[1] for k in st if k.startswith("apt:")])
    for k, v in st.items():
        src, i = k.split(":", 1)
        if (src == "flatpak" and i in fl) or (src == "apt" and i in ap):
            res.append({"src": src, "id": i, "name": v.get("name", i), "icon": v.get("icon") or (icon_url(i) if src == "flatpak" else ""), "summary": v.get("summary", "")})
    return res


# ------------------------------------------------------------------ the desktop shortcut
def desktop_dir():
    d = os.environ.get("LMG_DESKTOP_DIR")
    if d: return d
    try:
        d = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True, text=True, timeout=5).stdout.strip()
        if d and d != HOME: return d
    except Exception: pass
    return os.path.join(HOME, "Desktop")

def find_desktop_file(src, ident):
    if src == "flatpak":
        for base in (os.path.join(HOME, ".local/share/flatpak/exports/share/applications"), "/var/lib/flatpak/exports/share/applications"):
            p = os.path.join(base, ident + ".desktop")
            if os.path.exists(p): return p
        return None
    out = _run(["dpkg", "-L", ident]).splitlines()
    cands = [l for l in out if l.startswith("/usr/share/applications/") and l.endswith(".desktop")]
    for p in cands:
        try:
            if not re.search(r"^NoDisplay=true", open(p, errors="ignore").read(), re.M): return p
        except OSError: pass
    return None

def add_shortcut(src, ident):
    """Copy the app's launcher onto the desktop. Returns the new path or None."""
    p = find_desktop_file(src, ident)
    if not p: return None
    dd = desktop_dir(); os.makedirs(dd, exist_ok=True)
    dst = os.path.join(dd, os.path.basename(p))
    if not os.path.exists(dst):
        shutil.copy(p, dst); os.chmod(dst, 0o755)
        try: subprocess.run(["gio", "set", dst, "metadata::trusted", "true"], capture_output=True)
        except OSError: pass   # no gio (minimal system / CI container): the shortcut still works
    return dst

def remove_shortcut(path):
    try:
        if path and os.path.dirname(path) == desktop_dir() and path.endswith(".desktop"): os.remove(path)
    except OSError: pass


# ------------------------------------------------------------------ install / remove jobs
JOBS = {}

def _admin(args):
    if os.geteuid() == 0: return [HELPER] + args
    return ["pkexec", HELPER] + args

def build_cmd(action, src, ident):
    """The command for one job; None if the id is not acceptable."""
    if src == "flatpak":
        if not re.fullmatch(r"[A-Za-z0-9_.\-]+", ident or ""): return None
        if action == "install":
            line = "flatpak remote-add --user --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo && echo 'Preparing the app list - first time only, a few minutes on slow PCs' && flatpak update --user --appstream && flatpak install --user -y --noninteractive flathub " + shlex.quote(ident)
            # flatpak prints percentages only on a terminal: run it on a pseudo-terminal so the bar can move
            if shutil.which("script"): return ["script", "-qfec", line, "/dev/null"]
            return ["sh", "-c", line]
        return ["flatpak", "uninstall", "--user", "-y", "--noninteractive", ident]
    if src == "apt":
        if not re.fullmatch(r"[a-z0-9][a-z0-9+.\-]*", ident or ""): return None
        return _admin(["pkg-install" if action == "install" else "pkg-remove", ident])
    return None

def apt_plan_count(pkg):
    out = _run(["apt-get", "-s", "install", pkg], timeout=60)
    return max(1, len(re.findall(r"^Inst ", out, re.M)))

class Job:
    def __init__(self, action, src, ident, meta=None, cmd=None):
        self.id = "%s-%d" % (ident, int(time.time() * 1000)); self.action, self.src, self.ident = action, src, ident
        self.pct = 0; self.state = "running"; self.line = ""; self.ok = False; self.meta = meta or {}; self.log = []
        self.cmd = cmd or build_cmd(action, src, ident)
        JOBS[self.id] = self
        threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        if not self.cmd: self.state, self.line = "error", "bad request"; return
        if MOCK: return self.mock()
        try:
            planned = apt_plan_count(self.ident) if (self.src == "apt" and self.action == "install") else 1
            p = subprocess.Popen(self.cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True, bufsize=1, env=dict(os.environ, LC_ALL="C", DEBIAN_FRONTEND="noninteractive"))
            steps = 0
            for l in p.stdout:
                for part in l.replace("\r", "\n").split("\n"):
                    part = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", part).strip()
                    if not part: continue
                    self.line = part[-160:]; self.log = (self.log + [part])[-40:]
                    m = re.search(r"(\d{1,3})%", part)
                    if m and self.src == "flatpak": self.pct = max(self.pct, min(99, int(m.group(1))))
                    if self.src == "apt":
                        if part.startswith("Get:"): self.pct = max(self.pct, min(40, self.pct + 4))
                        if part.startswith(("Unpacking", "Setting up", "Removing")):
                            steps += 1; self.pct = max(self.pct, min(99, 40 + int(60 * steps / (2.0 * planned))))
            rc = p.wait()
            self.ok = rc == 0
        except Exception as e:
            self.line = str(e); self.ok = False
        if self.ok: self.after()
        self.pct = 100 if self.ok else self.pct; self.state = "done" if self.ok else "error"

    def mock(self):
        for i in range(1, 11): time.sleep(0.15); self.pct = i * 10
        self.ok = True; self.after(); self.state = "done"

    def after(self):
        st = load_state(); key = "%s:%s" % (self.src, self.ident)
        if self.action == "install":
            sc = None if MOCK and not os.environ.get("LMG_DESKTOP_DIR") else add_shortcut(self.src, self.ident)
            st[key] = dict(self.meta, shortcut=sc or "")
        else:
            remove_shortcut((st.get(key) or {}).get("shortcut")); st.pop(key, None)
        save_state(st)

def start_job(action, src, ident, meta=None):
    for j in JOBS.values():
        if j.state == "running" and j.ident == ident: return j
    return Job(action, src, ident, meta)

def job_info(jid):
    j = JOBS.get(jid)
    if not j: return None
    return {"id": j.id, "pct": j.pct, "state": j.state, "line": j.line, "ok": j.ok, "action": j.action}

def launch(src, ident):
    if MOCK: return True
    try:
        if src == "flatpak": subprocess.Popen(["flatpak", "run", ident], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            p = find_desktop_file("apt", ident)
            if not p: return False
            subprocess.Popen(["gtk-launch", os.path.basename(p)], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception: return False

def human(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB": return ("%d %s" % (n, u)) if u == "B" else ("%.1f %s" % (n, u) if n < 100 else "%d %s" % (n, u))
        n /= 1024.0
